# Working in House App Starter

- Read README.md, GUIDE.md, APP_SPEC.md, WORKFLOW.md, INPUTS.md and SCENE_CONTRACT.md before
  adapting this project. User instructions take precedence over these guidelines.
- Keep the existing viewer styling/interactions while replacing project data.
- Product names start the research/modeling workflow. Do not require users to
  provide 3D furniture assets. Record exact variants, dimensions and evidence;
  author, preview and refine product geometry.
- Use meters with Y up. Display-unit preferences do not change scene coordinates.
  Calibrate the plan once; add products with real-meter transforms.
- Preserve factory ownership, explicit feature bindings, movement bounds and
  separate pendant body/suspension. Keep product finishes independent.
- Record critical user corrections, assumptions and unresolved facts in project
  files. Ask concise grouped questions only when necessary and continue independent
  work while answers are pending.
- Rebuild generated bundles after source or imported asset changes. Follow
  VALIDATION.md; fix concrete failures and report verification not performed.
- The built-in demo is synthetic. Material inspection, session-memory edits and
  project-link Share are the baseline semantics; additions require implementation
  and verification before being described as supported.

- Maintain completed input/source/decision/progress records; templates are not
  runtime configs. Give concrete shell, product and furnished-house previews.
- Capture a running starter UI baseline where possible. Geometry reference images
  establish model appearance only; report actual browser/manual checks separately.
- Edit BUILD_PROMPT.txt as the canonical prompt and run npm run docs:sync.
