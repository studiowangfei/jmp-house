# Application specification

This specification defines the reusable viewer baseline. Adapt project content
while retaining the supported UI and interactions. Bind house-dependent features
to actual objects using `SCENE_CONTRACT.md`.

## Viewer and layout

- Full-viewport Three.js scene with orthographic 3D and top-down Plan views.
- 3D orbit, pan/zoom, 90-degree rotation and canonical Reset; Plan pans without
  freely orbiting away from the top view.
- Structure, cabinetry, furniture, lighting and trees layers; cutaway hides
  camera-facing exterior walls together with their frames/glass. Plan keeps
  exterior walls visible regardless of cutaway state.
- Day/Night toggle, fixture glow and bounded shelf/frame light effects; Night is
  an authored illustration, not photometric validation.
- Neutral paper palette, serif metadata, minimal line icons, 44px control cells
  at the upper right and 56px catalog cells along the bottom. Keep source styling,
  transitions, collapsed/expanded states and active-state treatment.
- Narrow screens use tighter margins and smaller expanded catalog cells. Short
  screens use a horizontal toolbar. Preserve space around focused objects when a
  mobile catalog expands.
- Percentage loader, media fallback handling, keyboard labels/focus and
  reduced-motion behavior; pause unnecessary rendering/media when hidden.

## Catalog

- Horizontal materials/products strip, static thumbnails and one expanded item.
- Product identity, finish and W/D/H labels; live rotating procedural preview.
- Material name and usage; inspect installed materials.
- Selection focuses relevant scene objects and dims surrounding content; closing
  restores materials without jumping the current camera pose.
- Desktop hover/click and touch tap/swipe distinguish scroll from selection.
- The material catalog **does not replace finishes**. Source URLs/evidence belong
  in project records; internal implementation filenames need not be product UI.

## Rearrange and snapshot

- Opt-in Rearrange; select movable furniture/lighting roots and registered wall
  items, then drag subject to floor/surface/wall bounds.
- Selection outline and W/D/H labels; rotate in 15-degree increments;
  duplicate/delete; undo/redo and canonical reset.
- Architecture and fixed cabinetry are not editable via Rearrange.
- Snapshot hides selection/grid helpers and centers the scene. Desktop uses 4:3;
  touch uses 3:4. Preview, Save image, Share and dismissal are supported.
- Edits use current-session memory. No persistence, account system or saved
  arrangement links are implied.
- Share copies/opens the configured project URL, falling back to the current
  page URL. It does not serialize furniture edits or share the snapshot file.

## Gallery and media

- Gallery opens through its toolbar or visible scene photo frames. Support the
  frame-to-photo Genie transition, selected image, thumbnails, keyboard arrows,
  Escape, touch navigation and restored scene controls/focus on dismissal.
- Sound controls include title, play/pause, previous/next, playlist/repeat-one and
  progress; a bound speaker can act as a scene hotspot/reactive object.
- A bound TV displays muted day/night media with the existing transition behavior.
- A bound fireplace toggles its illustrative flames; a mirror reflects the scene.
- Information control shows the configured title/description.
- Media and editor overlays dim/blur the underlying scene and prevent competing
  interactions. Preserve keyboard and touch behavior.

## Content and scope

The shipped products/materials/media are fictional demo content. Real projects
require measurements, research and authored scene adaptation. The viewer is not
an upload/build wizard, a generic CAD importer, an e-commerce configurator or a
construction-document generator. Missing object types should be handled through
explicit optional bindings; do not invent features in the actual building.

Additional features such as material switching, saved arrangements, exports of
editable 3D files or multi-level navigation are separate implementation tasks.
