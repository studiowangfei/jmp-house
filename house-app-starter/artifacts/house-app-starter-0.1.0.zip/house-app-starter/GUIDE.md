# Build a house app with your AI agent

This guide is for the homeowner. [WORKFLOW.md](WORKFLOW.md) gives the agent the
technical steps, and [APP_SPEC.md](APP_SPEC.md) defines the interface and features
your app will inherit.

## Start here

1. Download and extract House App Starter, or give your coding agent the starter
   ZIP or repository checkout.
2. Copy the complete text from [BUILD_PROMPT.txt](BUILD_PROMPT.txt) into your agent.
3. Attach the plans, measurements, photos and selections you already have.

Use a coding agent that can read and edit files, inspect drawings/images, search
the web and run the application. Browser access helps it verify the result; you
can also review the local app in your own browser.

The shared ZIP excludes `node_modules`. Your agent installs the dependencies
from `package.json` and `package-lock.json`. You do not have to assemble a software
environment or fill in a JSON form before giving the agent your information.

The starter is a working example. The agent replaces its fictional house and
selections with yours while using its viewer, controls, catalogs and interactions.

## The six stages

| Stage | What you provide | What the agent produces |
| --- | --- | --- |
| 1. Start and intake | Available plans, dimensions, photos and corrections | A file inventory and a small batch of critical missing questions |
| 2. House shell | Answers about scale, heights, layout and openings | A dimensioned Plan view, several 3D views and a list of estimates |
| 3. Products and materials | Product/material names or links; preferences you know | Researched specifications, dimensioned product previews and material swatches |
| 4. Furnished house | Placement preferences and corrections | A furnished model with quantities, clearances and installation heights |
| 5. Verification | Feedback from the running app | Desktop/mobile checks, screenshots and interaction evidence |
| 6. Delivery | Final corrections and any requested hosting destination | Runnable source, a deployment build, records and update instructions |

At each stage, the agent should show concrete work you can review. It can keep
researching, modeling and testing confirmed parts while it waits for an answer.

## 1. Give it the house information first

Send your latest floor plan in whatever readable format you have: a dimensioned
PDF, clear screenshot, drawing or useful model/CAD export. Elevations and room
photos help establish window heights, doors and built-ins. Tell the agent which
revision and corrections to follow.

For the first measured preview, it needs:

- The layout and number of levels.
- Units and reliable plan measurements in both directions, unless a usable
  measured model already establishes scale.
- Finished-floor-to-ceiling height and any changes in floor level.
- Enough information to interpret measured wall faces and important openings.

The agent should read your files before asking questions. Ask it to request only
missing critical facts in its first batch. Public websites can supply a chair's
dimensions; your house's unrecorded measurements need your input.

For example, you can send:

> Here is my latest plan. The overall dimensions are marked on it in feet and
> inches. The finished ceiling is 8 feet high. The doorway crossed out in red
> has been removed. Use the room photos to clarify the windows.

The starter currently models a single level with orthogonal walls and a cutaway
ceiling. If your project includes angled walls, stairs or multiple levels, the
agent should explain the scene and viewing changes required for your project.

## 2. Review the measured shell

The agent should show a labeled Plan view and several 3D directions before
detailing uncertain areas. It should identify confirmed measurements and mark
traced or estimated details.

Check the footprint, partitions, rooms, openings, ceiling height, level changes
and built-ins. Corrections can be plain language or marks on a screenshot:

> The bathroom divider belongs farther to the left. Keep the overall room width
> as measured. That opening is a window, not a door.

The agent records the correction and updates affected geometry. It should ask
about conflicting critical dimensions rather than treating an estimate as a
measurement.

## 3. Name the products and materials you want

**A product name is enough to start.** A link, brand, exact size, finish or SKU
can help identify the intended version, but you can supply those later.

For example:

> Add two IKEA MARIUS stools in black. Find their product photos and dimensions,
> build the models, and show me the previews.

The agent should:

1. Find the manufacturer and useful retailer pages.
2. Identify the intended model and variant; ask about choices that remain unclear.
3. Inspect photographs from useful angles and available dimension drawings.
4. Record dimensions, materials, finish, source links and estimated details.
5. Build a procedural 3D visualization with the product's distinctive shape.
6. Show front, side and 3D previews, refine it and generate its catalog thumbnail.

This is the product-name → research → modeling → review → integration flow.
You do not need to supply a furniture CAD library or manufacturer 3D files.

Review products in sensible batches. Look for the right variant, proportions,
legs, cushions, shells, shade profiles and finish. Published overall dimensions
and appearance inferred from photographs should be distinguishable in the
records. A dimensioned visualization does not certify fine construction details.

For materials, names, links or a swatch/photo are useful. Tell the agent which
surfaces use each material. Tile/slab size, board width, grain direction and sheen
help it apply the texture at the right scale.

## 4. Review the furnished house

Provide a marked placement plan or simple notes about rooms, orientation and
relationships. If you have no placement plan, ask the agent for an initial
proposal with the proposed positions clearly labeled.

For example:

> Put the sofa opposite the media wall. Mount the TV to that wall. Center the
> pendant over the table and leave its cord drop separate from the fixture size.

Check quantities, movement clearance, room scale and installation heights.
Wall-mounted objects should attach to actual walls; objects resting on a table,
counter or floor should meet their supporting surface. Lighting and Gallery
hotspots should follow their objects when moved.

At this stage you can provide the project title, description, Gallery photos,
captions and optional media. If your house has no particular object or feature,
the agent should represent that choice explicitly. It should not invent a
fireplace or other building element to make a control active.

## How reviews work

- Give corrections or answer the specific unresolved questions. Re-uploading all
  your data or completing a technical form should not be necessary.
- The agent should retain previously confirmed selections and instructions.
  A new correction should say which earlier interpretation it supersedes.
- Reviews can be batched. The agent can continue confirmed and independent work
  while feedback is pending.
- An unanswered critical question stays open. A period of silence does not
  establish a ceiling height, resolve a disputed dimension or choose a variant.

## 5. Check the running app

Ask the agent to give you the exact local URL and concise review instructions.
You can rotate the house, switch to Plan, inspect the catalogs and try Night and
Rearrange. Check both desktop and phone layouts when available.

The agent should verify the model against your inputs and the UI against the
starter's specification and running baseline. The bundled axon image and plan
are geometry references; they are not screenshots of the app interface.

The full checklist is in [VALIDATION.md](VALIDATION.md). It includes catalogs and
camera focus, layers/cutaway, Night effects, Gallery, Rearrange/history, snapshots,
sharing and applicable media controls. Animated transitions need normal-motion
review as well as static screenshots.

If browser automation cannot run, the agent should continue the build and
geometry checks, give you a working local preview and record the specific manual
checks still needed. It should record what you reviewed without treating a
general impression as proof that every interaction passed.

The current material catalog inspects installed finishes. Rearrangement uses
session memory. Save image exports a PNG; Share sends the project URL. These are
the baseline behaviors; requested additions need their own implementation.

## 6. What you should receive

- Source files you or another agent can update, including the dependency manifests.
- A verified `dist` folder or deployment ZIP for serving the finished website.
- Completed inputs, source evidence, decisions, remaining estimates and progress.
- Plan/3D/product previews and the available browser/interaction evidence.
- A short verification report with passed, failed, pending and inapplicable items.
- Exact instructions to run locally, change the data, rebuild and deploy.

Source archives should exclude `node_modules`; the finished website uses bundled
JavaScript. The deployment and review evidence may be delivered separately from
the source archive. If you request hosting or repository publication, give the
agent the intended destination when the result is ready for that step.

Your new agent should be able to continue from the project records without this
original conversation.

## A short instruction you can add to the prompt

> Start with the files and measurements I have already provided. Ask for missing
> house facts in small batches. Research and model my products from their names
> and photos, show useful previews, and preserve the starter's UI. Keep decisions
> and progress in files, fix issues found during review, and deliver source plus
> the verified deployment build.
