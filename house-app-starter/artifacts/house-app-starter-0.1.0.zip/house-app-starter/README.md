# House App Starter

A runnable starter for an interactive house visualization. It pairs the viewer
with a copy/paste prompt that guides a coding agent through collecting your
plans, researching your furniture and materials, authoring the model and
delivering your own build.

The bundled home, product designs, textures, artwork, audio and videos are
independently authored fictional examples. Replace them with your project.

## Start the demo

Requirements for preview: Python 3.10 or newer. The package includes prebuilt
viewers in `runtime/`. From the extracted starter folder, run:

```sh
python3 scripts/serve.py
```

Open [the house](http://127.0.0.1:4175/) or
[product previews](http://127.0.0.1:4175/runtime/products.html). Keep the server
running while using the app. For another port, use
`python3 scripts/serve.py --port 4180`.

## Build your own house with an agent

Start with [GUIDE.md](docs/GUIDE.md) for the homeowner walkthrough. The guide covers
staged intake, name-based product research, model reviews and final delivery.

1. Give your agent the packaged starter ZIP or source checkout. The ZIP excludes
   `node_modules`; the agent installs dependencies with `npm ci`.
2. Copy [BUILD_PROMPT.txt](BUILD_PROMPT.txt) (also displayed in [BUILD_PROMPT.md](docs/BUILD_PROMPT.md)) into your coding agent.
3. Supply the plans, measurements and selections you have. The agent asks for
   missing critical information, researches products and authors the scene.
4. Review the resulting model and provide corrections. The agent preserves the
   viewer UI while adapting the house, materials, products and media.

A furniture or lighting **name is enough to start**. Links, SKU/variant, finishes,
dimensions and reference photos improve the result. You do not need to provide
3D furniture files. The agent researches specifications and imagery, builds a
dimensioned procedural model, previews it and refines it before placement.

[INPUTS.md](docs/INPUTS.md) explains the staged questionnaire. The agent maintains
completed records in `project/input.json`, `project/sources.json`,
`project/decisions.json` and `project/progress.json`. The optional
[house-app-builder skill](skills/house-app-builder/SKILL.md) wraps the same
workflow for agents that support skills. Keep the starter checkout available
when using the skill; it does not contain the application by itself.

## What is included

- 3D and Plan views, orbit/pan/zoom, rotation, cutaway, layers and Day/Night.
- Product/material catalog inspection, live product previews and camera focus.
- Rearrange with dimensions, rotation, duplicate/delete, undo/redo and reset.
- Snapshot preview/save, project-link sharing, Gallery, audio, TV and fireplace
  interactions, reflective mirror and project information.
- Responsive controls for desktop, phone portrait and landscape.
- A synthetic eight-product library, four materials and a compact demo home.

[APP_SPEC.md](docs/APP_SPEC.md) defines behavior and scope;
[SCENE_CONTRACT.md](docs/SCENE_CONTRACT.md) defines code interfaces;
[WORKFLOW.md](docs/WORKFLOW.md) describes the build sequence;
[VALIDATION.md](docs/VALIDATION.md) contains completion checks.

This is an illustrative, dimension-calibrated visualization. It does not
automatically parse arbitrary plans, produce construction documents or simulate
certified lighting. A receiving agent needs file-editing, image/PDF inspection,
web research and browser-testing capabilities to carry out the full workflow.
Multi-level homes require extending the scene and visibility rules.

## Project layout

| Folder/file | Contents |
|---|---|
| `index.html` | Main demo entry point |
| `runtime/` | Prebuilt browser outputs and `build-manifest.json` |
| `src/` | JavaScript, CSS and product-page sources; geometry helpers in `src/scene/` |
| `docs/` | Homeowner guide, specifications and technical workflow |
| `project/` | Demo brief, intake templates and source/decision/progress records |
| `assets/` | Material images, product thumbnails, Gallery and media |
| `scripts/` | Serving, building, verification, packaging and asset tools |
| `references/` | Geometry examples and project review evidence |

## Edit and rebuild

Editing/building and automated checks require Node.js 22 or newer, npm and
Python 3.10 or newer. The agent installs the locked dependencies and rebuilds:

```sh
npm ci
npm run build
```

Edit source files under `src/` and project data under `project/`; rebuild after
changes to source or imported assets. Generated browser files live in `runtime/`.
The product page is served at `/runtime/products.html`. Run commands from the
starter root, beside this README.

## Files to adapt

| File | Purpose |
|---|---|
| `src/project-config.js` | Identity, labels, product/material metadata and media paths |
| `project/demo-brief.json` | The supplied fictional demo house data |
| `project/input-template.json` | Intake record to complete for your house; not a runtime config |
| `project/sources.json` | Source evidence, selected variants and explicit estimates |
| `src/model.js` | House geometry, openings, cabinetry, placement and feature bindings |
| `src/product-library.js` | Authored product geometry, finish ownership and suspension |
| `src/media-assets.js`, `src/product-thumbnails.js`, `assets/` | Static image imports and project media |

Use real meters for model coordinates; `projectConfig.units` controls displayed
dimensions only. House materials and product finishes are independent.

## Verify and package

```sh
npm run check
npm run build:deployment
npm run package:starter
```

`build:deployment` creates a static deployment folder. The packaging command
creates a shareable starter archive. See each command's output for its path.
Review the source and run the packaged copy before sharing it.

Browser checks use Playwright. Install its Chromium browser once:

```sh
npx playwright install chromium
npm run visual:smoke
```

The server must be running for visual checks. Capture results and browser
requirements are explained in [VALIDATION.md](docs/VALIDATION.md).

## Regenerate demo assets

Bundled assets are ready to use. Image and WAV regeneration uses only Python's
standard library:

```sh
python3 scripts/generate-demo-assets.py
```

Without an encoder, this leaves the bundled MP4 files unchanged. To regenerate
short original videos using an ffmpeg executable with `libx264`:

```sh
python3 scripts/generate-demo-assets.py --ffmpeg /path/to/ffmpeg
```

Render thumbnails directly from the actual product geometry with Node:

```sh
npm run render:thumbnails
```

This software rendering command needs no browser; its lighting is illustrative.
The optional `scripts/capture-product-thumbnails.mjs` uses a running browser to
capture WebGL thumbnails. Run the app build after changing static assets.
On macOS, `xcrun swift scripts/encode-demo-video.swift assets/video/demo-day.mp4 day`
(and the matching night command) provides an additional video regeneration path.

## Sharing behavior

Set `projectConfig.shareUrl` to your deployed page URL. When it is `null`, Share
uses the current page URL. A local development URL is useful only on the machine
running the server. Share sends a project link; arrangement edits remain in the
current session, and the link does not encode them. Save image exports their
visual result as a PNG.

Repository publication and hosted demo setup are separate release steps. This
package works from an attached/local folder now and does not depend on a
particular repository URL.

## Maintain the build prompt

Edit the canonical `BUILD_PROMPT.txt`, then run `npm run docs:sync` to regenerate
its Markdown view. This keeps the copy/paste text and readable guide link aligned.

## Include the starter download in the deployed demo

For this prepared neutral starter demo, use:

```sh
npm run build
npm run build:demo
```

The resulting `dist` includes `downloads/house-app-starter-0.1.0.zip` and
`downloads/BUILD_PROMPT.txt`. The ZIP and prompt are verified as a pair and are
served when visitors follow their links; the viewer does not load them on startup.
`downloads-manifest.json` verifies their hashes alongside the app deployment.

Ordinary `npm run build:deployment` produces a runtime-only house website. For a
customized house that should offer the original neutral starter, supply the
frozen original ZIP explicitly:

```sh
npm run build:deployment -- --starter-pack /path/to/house-app-starter-0.1.0.zip
```

That command extracts the matching prompt from the supplied ZIP. Use
`build:demo` when publishing the prepared neutral starter itself; use the frozen
starter option for a personal house so its own source/records do not become the
public starter download. Release downloads remain outside the source ZIP to
avoid embedding the archive inside itself.
