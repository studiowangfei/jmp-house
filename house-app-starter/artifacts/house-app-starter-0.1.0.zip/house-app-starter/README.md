# House App Starter

A runnable starter for an interactive house visualization. It pairs the viewer
with a copy/paste prompt that guides a coding agent through collecting your
plans, researching your furniture and materials, authoring the model and
delivering your own build.

The bundled home, product designs, textures, artwork, audio and videos are
independently authored fictional examples. Replace them with your project.

## Start the demo

Requirements: Node.js 22 or newer, npm, and Python 3.10 or newer.

```sh
npm ci
npm run build
npm run serve
```

Open `http://127.0.0.1:4175/` for the house and
`http://127.0.0.1:4175/products.html` for product previews. Keep the server running
while using the app. The server command also accepts `--port` through npm, for
example `npm run serve -- --port 4180`.

## Build your own house with an agent

Start with [GUIDE.md](GUIDE.md) for the homeowner walkthrough. The guide covers
staged intake, name-based product research, model reviews and final delivery.

1. Give your agent the packaged starter ZIP or source checkout. The ZIP excludes
   `node_modules`; the agent installs dependencies with `npm ci`.
2. Copy [BUILD_PROMPT.txt](BUILD_PROMPT.txt) (also displayed in [BUILD_PROMPT.md](BUILD_PROMPT.md)) into your coding agent.
3. Supply the plans, measurements and selections you have. The agent asks for
   missing critical information, researches products and authors the scene.
4. Review the resulting model and provide corrections. The agent preserves the
   viewer UI while adapting the house, materials, products and media.

A furniture or lighting **name is enough to start**. Links, SKU/variant, finishes,
dimensions and reference photos improve the result. You do not need to provide
3D furniture files. The agent researches specifications and imagery, builds a
dimensioned procedural model, previews it and refines it before placement.

[INPUTS.md](INPUTS.md) explains the staged questionnaire. The agent maintains
completed records in `project/input.json`, `project/sources.json`,
`project/decisions.json` and `project/progress.json`. The optional
[house-app-builder skill](skills/house-app-builder/SKILL.md) wraps the same
workflow for agents that support skills. Keep the starter checkout available
when using the skill; it does not contain the application by itself.

## What is included

- 3D and Plan views, orbit/pan/zoom, rotation, cutaway, layers and Day/Night.
- Product/material catalog inspection, live product previews and camera focus.
- Rearrange with dimensions, rotation, duplicate/delete, undo/redo and reset.
- Snapshot preview/save, project-link sharing, Gallery, audio, TV and fireplace
  interactions, reflective mirror and project information.
- Responsive controls for desktop, phone portrait and landscape.
- A synthetic eight-product library, four materials and a compact demo home.

[APP_SPEC.md](APP_SPEC.md) defines behavior and scope;
[SCENE_CONTRACT.md](SCENE_CONTRACT.md) defines code interfaces;
[WORKFLOW.md](WORKFLOW.md) describes the build sequence;
[VALIDATION.md](VALIDATION.md) contains completion checks.

This is an illustrative, dimension-calibrated visualization. It does not
automatically parse arbitrary plans, produce construction documents or simulate
certified lighting. A receiving agent needs file-editing, image/PDF inspection,
web research and browser-testing capabilities to carry out the full workflow.
Multi-level homes require extending the scene and visibility rules.

## Files to adapt

| File | Purpose |
|---|---|
| `project-config.js` | Identity, labels, product/material metadata and media paths |
| `project/demo-brief.json` | The supplied fictional demo house data |
| `project/input-template.json` | Intake record to complete for your house; not a runtime config |
| `project/sources.json` | Source evidence, selected variants and explicit estimates |
| `model.js` | House geometry, openings, cabinetry, placement and feature bindings |
| `product-library.js` | Authored product geometry, finish ownership and suspension |
| `media-assets.js`, `product-thumbnails.js`, `assets/` | Static image imports and project media |

Use real meters for model coordinates; `projectConfig.units` controls displayed
dimensions only. House materials and product finishes are independent.

## Verify and package

```sh
npm run check
npm run build:deployment
npm run package:starter
```

`build:deployment` creates a static deployment folder. The packaging command
creates a shareable starter archive. See each command's output for its path.
Review the source and run the packaged copy before sharing it.

Browser checks use Playwright. Install its Chromium browser once:

```sh
npx playwright install chromium
npm run visual:smoke
```

The server must be running for visual checks. Capture results and browser
requirements are explained in [VALIDATION.md](VALIDATION.md).

## Regenerate demo assets

Bundled assets are ready to use. Image and WAV regeneration uses only Python's
standard library:

```sh
python3 scripts/generate-demo-assets.py
```

Without an encoder, this leaves the bundled MP4 files unchanged. To regenerate
short original videos using an ffmpeg executable with `libx264`:

```sh
python3 scripts/generate-demo-assets.py --ffmpeg /path/to/ffmpeg
```

Render thumbnails directly from the actual product geometry with Node:

```sh
npm run render:thumbnails
```

This software rendering command needs no browser; its lighting is illustrative.
The optional `scripts/capture-product-thumbnails.mjs` uses a running browser to
capture WebGL thumbnails. Run the app build after changing static assets.
On macOS, `xcrun swift scripts/encode-demo-video.swift assets/video/demo-day.mp4 day`
(and the matching night command) provides an additional video regeneration path.

## Sharing behavior

Set `projectConfig.shareUrl` to your deployed page URL. When it is `null`, Share
uses the current page URL. A local development URL is useful only on the machine
running the server. Share sends a project link; arrangement edits remain in the
current session, and the link does not encode them. Save image exports their
visual result as a PNG.

Repository publication and hosted demo setup are separate release steps. This
package works from an attached/local folder now and does not depend on a
particular repository URL.

## Maintain the build prompt

Edit the canonical `BUILD_PROMPT.txt`, then run `npm run docs:sync` to regenerate
its Markdown view. This keeps the copy/paste text and readable guide link aligned.
