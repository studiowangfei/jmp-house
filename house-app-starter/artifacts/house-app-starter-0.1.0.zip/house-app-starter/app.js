import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { buildHouse } from './model.js';
import {productCatalog,createProduct,disposeProduct} from './product-library.js';
import {productThumbnailSources} from './product-thumbnails.js';
import {materialCatalog} from './catalog-data.js';
import {optimizeGalleryFrameRails,optimizeStaticScene} from './performance-optimizations.js';
import {formatDimension,formatProductDimensions} from './dimensions.js';
import {createGalleryGenieTransition} from './gallery-genie.js';
import {updateSpeakerPlaybackVisual} from './speaker-playback.js';
import {createArrangeSurfaceGrid} from './arrange-grid.js';
import {wallAxes,constrainWallPosition} from './arrangement-constraints.js';
import {collectInteractionTargets,galleryPhotoForHit} from './scene-interactions.js';
import {createCenteredSnapshotCamera} from './snapshot-camera.js';
import {captureCanvasAtAspect} from './snapshot-capture.js';
import {createRetroTvStaticTexture,createTvVideoTransitionController,setRetroTvStaticFrame} from './tv-video-transition.js';
import {chooseProductFocusOffset,productFocusBounds,productFocusMinimumVerticalRatio,productFocusZoom} from './product-focus.js';
import {createNightViewController,createNightShelfLighting} from './night-view.js';
import {createNightWallFrameLighting} from './night-wall-frame-lighting.js';
import {toggleFireplaceFire} from './fireplace-control.js';
import {galleryDisplaySources,galleryFullSources,galleryPreviewSources,materialImageSources,fireplaceFireImage} from './media-assets.js';
import {projectConfig} from './project-config.js';
import {materialFocusMinimumVerticalRatio,materialFocusTargets,objectMatchesMaterialAsset} from './material-focus.js';
import {materialFocusPreset} from './material-focus-presets.js';
import {createHomeView,createDaylightFrame} from './default-view.js';
import {createEmbeddedHostBridge} from './embedded-host-bridge.js';
const embeddedHostBridge=createEmbeddedHostBridge();
const performanceMode=new URLSearchParams(location.search).get('performance')!=='legacy';
const scriptBase=new URL('.',document.currentScript?.src||location.href);
const assetUrl=name=>new URL(`assets/${name}`,scriptBase).href;
const galleryPhotos=galleryFullSources.map((src,index)=>({index,src,thumbnailSrc:galleryPreviewSources[index],label:projectConfig.media?.gallery?.[index]?.alt||`Gallery photo ${index+1}`}));
document.title=projectConfig.title;
document.querySelector('#project-title').textContent=projectConfig.title;
document.querySelector('#project-description').textContent=projectConfig.description;
const startupTextureTasks=[...Object.keys(materialImageSources).map(key=>`texture-material-${key}`),'texture-fireplace',...galleryPreviewSources.map((_,index)=>`texture-gallery-preview-${index+1}`)];
const appLoadingTasks=new Map(['model',...startupTextureTasks,'tv-video','night-view','first-frame'].map(id=>[id,false]));
const appLoader=document.querySelector('#app-loader'),appLoaderMeter=document.querySelector('#app-loader-meter'),appLoaderFill=document.querySelector('#app-loader-fill'),appLoaderPercent=document.querySelector('#app-loader-percent'),appLoaderMessage=document.querySelector('#app-loader-message'),appShell=document.querySelector('.app-shell');
const appLoadingTimeScale=1.5,appLoadingStartedAt=performance.now(),appLoadingErrors=[];let appLoadingDisplayedPercent=0,appLoadingCompletionFrame=0,appLoadingReadyForFrame=false,appLoadingRevealScheduled=false,appLoadingFinished=false;
function displayAppLoadingPercent(percent,{updateFill=true}={}){
 appLoadingDisplayedPercent=percent;if(updateFill)appLoaderFill.style.transform=`scaleX(${percent/100})`;
 appLoaderPercent.value=`${percent}%`;appLoaderPercent.textContent=`${percent}%`;appLoaderMeter.setAttribute('aria-valuenow',String(percent));appLoaderMeter.setAttribute('aria-valuetext',`${percent}% loaded`);
}
function finishAppLoadingProgress(){
 if(appLoadingCompletionFrame||appLoadingRevealScheduled)return;
 const reducedMotion=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
 const duration=reducedMotion?0:Math.min(3000,Math.max(270,(performance.now()-appLoadingStartedAt)*(appLoadingTimeScale-1)));
 if(!duration){displayAppLoadingPercent(100);revealLoadedApp();return;}
 const from=appLoadingDisplayedPercent,start=performance.now();appLoaderFill.style.transitionDuration=`${duration}ms`;appLoaderFill.style.transform='scaleX(1)';
 const advance=now=>{
  const progress=Math.min(1,(now-start)/duration),percent=Math.min(100,Math.floor(from+(100-from)*progress));displayAppLoadingPercent(percent,{updateFill:false});
  if(progress<1)appLoadingCompletionFrame=requestAnimationFrame(advance);else{appLoadingCompletionFrame=0;displayAppLoadingPercent(100,{updateFill:false});revealLoadedApp();}
 };
 appLoadingCompletionFrame=requestAnimationFrame(advance);
}
function updateAppLoadingProgress(){
 const complete=[...appLoadingTasks.values()].filter(Boolean).length,percent=Math.round(complete/appLoadingTasks.size*100);
 if(percent===100)finishAppLoadingProgress();else displayAppLoadingPercent(percent);
}
function requestAppLoadingFinalFrame(){
 if(appLoadingReadyForFrame||appLoadingTasks.get('first-frame'))return;
 const ready=[...appLoadingTasks].every(([id,done])=>id==='first-frame'||done);if(!ready)return;
 appLoadingReadyForFrame=true;prepareIntroCameraPose();invalidateReflectors();invalidateShadows();requestMainRender();
}
function settleAppLoadingTask(id,error=null){
 if(!appLoadingTasks.has(id)||appLoadingTasks.get(id))return;
 appLoadingTasks.set(id,true);
 if(error){appLoadingErrors.push({id,error});console.warn(`Startup asset ${id} could not be prepared; continuing with its fallback.`,error);appLoaderMessage.hidden=false;appLoaderMessage.textContent='Some media will continue loading after the model appears.';}
 updateAppLoadingProgress();if(id!=='first-frame')requestAppLoadingFinalFrame();
}
function revealLoadedApp(){
 if(appLoadingRevealScheduled)return;appLoadingRevealScheduled=true;
 requestAnimationFrame(()=>{
  document.documentElement.classList.remove('app-loading');document.documentElement.classList.add('app-ready');
  appShell.removeAttribute('inert');appShell.setAttribute('aria-busy','false');appLoadingFinished=true;
  startIntroCamera({prepared:true});scheduleNightProgramWarmup(false);requestMainRender();
  setTimeout(()=>{appLoader.hidden=true;},450);
 });
}
updateAppLoadingProgress();
let requestMainRender=()=>{},invalidateShadows=()=>{},galleryGenieTransition=null,tvPlaybackAllowed=()=>true,speakerAnimationAllowed=()=>true,appInViewport=!performanceMode||!('IntersectionObserver' in window),startupNightWarmupPending=performanceMode;
const afterMainRenderCallbacks=new Set();
const afterMainRender=callback=>{afterMainRenderCallbacks.add(callback);requestMainRender();return callback;};
const cancelAfterMainRender=callback=>afterMainRenderCallbacks.delete(callback);
const completeAfterMainRender=now=>{const callbacks=[...afterMainRenderCallbacks];afterMainRenderCallbacks.clear();for(const callback of callbacks)callback(now);};
const mount=document.querySelector('#scene');
const scene=new THREE.Scene();scene.background=new THREE.Color('#f7f5f0');
const renderer=new THREE.WebGLRenderer({antialias:true});
const fullPixelRatio=Math.min(devicePixelRatio||1,2),motionPixelRatio=Math.min(fullPixelRatio,window.matchMedia?.('(pointer: coarse)')?.matches?1.25:1.5),motionQualityReasons=new Set();let desiredRendererPixelRatio=fullPixelRatio,motionReflectors=[],motionQualityActive=false,mirrorMotionQualityActive=false;
renderer.setPixelRatio(fullPixelRatio);renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFShadowMap;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1;
renderer.domElement.setAttribute('aria-label',`${projectConfig.title} interactive house model`);renderer.domElement.tabIndex=0;mount.appendChild(renderer.domElement);
const camera=new THREE.OrthographicCamera(-10,10,10,-10,.1,500);
const controls=new OrbitControls(camera,renderer.domElement);
controls.enableDamping=true;controls.minZoom=.45;controls.maxZoom=15;controls.maxPolarAngle=Math.PI/2;
const tvVideo=document.createElement('video');
tvVideo.muted=true;tvVideo.defaultMuted=true;tvVideo.loop=true;tvVideo.autoplay=true;tvVideo.playsInline=true;tvVideo.preload='auto';tvVideo.disablePictureInPicture=true;
for(const attribute of ['muted','autoplay','loop','playsinline','webkit-playsinline'])tvVideo.setAttribute(attribute,'');
tvVideo.setAttribute('aria-hidden','true');
// iOS may decline muted autoplay for a fully transparent/non-rendered element,
// even when the element is only a source for a WebGL VideoTexture. Keep a tiny,
// practically invisible on-screen box so WebKit considers the media visible.
Object.assign(tvVideo.style,{position:'fixed',top:'0',left:'0',width:'2px',height:'2px',opacity:'.001',pointerEvents:'none'});
document.body.appendChild(tvVideo);
const tvVideoTexture=new THREE.VideoTexture(tvVideo);
tvVideoTexture.colorSpace=THREE.SRGBColorSpace;tvVideoTexture.minFilter=THREE.LinearFilter;tvVideoTexture.magFilter=THREE.LinearFilter;tvVideoTexture.generateMipmaps=false;
function cropTvVideoToScreen(){
 const videoAspect=tvVideo.videoWidth/tvVideo.videoHeight,screenAspect=bindings.tv?.aspect||(bindings.tv?.display?.geometry?.parameters?.width||16)/(bindings.tv?.display?.geometry?.parameters?.height||9);
 tvVideoTexture.repeat.set(1,1);tvVideoTexture.offset.set(0,0);
 if(videoAspect>screenAspect){tvVideoTexture.repeat.x=screenAspect/videoAspect;tvVideoTexture.offset.x=(1-tvVideoTexture.repeat.x)/2;}
 else if(videoAspect<screenAspect){tvVideoTexture.repeat.y=videoAspect/screenAspect;tvVideoTexture.offset.y=(1-tvVideoTexture.repeat.y)/2;}
 tvVideoTexture.needsUpdate=true;
 requestMainRender();
}
tvVideo.addEventListener('loadedmetadata',cropTvVideoToScreen);
let tvStartupDeadline=0;
function settleTvStartup(error=null){clearTimeout(tvStartupDeadline);tvStartupDeadline=0;settleAppLoadingTask('tv-video',error);}
function checkTvStartupReady(){if(tvVideo.readyState>=HTMLMediaElement.HAVE_CURRENT_DATA)settleTvStartup();}
for(const event of ['loadeddata','canplay'])tvVideo.addEventListener(event,checkTvStartupReady);
tvVideo.addEventListener('error',()=>settleTvStartup(tvVideo.error||new Error('TV video failed to load.')));
function armTvStartupDeadline(){
 if(appLoadingTasks.get('tv-video')||document.hidden)return;
 clearTimeout(tvStartupDeadline);tvStartupDeadline=setTimeout(()=>settleTvStartup(new Error('TV video startup timed out.')),3000);
}
document.addEventListener('visibilitychange',()=>{if(!document.hidden)armTvStartupDeadline();else{clearTimeout(tvStartupDeadline);tvStartupDeadline=0;}});
const tvVideoSources={day:projectConfig.media?.tv?.day?assetUrl(projectConfig.media.tv.day):null,night:projectConfig.media?.tv?.night?assetUrl(projectConfig.media.tv.night):null};
let tvVideoLightingMode='day';tvVideo.dataset.lightingMode=tvVideoLightingMode;
if(tvVideoSources.day){tvVideo.src=tvVideoSources.day;tvVideo.load();checkTvStartupReady();armTvStartupDeadline();}else settleTvStartup();
const textureLoader=new THREE.TextureLoader();
const loadTexture=(url,onLoad,taskId)=>{
 let taskSettled=false;
 const settle=(error=null)=>{if(taskSettled)return;taskSettled=true;clearTimeout(timeout);settleAppLoadingTask(taskId,error);};
 const timeout=taskId?setTimeout(()=>settle(new Error('Texture decode timed out.')),6000):0;
 return textureLoader.load(url,texture=>{
  let decoded;
  try{onLoad?.(texture);decoded=texture.image?.decode?.();}catch(error){settle(error);requestMainRender();return;}
  if(decoded?.then)decoded.then(()=>settle()).catch(settle);else settle();
  requestMainRender();
 },undefined,error=>settle(error||new Error('Texture failed to load.')));
};
const materialTextures=Object.fromEntries(Object.entries(materialImageSources).map(([key,image])=>{
 const texture=loadTexture(image,null,`texture-material-${key}`);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());return[key,texture];
}));
const fireplaceFireTexture=loadTexture(fireplaceFireImage,null,'texture-fireplace');
// Use one clamped illustration. The flame plane's UVs apply a bottom-aligned
// cover crop after plan calibration, so nothing is tiled, mirrored or warped.
fireplaceFireTexture.colorSpace=THREE.SRGBColorSpace;fireplaceFireTexture.wrapS=THREE.ClampToEdgeWrapping;fireplaceFireTexture.wrapT=THREE.ClampToEdgeWrapping;
fireplaceFireTexture.repeat.set(1,1);fireplaceFireTexture.offset.set(0,0);
fireplaceFireTexture.minFilter=THREE.LinearFilter;fireplaceFireTexture.magFilter=THREE.LinearFilter;fireplaceFireTexture.generateMipmaps=false;fireplaceFireTexture.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());
const galleryPreviewTextures=galleryPreviewSources.map((source,index)=>loadTexture(source,texture=>{texture.colorSpace=THREE.SRGBColorSpace;},`texture-gallery-preview-${index+1}`));
const galleryTextures=galleryDisplaySources.map(()=>{const texture=new THREE.Texture();texture.colorSpace=THREE.SRGBColorSpace;return texture;});let galleryTexturesRequested=false;
function ensureGalleryTexturesLoaded(){
 if(galleryTexturesRequested)return;galleryTexturesRequested=true;
 galleryDisplaySources.forEach((source,index)=>textureLoader.load(source,loaded=>{const target=galleryTextures[index];target.image=loaded.image;target.colorSpace=THREE.SRGBColorSpace;target.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());target.needsUpdate=true;requestMainRender();}));
}
for(const texture of galleryPreviewTextures){texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());}
const {layers,exterior,glazingGroups,wallSchedule=[],movementBoundary=[],animators=[],animatedRoots=[],reflectors=[],materials:modelMaterials={},bindings={}}=buildHouse(THREE,{project:projectConfig,materialTextures,tvVideoTexture,fireplaceFireTexture});
const houseBounds=new THREE.Box3().setFromObject(layers.architecture);
const AXON_HOME_VIEW=createHomeView(THREE,houseBounds,projectConfig.camera);
camera.far=Math.max(150,new THREE.Vector3(...AXON_HOME_VIEW.offset).length()*2+houseBounds.getSize(new THREE.Vector3()).length()*2);
motionReflectors=reflectors;
function setSceneMotionQuality(reason,active){
 if(active)motionQualityReasons.add(reason);else motionQualityReasons.delete(reason);
 const moving=motionQualityReasons.size>0,mirrorMoving=[...motionQualityReasons].some(value=>value!=='scene-animation'),targetRatio=moving?motionPixelRatio:fullPixelRatio,qualityChanged=moving!==motionQualityActive,mirrorQualityChanged=mirrorMoving!==mirrorMotionQualityActive;motionQualityActive=moving;mirrorMotionQualityActive=mirrorMoving;
 if(mirrorQualityChanged)for(const {mirror} of motionReflectors)mirror.setMotionQuality?.(mirrorMoving);
 const pixelRatioChanged=Math.abs(desiredRendererPixelRatio-targetRatio)>=.01;desiredRendererPixelRatio=targetRatio;
 if(qualityChanged||mirrorQualityChanged||pixelRatioChanged)requestMainRender();
}
// Changing WebGL drawing-buffer size clears the canvas. Apply queued quality
// changes only inside a render frame so the same frame immediately repaints it.
function applySceneRenderQuality(){if(Math.abs(renderer.getPixelRatio()-desiredRendererPixelRatio)>=.01)renderer.setPixelRatio(desiredRendererPixelRatio);}
const invalidateReflectors=()=>{for(const {mirror} of reflectors)mirror.invalidateReflection?.();};
const setReflectorRefreshThrottled=active=>{for(const {mirror} of reflectors)mirror.setRefreshThrottled?.(active);};
const reducedMotionQuery=window.matchMedia?.('(prefers-reduced-motion: reduce)');
const mediaScreen=bindings.tv?.screen||null;
const mediaVideoDisplay=bindings.tv?.display||null;
const mediaScreenFocus=mediaScreen?new THREE.Box3().setFromObject(mediaScreen).getCenter(new THREE.Vector3()):null;
const retroTvStaticTexture=mediaVideoDisplay?createRetroTvStaticTexture(THREE):null;
const retroTvStaticMaterial=mediaVideoDisplay?mediaVideoDisplay.material.clone():null;
if(retroTvStaticMaterial){retroTvStaticMaterial.name='Retro TV transition material';retroTvStaticMaterial.map=retroTvStaticTexture;retroTvStaticMaterial.userData={effect:'temporary retro CRT static',sharedScreenMesh:true};}
const tvVideoTransition=mediaVideoDisplay?createTvVideoTransitionController({video:tvVideo,display:mediaVideoDisplay,videoMaterial:mediaVideoDisplay.material,staticMaterial:retroTvStaticMaterial,videoTexture:tvVideoTexture,staticTexture:retroTvStaticTexture,requestRender:()=>requestMainRender(),paintStaticFrame:index=>{const frame=setRetroTvStaticFrame(retroTvStaticTexture,index);tvVideo.dataset.staticFrame=String(frame);return frame;},staticFrameCount:4,staticFrameIntervalMs:100,staticAnimationDurationMs:650,staticBrightness:.8,reducedMotion:()=>Boolean(reducedMotionQuery?.matches),present:afterMainRender,cancelPresent:cancelAfterMainRender,onStateChange:state=>{tvVideo.dataset.transition=state;},minimumVisibleMs:650}):null;
const arrangeSurfaceGrid=createArrangeSurfaceGrid(THREE,{layers,wallSchedule,movementBoundary,exterior});scene.add(arrangeSurfaceGrid.group);
const nightShelfLighting=createNightShelfLighting(THREE,layers.cabinetry);
const nightFrameLighting=createNightWallFrameLighting(THREE,layers.furniture,layers.architecture);
if(performanceMode)scene.userData.performanceOptimization=optimizeStaticScene(THREE,{layers,exterior,glazingGroups,animatedRoots,preserveMovableFurniture:true});
const galleryPhotoMeshes=[],modelInteractionMeshes=[];
const galleryGrid=bindings.gallery?.root||null;
if(galleryGrid){
 const frames=bindings.gallery.frames||[];
 if(performanceMode)optimizeGalleryFrameRails(THREE,galleryGrid);
 const {frameSize=.32,rail=.014,photoPadding=.04,frameDepth=.025}=bindings.gallery,matSize=frameSize-rail*2,photoSize=matSize-photoPadding*2;
 const geometry=new THREE.PlaneGeometry(photoSize,photoSize),matGeometry=new THREE.PlaneGeometry(matSize,matSize),hitGeometry=new THREE.PlaneGeometry(frameSize,frameSize),matMaterial=new THREE.MeshBasicMaterial({color:'#f7f5f0',side:THREE.DoubleSide,toneMapped:false}),hitMaterial=new THREE.MeshBasicMaterial({visible:false,side:THREE.DoubleSide});
 const materials=galleryPreviewTextures.map(texture=>new THREE.MeshBasicMaterial({color:'#ffffff',map:texture,side:THREE.DoubleSide,toneMapped:false}));
 frames.forEach((frame,index)=>{
  const galleryIndex=frame.userData.galleryFrame?.index??index;
  const mat=new THREE.Mesh(matGeometry,matMaterial);mat.name=`Gallery mat ${galleryIndex+1}`;mat.position.z=frameDepth/2+.0005;mat.renderOrder=1;frame.add(mat);
  const photo=new THREE.Mesh(geometry,materials[galleryIndex%Math.max(1,materials.length)]||matMaterial);photo.name=`Gallery photo ${galleryIndex+1}`;photo.position.z=frameDepth/2+.001;photo.renderOrder=2;photo.userData.galleryIndex=galleryIndex;photo.userData.galleryPhoto=true;frame.add(photo);galleryPhotoMeshes.push(photo);
  const hitTarget=new THREE.Mesh(hitGeometry,hitMaterial);hitTarget.name=`Gallery frame hit target ${galleryIndex+1}`;hitTarget.position.z=frameDepth/2+.0015;hitTarget.userData.interaction='gallery';hitTarget.userData.galleryIndex=galleryIndex;frame.add(hitTarget);modelInteractionMeshes.push(hitTarget);
 });
}
nightFrameLighting?.syncPositions({force:true});
const audioSpeaker=bindings.audio?.root||null;
if(audioSpeaker){audioSpeaker.userData.audioPlayerTrigger=true;audioSpeaker.traverse(object=>{if(object.isMesh){object.userData.interaction='audio';modelInteractionMeshes.push(object);}});}
const fireplace=bindings.fireplace?.root||null,fireplaceFirebox=bindings.fireplace?.firebox||null,illustratedFlames=bindings.fireplace?.flames||null;
if(fireplaceFirebox&&illustratedFlames)modelInteractionMeshes.push(fireplaceFirebox,illustratedFlames);
Object.values(layers).forEach(g=>scene.add(g));
const treeBases=bindings.landscape?.bases||[];
settleAppLoadingTask('model');
let tvPlayPromise=null,tvAutoplayBlocked=false;
function attemptTvVideoPlayback({userGesture=false}={}){
 if(!tvVideoSources.day)return Promise.resolve(false);
 if(!tvVideo.paused)return Promise.resolve(true);
 if(tvAutoplayBlocked&&!userGesture)return Promise.resolve(false);
 if(tvPlayPromise&&!userGesture)return tvPlayPromise;
 if(userGesture)tvAutoplayBlocked=false;
 tvVideo.muted=true;tvVideo.defaultMuted=true;tvVideo.setAttribute('muted','');
 try{
  const result=tvVideo.play();
  if(!result?.then)return Promise.resolve(true);
  const pending=result.then(()=>{tvAutoplayBlocked=false;return true;}).catch(error=>{
   // NotAllowedError can still occur in iOS Low Power Mode. Gesture retries
   // remain installed until one succeeds; other transient load errors retry on
   // loadeddata/canplay/pageshow without surfacing a broken UI state.
   if(error?.name==='NotAllowedError')tvAutoplayBlocked=true;
   if(userGesture&&error?.name!=='AbortError')console.debug('TV video playback is still awaiting media permission.',error);
   return false;
  });
  tvPlayPromise=pending;pending.finally(()=>{if(tvPlayPromise===pending)tvPlayPromise=null;});return pending;
 }catch(error){return Promise.resolve(false);}
}
function syncTvVideoPlayback(){
 if(document.hidden||!appInViewport||!layers.cabinetry.visible||!tvPlaybackAllowed()){
  if(!tvVideo.paused){tvVideo.pause();requestMainRender();}return;
 }
 if(tvVideo.paused)attemptTvVideoPlayback().then(started=>{if(started)requestMainRender();});
}
function setTvVideoLightingMode(night){
 const mode=night?'night':'day';
 if(tvVideoLightingMode===mode){syncTvVideoPlayback();return false;}
 const source=tvVideoSources[mode]||tvVideoSources.day;if(!source)return false;
 tvVideoLightingMode=mode;tvVideo.dataset.lightingMode=mode;tvVideoTransition?.begin(mode,source);tvVideo.pause();tvVideo.src=source;tvVideo.load();tvVideoTexture.needsUpdate=true;
 attemptTvVideoPlayback({userGesture:true}).then(started=>{
  if(!started)return;
  if(document.hidden||!appInViewport||!layers.cabinetry.visible||!tvPlaybackAllowed())tvVideo.pause();
  else requestMainRender();
 });
 return true;
}
let lastTvGestureAttempt=-Infinity;
function primeTvVideoFromGesture(){
 const now=performance.now();if(now-lastTvGestureAttempt<100)return;lastTvGestureAttempt=now;
 attemptTvVideoPlayback({userGesture:true}).then(started=>{
  if(!started)return;requestMainRender();
  // The gesture exists to unlock WebKit playback. Restore the normal power gate
  // afterward if the TV is currently offscreen, tiny, or behind another view.
  if(document.hidden||!appInViewport||!layers.cabinetry.visible||!tvPlaybackAllowed())tvVideo.pause();
 });
}
for(const event of ['loadeddata','canplay','canplaythrough'])tvVideo.addEventListener(event,syncTvVideoPlayback);
tvVideo.addEventListener('playing',()=>requestMainRender());
document.addEventListener('visibilitychange',syncTvVideoPlayback);
window.addEventListener('pageshow',syncTvVideoPlayback);
window.addEventListener('online',syncTvVideoPlayback);
for(const event of ['pointerdown','pointerup','touchstart','touchend','keydown'])window.addEventListener(event,primeTvVideoFromGesture,{capture:true,passive:true});
syncTvVideoPlayback();

function proceduralMaterialPreview(material){
 const source=material?.map?.image,canvas=document.createElement('canvas');
 canvas.width=source?.width||128;canvas.height=source?.height||128;
 const context=canvas.getContext('2d'),pixels=context.createImageData(canvas.width,canvas.height),tint=material?.color||new THREE.Color('#ffffff');
 const srgbToLinear=value=>value<=.04045?value/12.92:Math.pow((value+.055)/1.055,2.4);
 const linearToSrgb=value=>value<=.0031308?value*12.92:1.055*Math.pow(value,1/2.4)-.055;
 if(source?.data){
  for(let i=0;i<pixels.data.length;i+=4){
   pixels.data[i]=Math.round(255*linearToSrgb(srgbToLinear(source.data[i]/255)*tint.r));
   pixels.data[i+1]=Math.round(255*linearToSrgb(srgbToLinear(source.data[i+1]/255)*tint.g));
   pixels.data[i+2]=Math.round(255*linearToSrgb(srgbToLinear(source.data[i+2]/255)*tint.b));
   pixels.data[i+3]=source.data[i+3]??255;
  }
  context.putImageData(pixels,0,0);
 }else{
  context.fillStyle=`#${tint.clone().convertLinearToSRGB().getHexString()}`;context.fillRect(0,0,canvas.width,canvas.height);
 }
 return canvas.toDataURL('image/png');
}
const materialAssets=Object.fromEntries(materialCatalog.map(material=>[material.assetKey,{key:material.assetKey,image:materialImageSources[material.assetKey]||proceduralMaterialPreview(modelMaterials[material.assetKey]),texture:materialTextures[material.assetKey],material:modelMaterials[material.assetKey]}]));
const displayedProducts=productCatalog.filter(product=>product.catalogVisible!==false);
const displayedMaterials=materialCatalog.filter(material=>materialAssets[material.assetKey]);
const SHARE_URL=projectConfig.shareUrl||location.href.split('?')[0];
const catalogStrip=document.querySelector('.product-strip'),catalogTrack=catalogStrip.querySelector('.catalog-track'),catalogBackdrop=document.querySelector('#catalog-backdrop');
const descriptionControl=document.querySelector('#description-control');
const descriptionCell=document.querySelector('#description-cell');
const descriptionContent=document.querySelector('#description-content');
const descriptionToggle=document.querySelector('#description-toggle');
const audioControl=document.querySelector('#audio-control');
const audioToggle=document.querySelector('#audio-toggle');
const audioPlayerContent=document.querySelector('#audio-player-content');
const audioPrevious=document.querySelector('#audio-previous');
const audioPlayToggle=document.querySelector('#audio-play-toggle');
const audioNext=document.querySelector('#audio-next');
const audioRepeatToggle=document.querySelector('#audio-repeat-toggle');
const audioProgressLine=document.querySelector('#audio-progress-line');
const audioTrackLabels=[...document.querySelectorAll('.audio-track-label')];
const audioWaveBars=[...audioToggle.querySelectorAll('.audio-wave-bar')];
const viewPanel=document.querySelector('.view-panel'),dayNightToggle=document.querySelector('#day-night-toggle'),layerMenu=document.querySelector('#layer-menu'),layerMenuToggle=document.querySelector('#layer-menu-toggle'),layerControls=document.querySelector('#layer-controls'),layerInputs=[...document.querySelectorAll('[data-layer]')],cutaway=document.querySelector('#cutaway'),desktopHoverQuery=window.matchMedia('(hover: hover) and (pointer: fine)');
const arrangeControl=document.querySelector('#arrange-control'),arrangeToggle=document.querySelector('#arrange-toggle'),arrangeActions=document.querySelector('#arrange-actions'),arrangeUndo=document.querySelector('#arrange-undo'),arrangeRedo=document.querySelector('#arrange-redo'),arrangeSnapshot=document.querySelector('#arrange-snapshot');
const mobileControlTouchQuery=window.matchMedia('(hover: none), (pointer: coarse)'),mobileControlHapticTargets=[];let arrangeHapticSwitch=null;
const arrangeItemControls=document.querySelector('#arrange-item-controls'),arrangeRotateLeft=document.querySelector('#arrange-rotate-left'),arrangeRotateRight=document.querySelector('#arrange-rotate-right'),arrangeDuplicate=document.querySelector('#arrange-duplicate'),arrangeDelete=document.querySelector('#arrange-delete');
const arrangeDimensions=document.querySelector('#arrange-dimensions'),arrangeDimensionWidth=document.querySelector('#arrange-dimension-width'),arrangeDimensionDepth=document.querySelector('#arrange-dimension-depth'),arrangeDimensionHeight=document.querySelector('#arrange-dimension-height');
const snapshotDialog=document.querySelector('#snapshot-dialog'),snapshotCard=snapshotDialog.querySelector('.snapshot-card'),snapshotImage=document.querySelector('#snapshot-image'),snapshotSave=document.querySelector('#snapshot-save'),snapshotShare=document.querySelector('#snapshot-share'),shareToast=document.querySelector('#share-toast');
const audioTracks=(projectConfig.media?.audio||[]).map(track=>({...track,src:assetUrl(track.file)}));
const audioElement=document.querySelector('#audio-element');
const audioWaveRestHeights=[8,16,10,18,12];
let selectedAudioIndex=0,audioWaveFrame=0,audioWaveLastFrame=0,audioWaveSmoothedHeights=[...audioWaveRestHeights],layerMenuSettleTimer=0,audioHoverOpened=false,soundCellFocusUsed=false;
audioElement.muted=false;audioElement.volume=1;audioElement.loop=false;
if(audioSpeaker)animators.push({
 fps:15,
 isActive:()=>!audioElement.paused&&!audioElement.ended&&layers.furniture.visible&&speakerAnimationAllowed(),
 update:()=>{for(const root of layers.furniture.children.filter(root=>root.userData.audioPlayerTrigger&&!root.userData.arrangeDeleted))updateSpeakerPlaybackVisual(root,{playing:true,currentTime:audioElement.currentTime,reducedMotion:Boolean(reducedMotionQuery?.matches)});},
});
function setLayerMenuOpen(open){
 const expanded=Boolean(open&&viewPanel.classList.contains('is-layer-compact'));clearTimeout(layerMenuSettleTimer);layerMenuSettleTimer=0;layerMenu.classList.remove('is-settled');layerMenu.classList.toggle('is-open',expanded);layerMenuToggle.setAttribute('aria-expanded',String(expanded));layerControls.setAttribute('aria-hidden',String(viewPanel.classList.contains('is-layer-compact')&&!expanded));
 if(expanded)layerMenuSettleTimer=setTimeout(()=>{if(layerMenu.classList.contains('is-open'))layerMenu.classList.add('is-settled');layerMenuSettleTimer=0;},320);
 layerMenuToggle.setAttribute('aria-label',expanded?'Close layer controls':'Open layer controls');
}
function updateLayerMenuHiddenState(){layerMenuToggle.classList.toggle('has-hidden-layers',cutaway.checked||layerInputs.some(input=>!input.checked));}
updateLayerMenuHiddenState();
function updateLayerControlsLayout(){
 viewPanel.classList.add('is-layer-compact');layerControls.setAttribute('aria-hidden',String(!layerMenu.classList.contains('is-open')));
}
function setAudioWaveBarHeight(bar,height){
 const half=Math.max(1.5,Math.min(9.5,height/2));bar.setAttribute('y1',String(12-half));bar.setAttribute('y2',String(12+half));
}
function resetAudioWaveform(){audioWaveSmoothedHeights=[...audioWaveRestHeights];audioWaveBars.forEach((bar,index)=>setAudioWaveBarHeight(bar,audioWaveRestHeights[index]));}
function stopAudioWaveform(){if(audioWaveFrame)cancelAnimationFrame(audioWaveFrame);audioWaveFrame=0;audioWaveLastFrame=0;resetAudioWaveform();}
function syncAudioProgress(){
 const duration=audioElement.duration,currentTime=audioElement.currentTime;
 const progress=audioElement.readyState>=1&&!audioElement.error&&Number.isFinite(duration)&&duration>0&&Number.isFinite(currentTime)?Math.min(1,Math.max(0,currentTime/duration)):0;
 audioProgressLine.style.setProperty('--audio-progress',String(progress));
}
function renderAudioWaveform(now=performance.now()){
 audioWaveFrame=0;
 if(audioElement.paused||audioElement.ended||document.hidden){resetAudioWaveform();return;}
 if(audioWaveLastFrame&&now-audioWaveLastFrame<1000/30){audioWaveFrame=requestAnimationFrame(renderAudioWaveform);return;}audioWaveLastFrame=now;
 syncAudioProgress();
 audioWaveBars.forEach((bar,index)=>{
  const phase=audioElement.currentTime*(4.6+index*.83)+index*1.31;
  const level=.18+.82*Math.abs(Math.sin(phase)*.72+Math.sin(phase*.43+index)*.28),targetHeight=3+Math.pow(level,.72)*16;
  audioWaveSmoothedHeights[index]+=(targetHeight-audioWaveSmoothedHeights[index])*.42;setAudioWaveBarHeight(bar,audioWaveSmoothedHeights[index]);
 });
 audioWaveFrame=requestAnimationFrame(renderAudioWaveform);
}
function startAudioWaveform(){
 if(window.matchMedia?.('(prefers-reduced-motion: reduce)').matches){resetAudioWaveform();return;}
 if(!audioWaveFrame)audioWaveFrame=requestAnimationFrame(renderAudioWaveform);
}
function syncAudioPlaybackState(){
 const playing=!audioElement.paused&&!audioElement.ended;
 syncAudioProgress();
 audioToggle.setAttribute('aria-pressed',String(playing));audioToggle.setAttribute('aria-label',playing?'Pause Sound':'Play Sound');
 audioPlayToggle.setAttribute('aria-pressed',String(playing));audioPlayToggle.setAttribute('aria-label',`${playing?'Pause':'Play'} ${audioTracks[selectedAudioIndex]?.title||'Sound'}`);
 for(const root of layers.furniture.children.filter(root=>root.userData.audioPlayerTrigger&&!root.userData.arrangeDeleted))updateSpeakerPlaybackVisual(root,{playing,currentTime:audioElement.currentTime,reducedMotion:Boolean(reducedMotionQuery?.matches)});requestMainRender();
 if(playing)startAudioWaveform();else stopAudioWaveform();
}
function playAudio(){
 if(!audioTracks.length)return;
 if(audioElement.ended){audioElement.currentTime=0;syncAudioProgress();}
 audioElement.muted=false;
 const playback=audioElement.play();if(playback)playback.catch(error=>{console.warn('Unable to play local audio.',error);syncAudioPlaybackState();});
}
function resetAudioTrackMarquee(track){
 const text=`${track.title} · ${track.artist}`;
 audioTrackLabels.forEach(label=>{
  label.classList.add('is-marquee-resetting');label.textContent=text;
  // Commit the right-edge start frame before recreating the CSS animation.
  void label.offsetWidth;label.classList.remove('is-marquee-resetting');
 });
}
function selectAudioTrack(index,{resume=false}={}){
 if(!audioTracks.length){audioToggle.disabled=true;audioPlayToggle.disabled=true;audioPrevious.disabled=true;audioNext.disabled=true;return;}
 selectedAudioIndex=(index+audioTracks.length)%audioTracks.length;const track=audioTracks[selectedAudioIndex];
 audioProgressLine.style.setProperty('--audio-progress','0');
 resetAudioTrackMarquee(track);audioElement.src=track.src;audioElement.load();syncAudioPlaybackState();if(resume)playAudio();
}
function setAudioPlayerOpen(open,{hover=false}={}){
 audioHoverOpened=Boolean(open&&hover);
 if(open)setDescriptionOpen(false);
 audioControl.classList.toggle('is-open',open);audioToggle.setAttribute('aria-expanded',String(open));audioPlayerContent.setAttribute('aria-hidden',String(!open));
 syncAudioProgress();
 requestAnimationFrame(updateLayerControlsLayout);
}
function changeAudioTrack(direction){
 if(direction<0&&!audioElement.paused&&!audioElement.ended&&audioElement.currentTime>3){audioElement.currentTime=0;syncAudioProgress();return;}
 selectAudioTrack(selectedAudioIndex+direction,{resume:true});
}
audioToggle.onclick=event=>{
 const startingPlayback=audioElement.paused||audioElement.ended;
 if(event.pointerType==='touch'||!desktopHoverQuery.matches)setAudioPlayerOpen(true);
 toggleAudioPlayback();
 if(startingPlayback&&!soundCellFocusUsed){soundCellFocusUsed=true;focusAudioSpeaker();}
};
audioControl.addEventListener('pointerenter',event=>{if(desktopHoverQuery.matches&&event.pointerType!=='touch'&&!audioControl.classList.contains('is-open'))setAudioPlayerOpen(true,{hover:true});});
audioControl.addEventListener('pointerleave',event=>{if(desktopHoverQuery.matches&&event.pointerType!=='touch'&&audioHoverOpened)setAudioPlayerOpen(false);});
audioPlayerContent.addEventListener('pointerdown',()=>{if(audioHoverOpened)setAudioPlayerOpen(true);},true);
function toggleAudioPlayback(){if(audioElement.paused||audioElement.ended)playAudio();else audioElement.pause();}
audioPlayToggle.onclick=toggleAudioPlayback;
audioPrevious.onclick=()=>changeAudioTrack(-1);
audioNext.onclick=()=>changeAudioTrack(1);
audioRepeatToggle.onclick=()=>{const enabled=!audioElement.loop;audioElement.loop=enabled;audioRepeatToggle.setAttribute('aria-pressed',String(enabled));audioRepeatToggle.setAttribute('aria-description',enabled?'Repeating the current song':'Repeating the whole playlist');};
layerMenuToggle.onclick=()=>setLayerMenuOpen(!layerMenu.classList.contains('is-open'));
layerMenu.addEventListener('pointerenter',event=>{if(desktopHoverQuery.matches&&event.pointerType!=='touch')setLayerMenuOpen(true);});
layerMenu.addEventListener('pointerleave',event=>{if(desktopHoverQuery.matches&&event.pointerType!=='touch')setLayerMenuOpen(false);});
document.addEventListener('pointerdown',event=>{if(descriptionToggle.contains(event.target))return;if(!layerMenu.contains(event.target))setLayerMenuOpen(false);},true);
for(const event of ['play','pause','ended'])audioElement.addEventListener(event,syncAudioPlaybackState);
for(const event of ['loadedmetadata','durationchange','timeupdate','seeking','seeked','loadstart','emptied','error'])audioElement.addEventListener(event,syncAudioProgress);
audioElement.addEventListener('ended',()=>{if(!audioElement.loop&&audioTracks.length)selectAudioTrack(selectedAudioIndex+1,{resume:true});});
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopAudioWaveform();else syncAudioPlaybackState();});
document.addEventListener('keydown',event=>{if(event.key!=='Escape')return;if(layerMenu.classList.contains('is-open')){setLayerMenuOpen(false);layerMenuToggle.focus();}else if(audioControl.classList.contains('is-open')){setAudioPlayerOpen(false);audioToggle.focus();}else if(descriptionControl.classList.contains('is-open')){setDescriptionOpen(false);descriptionToggle.focus();}});
resetAudioWaveform();selectAudioTrack(0);
function updateDescriptionPanelScale(){
 const cellSize=parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--control-cell-size'))||44,width=Math.min(cellSize*8,window.innerWidth-32);descriptionControl.style.setProperty('--description-panel-width',width+'px');
 const height=descriptionContent.scrollHeight+2;descriptionControl.style.setProperty('--description-panel-height',height+'px');
 descriptionControl.style.setProperty('--description-content-scale-x',String(cellSize/width));descriptionControl.style.setProperty('--description-content-scale-y',String(cellSize/height));
}
function setDescriptionOpen(open){
 if(open){setAudioPlayerOpen(false);setLayerMenuOpen(false);}
 updateDescriptionPanelScale();descriptionControl.classList.toggle('is-open',open);descriptionToggle.setAttribute('aria-expanded',String(open));descriptionContent.setAttribute('aria-hidden',String(!open));descriptionContent.inert=!open;
 descriptionToggle.setAttribute('aria-expanded',String(open));descriptionContent.setAttribute('aria-hidden',String(!open));
}
const viewer=document.querySelector('.viewer');
descriptionControl.addEventListener('pointerenter',event=>{if(desktopHoverQuery.matches&&event.pointerType!=='touch')setDescriptionOpen(true);});
descriptionControl.addEventListener('pointerleave',event=>{if(desktopHoverQuery.matches&&event.pointerType!=='touch')setDescriptionOpen(false);});
document.addEventListener('pointerdown',event=>{if(descriptionControl.classList.contains('is-open')&&!descriptionControl.contains(event.target))setDescriptionOpen(false);},true);
document.addEventListener('wheel',()=>{if(descriptionControl.classList.contains('is-open'))setDescriptionOpen(false);},{passive:true});
window.addEventListener('resize',updateDescriptionPanelScale);
document.fonts?.ready.then(updateDescriptionPanelScale);requestAnimationFrame(()=>{updateDescriptionPanelScale();setDescriptionOpen(false);});
let descriptionTogglePointerType='';
descriptionToggle.addEventListener('pointerdown',event=>{descriptionTogglePointerType=event.pointerType;});
descriptionToggle.addEventListener('pointercancel',()=>{descriptionTogglePointerType='';});
descriptionToggle.addEventListener('blur',()=>{descriptionTogglePointerType='';});
descriptionControl.addEventListener('focusout',event=>{if(desktopHoverQuery.matches&&!descriptionControl.contains(event.relatedTarget)&&!descriptionControl.matches(':hover'))setDescriptionOpen(false);});
descriptionToggle.onclick=event=>{
 const pointerType=event.pointerType||descriptionTogglePointerType;descriptionTogglePointerType='';
 if(desktopHoverQuery.matches&&pointerType!=='touch'&&event.detail!==0)return;
 setDescriptionOpen(!descriptionControl.classList.contains('is-open'));
};
renderer.domElement.addEventListener('pointerdown',event=>{setDescriptionOpen(false);setLayerMenuOpen(false);if(modelInteractionAtPointer(event)?.type!=='audio')setAudioPlayerOpen(false);},true);
renderer.domElement.addEventListener('wheel',()=>{setDescriptionOpen(false);setAudioPlayerOpen(false);setLayerMenuOpen(false);},{passive:true});
controls.addEventListener('start',()=>{setDescriptionOpen(false);setAudioPlayerOpen(false);setLayerMenuOpen(false);});
viewPanel.addEventListener('pointerdown',event=>{
 const descriptionTarget=event.target.closest?.('.description-toggle');
 if(!event.target.closest?.('.description-control')&&!descriptionTarget)setDescriptionOpen(false);
 if(!event.target.closest?.('.audio-control')&&!descriptionTarget)setAudioPlayerOpen(false);
 if(!event.target.closest?.('.layer-menu')&&!descriptionTarget)setLayerMenuOpen(false);
},true);
const galleryOverlay=document.querySelector('#gallery-overlay'),galleryStage=document.querySelector('.gallery-stage'),galleryImage=document.querySelector('#gallery-image'),galleryThumbnails=document.querySelector('#gallery-thumbnails'),galleryToggle=document.querySelector('#gallery-toggle'),galleryClose=document.querySelector('#gallery-close');
function reportEmbeddedChildViewState(){
 const open=galleryOverlay.classList.contains('is-open')||snapshotDialog.classList.contains('is-open');
 embeddedHostBridge.setChildViewOpen(open);
}
reportEmbeddedChildViewState();
// Rollback switch: the original DOM animation remains available at
// ?galleryTransition=classic. Invalid and omitted values intentionally use the
// Genie renderer so reverting the default is a one-word change here.
const requestedGalleryTransition=new URLSearchParams(location.search).get('galleryTransition');
const galleryTransitionMode=requestedGalleryTransition==='classic'?'classic':'genie';
const galleryMorphTuning=galleryTransitionMode==='classic'?{overshoot:0,depth:20,arc:2,duration:600}:{stagger:24,squeeze:0,curve:0,duration:450};
function ensureGalleryGenieTransition(){
 if(galleryTransitionMode!=='genie')return null;
 if(!galleryGenieTransition)galleryGenieTransition=createGalleryGenieTransition(THREE,{viewer});
 return galleryGenieTransition;
}
window.addEventListener('pagehide',event=>{gallerySwipeGesture=null;clearGallerySlide();if(!event.persisted)galleryGenieTransition?.dispose();});
let selectedGalleryIndex=0,galleryThumbnailSelectionIndex=0,galleryPendingThumbnailIndex=null,galleryOpener=null,galleryMorphElement=null,galleryMorphAnimation=null,gallerySourcePhoto=null,galleryCrossfadeToken=0,galleryCrossfadeImage=null,galleryCrossfadeAnimations=[],galleryCrossfadePending=false,gallerySlideImages=[],gallerySlideAnimations=[],gallerySlideGeneration=0,gallerySlideSettling=false,gallerySwipeGesture=null;
const galleryPhotoPreloads=new Map();
function disposeGalleryPhotoCrossfade(){
 galleryCrossfadeAnimations.forEach(animation=>animation.cancel());galleryCrossfadeAnimations=[];galleryCrossfadeImage?.remove();galleryCrossfadeImage=null;
}
function clearGalleryPhotoCrossfade(){galleryCrossfadeToken++;galleryCrossfadePending=false;disposeGalleryPhotoCrossfade();}
function wrappedGalleryIndex(index){return(index+galleryPhotos.length)%galleryPhotos.length;}
function preloadGalleryPhoto(index){
 const photo=galleryPhotos[wrappedGalleryIndex(index)];if(galleryPhotoPreloads.has(photo.index))return galleryPhotoPreloads.get(photo.index);
 const image=new Image();image.decoding='async';image.src=photo.src;image.decode?.().catch(()=>{});galleryPhotoPreloads.set(photo.index,image);return image;
}
function preloadSelectedGalleryNeighbors(){preloadGalleryPhoto(selectedGalleryIndex-1);preloadGalleryPhoto(selectedGalleryIndex+1);}
function clearGallerySlide(){
 gallerySlideGeneration++;gallerySlideAnimations.forEach(animation=>animation.cancel());gallerySlideAnimations=[];gallerySlideImages.forEach(image=>image.remove());gallerySlideImages=[];gallerySlideSettling=false;
 galleryStage.classList.remove('is-swiping');galleryImage.style.removeProperty('transform');galleryImage.style.removeProperty('will-change');
 if(galleryPendingThumbnailIndex!==null){galleryPendingThumbnailIndex=null;setGalleryThumbnailSelection(selectedGalleryIndex);}
}
function createGallerySlideImage(index,position,pageWidth){
 const photo=galleryPhotos[wrappedGalleryIndex(index)],image=document.createElement('img');preloadGalleryPhoto(photo.index);image.className='gallery-slide-image';image.src=photo.src;image.alt='';image.setAttribute('aria-hidden','true');image.draggable=false;image.dataset.gallerySlide=position;image.dataset.galleryIndex=String(photo.index);image.style.transform=`translate3d(${position==='previous'?-pageWidth:pageWidth}px,0,0)`;return image;
}
function beginGallerySlide(){
 clearGalleryPhotoCrossfade();clearGallerySlide();const pageWidth=Math.max(1,galleryStage.getBoundingClientRect().width),previous=createGallerySlideImage(selectedGalleryIndex-1,'previous',pageWidth),next=createGallerySlideImage(selectedGalleryIndex+1,'next',pageWidth);
 galleryStage.append(previous,next);gallerySlideImages=[previous,next];galleryStage.classList.add('is-swiping');galleryImage.style.willChange='transform';return{generation:gallerySlideGeneration,pageWidth,previous,next,dx:0};
}
function updateGallerySlide(slide,offset){
 if(!slide||slide.generation!==gallerySlideGeneration)return;const dx=THREE.MathUtils.clamp(offset,-slide.pageWidth,slide.pageWidth);slide.dx=dx;
 galleryImage.style.transform=`translate3d(${dx}px,0,0)`;slide.previous.style.transform=`translate3d(${dx-slide.pageWidth}px,0,0)`;slide.next.style.transform=`translate3d(${dx+slide.pageWidth}px,0,0)`;
}
function settleGallerySlide(slide,{direction=0,velocity=0}={}){
 if(!slide||slide.generation!==gallerySlideGeneration)return;const generation=slide.generation,pageWidth=slide.pageWidth,target=direction>0?-pageWidth:direction<0?pageWidth:0,remaining=Math.abs(target-slide.dx),speed=Math.max(.55,Math.abs(velocity)),duration=reducedMotionQuery?.matches?0:THREE.MathUtils.clamp(remaining/speed*.8,180,360),easing='cubic-bezier(.2,.75,.25,1)',elements=[galleryImage,slide.previous,slide.next],starts=[slide.dx,slide.dx-pageWidth,slide.dx+pageWidth],ends=direction>0?[-pageWidth,-2*pageWidth,0]:direction<0?[pageWidth,0,2*pageWidth]:[0,-pageWidth,pageWidth];
 if(direction){galleryPendingThumbnailIndex=wrappedGalleryIndex(selectedGalleryIndex+direction);setGalleryThumbnailSelection(galleryPendingThumbnailIndex);}
 gallerySlideSettling=true;
 const finish=()=>{
  if(generation!==gallerySlideGeneration)return;
  if(!direction){clearGallerySlide();return;}
  const targetIndex=galleryPendingThumbnailIndex??wrappedGalleryIndex(selectedGalleryIndex+direction);galleryPendingThumbnailIndex=null;selectGalleryPhoto(targetIndex,{preserveSlide:true,syncThumbnail:false});
  const cleanup=()=>requestAnimationFrame(()=>requestAnimationFrame(()=>{if(generation===gallerySlideGeneration)clearGallerySlide();})),decoded=galleryImage.decode?.();
  if(decoded?.then)Promise.race([decoded.catch(()=>{}),new Promise(resolve=>setTimeout(resolve,350))]).then(cleanup);else cleanup();
 };
 if(!duration){elements.forEach((element,index)=>element.style.transform=`translate3d(${ends[index]}px,0,0)`);finish();return;}
 gallerySlideAnimations=elements.map((element,index)=>element.animate([{transform:`translate3d(${starts[index]}px,0,0)`},{transform:`translate3d(${ends[index]}px,0,0)`}],{duration,easing,fill:'forwards'}));
 Promise.allSettled(gallerySlideAnimations.map(animation=>animation.finished)).then(finish);
}
async function crossfadeGalleryPhoto(photo){
 const currentSource=galleryImage.currentSrc||galleryImage.src;if(!currentSource||currentSource===new URL(photo.src,location.href).href||reducedMotionQuery?.matches){clearGalleryPhotoCrossfade();galleryImage.src=photo.src;galleryImage.alt=photo.label;galleryImage.decode?.().catch(()=>{});return;}
 const token=++galleryCrossfadeToken;galleryCrossfadePending=true;disposeGalleryPhotoCrossfade();
 const preload=new Image();preload.src=photo.src;
 try{if(preload.decode)await preload.decode();else if(!preload.complete)await new Promise((resolve,reject)=>{preload.onload=resolve;preload.onerror=reject;});}catch{if(token===galleryCrossfadeToken){galleryCrossfadePending=false;galleryImage.src=photo.src;galleryImage.alt=photo.label;}return;}
 if(token!==galleryCrossfadeToken)return;
 galleryCrossfadePending=false;
 const outgoing=galleryImage.cloneNode(false);outgoing.removeAttribute('id');outgoing.className='gallery-crossfade-outgoing';outgoing.alt='';galleryStage.appendChild(outgoing);galleryCrossfadeImage=outgoing;
 galleryImage.src=photo.src;galleryImage.alt=photo.label;
 const timing={duration:280,easing:'ease-in-out',fill:'both'};
 galleryCrossfadeAnimations=[galleryImage.animate([{opacity:0},{opacity:1}],timing),outgoing.animate([{opacity:1},{opacity:0}],timing)];
 Promise.allSettled(galleryCrossfadeAnimations.map(animation=>animation.finished)).then(()=>{if(token===galleryCrossfadeToken)disposeGalleryPhotoCrossfade();});
}
function revealGalleryThumbnail(index=galleryThumbnailSelectionIndex){
 if(!galleryOverlay.classList.contains('is-open'))return;
 const button=galleryThumbnails.children[index];if(!button||!galleryThumbnails.clientWidth)return;
 const stripRect=galleryThumbnails.getBoundingClientRect(),buttonRect=button.getBoundingClientRect();
 const target=galleryThumbnails.scrollLeft+(buttonRect.left-stripRect.left)-(stripRect.width-buttonRect.width)/2;
 galleryThumbnails.scrollTo({left:Math.max(0,Math.min(target,galleryThumbnails.scrollWidth-galleryThumbnails.clientWidth)),behavior:reducedMotionQuery?.matches?'auto':'smooth'});
}
function setGalleryThumbnailSelection(index){
 galleryThumbnailSelectionIndex=wrappedGalleryIndex(index);galleryThumbnails.querySelectorAll('.gallery-thumbnail').forEach((button,buttonIndex)=>button.setAttribute('aria-current',String(buttonIndex===galleryThumbnailSelectionIndex)));
 requestAnimationFrame(()=>revealGalleryThumbnail(galleryThumbnailSelectionIndex));
}
function selectGalleryPhoto(index,{crossfade=false,preserveSlide=false,syncThumbnail=true}={}){
 if(!preserveSlide){gallerySwipeGesture=null;clearGallerySlide();}
 const nextIndex=wrappedGalleryIndex(index),changed=nextIndex!==selectedGalleryIndex;selectedGalleryIndex=nextIndex;const photo=galleryPhotos[selectedGalleryIndex];
 if(crossfade&&changed)crossfadeGalleryPhoto(photo);else{clearGalleryPhotoCrossfade();galleryImage.src=photo.src;galleryImage.alt=photo.label;galleryImage.decode?.().catch(()=>{});}
 if(syncThumbnail)setGalleryThumbnailSelection(selectedGalleryIndex);preloadSelectedGalleryNeighbors();
}
for(const photo of galleryPhotos){
 const button=document.createElement('button');button.type='button';button.className='gallery-thumbnail';button.setAttribute('aria-label',photo.label);
 const image=document.createElement('img');image.src=photo.thumbnailSrc;image.alt='';button.appendChild(image);button.onclick=()=>{clearGalleryMorph();selectGalleryPhoto(photo.index,{crossfade:true});};galleryThumbnails.appendChild(button);
}
galleryThumbnails.firstElementChild?.setAttribute('aria-current','true');galleryImage.alt=galleryPhotos[0]?.label||'Gallery';if(!galleryPhotos.length)galleryToggle.disabled=true;
function projectedGalleryPhoto(photo){
 photo.geometry.computeBoundingBox();photo.updateWorldMatrix(true,false);camera.updateMatrixWorld();
 const box=photo.geometry.boundingBox,viewerRect=viewer.getBoundingClientRect();
 const project=(x,y)=>{const point=new THREE.Vector3(x,y,0).applyMatrix4(photo.matrixWorld).project(camera);return{x:(point.x+1)*viewerRect.width/2,y:(1-point.y)*viewerRect.height/2};};
 const corners=[project(box.min.x,box.max.y),project(box.max.x,box.max.y),project(box.max.x,box.min.y),project(box.min.x,box.min.y)];
 const distance=(a,b)=>Math.hypot(b.x-a.x,b.y-a.y),center=corners.reduce((sum,point)=>({x:sum.x+point.x/4,y:sum.y+point.y/4}),{x:0,y:0});
 const projectedHorizontal={x:corners[1].x-corners[0].x,y:corners[1].y-corners[0].y};
 let shear=Math.atan2(projectedHorizontal.y,projectedHorizontal.x);if(shear>Math.PI/2)shear-=Math.PI;if(shear< -Math.PI/2)shear+=Math.PI;
 // Resolve the shortest turn from the wall normal to the camera strictly
 // around the house's world-Y axis. Every frame stays upright throughout.
 const normal=new THREE.Vector3(0,0,1).transformDirection(photo.matrixWorld);normal.y=0;normal.normalize();
 const photoPosition=photo.getWorldPosition(new THREE.Vector3()),cameraPosition=camera.getWorldPosition(new THREE.Vector3()),toCamera=cameraPosition.sub(photoPosition);toCamera.y=0;
 let yaw=0;if(toCamera.lengthSq()>1e-8){toCamera.normalize();if(normal.dot(toCamera)<0)normal.multiplyScalar(-1);const turnToCamera=Math.atan2(new THREE.Vector3(0,1,0).dot(normal.clone().cross(toCamera)),normal.dot(toCamera));yaw=-THREE.MathUtils.radToDeg(turnToCamera);}
 yaw=THREE.MathUtils.clamp(yaw,-85,85);
 const width=Math.max(1,Math.abs(projectedHorizontal.x)),height=(distance(corners[0],corners[3])+distance(corners[1],corners[2]))/2;
 return{corners,center,left:center.x-width/2,top:center.y-height/2,width,height,shear,yaw};
}
let galleryHandoffFrame=0,galleryThumbnailFrame=0,galleryMorphGeneration=0;
function clearGalleryHandoff(){
 if(galleryHandoffFrame)cancelAnimationFrame(galleryHandoffFrame);galleryHandoffFrame=0;galleryOverlay.classList.remove('is-handoff');
}
function cancelGalleryMorphAnimations(){
 galleryGenieTransition?.cancel();galleryMorphAnimation?.cancel();galleryMorphAnimation=null;galleryMorphElement?.remove();galleryMorphElement=null;
 if(galleryThumbnailFrame)cancelAnimationFrame(galleryThumbnailFrame);galleryThumbnailFrame=0;
}
function beginGalleryMorph(){
 galleryMorphGeneration++;clearGalleryHandoff();Object.assign(galleryImage.style,{display:'block',opacity:'0',visibility:'hidden'});galleryOverlay.classList.add('is-morphing');galleryOverlay.setAttribute('aria-busy','true');cancelGalleryMorphAnimations();
 Object.assign(galleryThumbnails.style,{opacity:'0',visibility:'hidden',transition:'none'});
}
function updateGalleryThumbnailFade(linear,duration){
 const fadeDuration=Math.min(180,duration),fadeStart=1-fadeDuration/duration;
 const fade=THREE.MathUtils.smoothstep(linear,fadeStart,1);
 galleryThumbnails.style.opacity=String(fade);galleryThumbnails.style.visibility=linear>=fadeStart?'visible':'hidden';
}
function startGalleryThumbnailFade(duration){
 if(galleryThumbnailFrame)cancelAnimationFrame(galleryThumbnailFrame);
 const start=performance.now();updateGalleryThumbnailFade(0,duration);
 const frame=now=>{const linear=THREE.MathUtils.clamp((now-start)/duration,0,1);updateGalleryThumbnailFade(linear,duration);if(linear<1)galleryThumbnailFrame=requestAnimationFrame(frame);else galleryThumbnailFrame=0;};
 galleryThumbnailFrame=requestAnimationFrame(frame);
}
function finishGalleryMorph({holdGenieFrame=false}={}){
 clearGalleryHandoff();if(galleryThumbnailFrame)cancelAnimationFrame(galleryThumbnailFrame);galleryThumbnailFrame=0;updateGalleryThumbnailFade(1,galleryMorphTuning.duration);
 galleryOverlay.classList.add('is-handoff');Object.assign(galleryImage.style,{display:'block',opacity:'1',visibility:'visible'});galleryOverlay.classList.remove('is-morphing');galleryOverlay.removeAttribute('aria-busy');
 if(!holdGenieFrame)galleryGenieTransition?.release();
 galleryHandoffFrame=requestAnimationFrame(()=>{if(holdGenieFrame)galleryGenieTransition?.release();galleryOverlay.classList.remove('is-handoff');for(const property of ['display','opacity'])galleryImage.style.removeProperty(property);for(const property of ['opacity','visibility','transition'])galleryThumbnails.style.removeProperty(property);galleryHandoffFrame=0;});
}
function clearGalleryMorph(){
 galleryMorphGeneration++;cancelGalleryMorphAnimations();finishGalleryMorph();
}
function galleryMotionProgress(time,edge){
 // Stay close to constant velocity for most of the morph. The short rounded
 // caps avoid both the smoothstep pause at launch and its long, subtle tail.
 const speed=1/(1-edge);
 if(time<edge){const phase=time/edge;return speed*edge*(phase**3-.5*phase**4);}
 if(time>1-edge){const phase=(1-time)/edge;return 1-speed*edge*(phase**3-.5*phase**4);}
 return speed*(time-edge/2);
}
async function animateClassicGalleryFromFrame(source,index,prepared=false){
 const photo=galleryPhotos[index],morph=document.createElement('img');if(!prepared)beginGalleryMorph();const generation=galleryMorphGeneration;
 // source.width is already the foreshortened on-screen width. Compensate the
 // layout width before applying rotateY so the yaw is not applied twice and
 // the photo does not snap nearly edge-on at the start of the morph.
 const initialYawRadians=THREE.MathUtils.degToRad(source.yaw),yawScale=Math.max(.087,Math.abs(Math.cos(initialYawRadians)));
 const initialWidth=source.width/yawScale,initialHeight=source.height,initialLeft=source.center.x-initialWidth/2,initialTop=source.center.y-initialHeight/2,initialTransform=`perspective(1000px) skewY(${source.shear}rad) rotateY(${source.yaw}deg) translateZ(0px)`;
 morph.className='gallery-morph-image';morph.src=photo.src;morph.alt='';Object.assign(morph.style,{left:`${initialLeft}px`,top:`${initialTop}px`,width:`${initialWidth}px`,height:`${initialHeight}px`,transform:initialTransform});viewer.appendChild(morph);galleryMorphElement=morph;
 if(!galleryOverlay.classList.contains('is-open')||galleryMorphElement!==morph)return;
 const viewerRect=viewer.getBoundingClientRect(),targetRect=galleryImage.getBoundingClientRect();
 if(!targetRect.width||!targetRect.height){clearGalleryMorph();return;}
 galleryImage.style.display='none';
 const targetLeft=targetRect.left-viewerRect.left,targetTop=targetRect.top-viewerRect.top;
 const tuning={...galleryMorphTuning},easeEdge=Math.min(.12,55/tuning.duration);
 const sampleCount=Math.max(32,Math.ceil(tuning.duration/16)),motionKeyframes=Array.from({length:sampleCount+1},(_,index)=>{
  const time=index/sampleCount,motion=galleryMotionProgress(time,easeEdge),rotationMotion=motion**3,bounceTime=THREE.MathUtils.clamp((time-.72)/.22,0,1),bounce=time>=.72&&time<=.94?Math.sin(Math.PI*bounceTime)**2*tuning.overshoot/100:0;
  const width=THREE.MathUtils.lerp(initialWidth,targetRect.width,motion)*(1+bounce),height=THREE.MathUtils.lerp(initialHeight,targetRect.height,motion)*(1+bounce);
  const centerX=THREE.MathUtils.lerp(source.center.x,targetLeft+targetRect.width/2,motion),centerY=THREE.MathUtils.lerp(source.center.y,targetTop+targetRect.height/2,motion);
  const spatial=Math.sin(Math.PI*motion),lift=spatial*tuning.arc;
  return{left:`${centerX-width/2}px`,top:`${centerY-height/2-lift}px`,width:`${width}px`,height:`${height}px`,transform:`perspective(1000px) skewY(${source.shear*(1-rotationMotion)}rad) rotateY(${source.yaw*(1-rotationMotion)}deg) translateZ(${tuning.depth*spatial}px)`,offset:time};
 });
 startGalleryThumbnailFade(tuning.duration);
 galleryMorphAnimation=morph.animate(motionKeyframes,{duration:tuning.duration,easing:'linear',fill:'forwards'});
  try{await galleryMorphAnimation.finished;}catch{}
 if(galleryMorphElement===morph&&generation===galleryMorphGeneration)await new Promise(resolve=>requestAnimationFrame(resolve));
 if(galleryMorphElement===morph&&generation===galleryMorphGeneration){
  finishGalleryMorph();morph.remove();galleryMorphElement=null;galleryMorphAnimation=null;
 }
}
function animateGenieGalleryFromFrame(source,index,prepared=false){
 if(!prepared)beginGalleryMorph();const generation=galleryMorphGeneration;
 const viewerRect=viewer.getBoundingClientRect(),targetBounds=galleryImage.getBoundingClientRect();
 const targetRect={left:targetBounds.left-viewerRect.left,top:targetBounds.top-viewerRect.top,width:targetBounds.width,height:targetBounds.height};
 galleryImage.style.display='none';
 const started=ensureGalleryGenieTransition()?.animate({
  sourceCorners:source.corners,
  targetRect,
  texture:galleryTextures[index%galleryTextures.length].image?galleryTextures[index%galleryTextures.length]:galleryPreviewTextures[index%galleryPreviewTextures.length],
  duration:galleryMorphTuning.duration,
  stagger:galleryMorphTuning.stagger/100,
  squeeze:galleryMorphTuning.squeeze/100,
  curve:galleryMorphTuning.curve,
  onProgress:linear=>{if(generation===galleryMorphGeneration)updateGalleryThumbnailFade(linear,galleryMorphTuning.duration);},
  onComplete:()=>{if(generation===galleryMorphGeneration&&galleryOverlay.classList.contains('is-open'))finishGalleryMorph({holdGenieFrame:true});},
  onAbort:()=>{if(generation===galleryMorphGeneration&&galleryOverlay.classList.contains('is-open'))finishGalleryMorph();},
  holdFinalFrame:true,
 });
 if(!started){galleryImage.style.display='block';animateClassicGalleryFromFrame(source,index,true);}
}
function animateGalleryFromFrame(source,index,prepared=false){
 if(window.matchMedia?.('(prefers-reduced-motion: reduce)').matches){clearGalleryMorph();return;}
 if(galleryTransitionMode==='genie')animateGenieGalleryFromFrame(source,index,prepared);else animateClassicGalleryFromFrame(source,index,prepared);
}
window.addEventListener('resize',()=>{gallerySwipeGesture=null;clearGallerySlide();if(galleryGenieTransition?.active)clearGalleryMorph();else galleryGenieTransition?.resize();});
function openGallery(index=0,opener=galleryToggle,sourcePhoto=null){
 if(!galleryPhotos.length)return;
 ensureGalleryTexturesLoaded();
 const photoIndex=(index+galleryPhotos.length)%galleryPhotos.length;
 const source=sourcePhoto?projectedGalleryPhoto(sourcePhoto):null;
 const controlEntry=!sourcePhoto;
 if(controlEntry)galleryThumbnails.scrollLeft=0;
 if(gallerySourcePhoto)gallerySourcePhoto.visible=true;gallerySourcePhoto=sourcePhoto;if(gallerySourcePhoto){gallerySourcePhoto.visible=false;requestMainRender();}
  cancelIntroCamera();closeActiveCatalogItem();setDescriptionOpen(false);setAudioPlayerOpen(false);selectGalleryPhoto(photoIndex);galleryOpener=opener;
 const shouldMorph=Boolean(source)&&!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
 if(shouldMorph)beginGalleryMorph();else clearGalleryMorph();
  setModelInteractiveHover(false);viewer.classList.toggle('gallery-control-open',controlEntry);galleryOverlay.classList.toggle('is-control-open',controlEntry);viewer.classList.add('gallery-open');galleryOverlay.classList.add('is-open');galleryOverlay.setAttribute('aria-hidden','false');galleryToggle.setAttribute('aria-expanded','true');controls.enabled=false;reportEmbeddedChildViewState();syncTvVideoPlayback();
 if(shouldMorph)animateGalleryFromFrame(source,photoIndex,true);galleryOverlay.focus();
}
function closeGallery({suppressOpenerFeedback=false}={}){
 if(!galleryOverlay.classList.contains('is-open'))return;
 gallerySwipeGesture=null;clearGallerySlide();clearGalleryMorph();clearGalleryPhotoCrossfade();if(gallerySourcePhoto){gallerySourcePhoto.visible=true;gallerySourcePhoto=null;}
 galleryOverlay.classList.remove('is-open','is-control-open');viewer.classList.remove('gallery-open','gallery-control-open');galleryOverlay.setAttribute('aria-hidden','true');galleryToggle.setAttribute('aria-expanded','false');controls.enabled=true;reportEmbeddedChildViewState();
 if(suppressOpenerFeedback&&galleryOpener===galleryToggle)galleryToggle.classList.add('suppress-focus-ring','suppress-tooltip-feedback');galleryOpener?.focus?.({preventScroll:true});galleryOpener=null;syncTvVideoPlayback();requestMainRender();
}
galleryToggle.onclick=()=>openGallery(0,galleryToggle);
galleryToggle.addEventListener('pointerenter',()=>galleryToggle.classList.remove('suppress-tooltip-feedback'));
for(const event of ['pointerdown','blur'])galleryToggle.addEventListener(event,()=>galleryToggle.classList.remove('suppress-focus-ring','suppress-tooltip-feedback'));
galleryClose.onclick=closeGallery;
galleryImage.addEventListener('pointerdown',event=>{
 if(event.pointerType!=='touch')return;
 if(!event.isPrimary){if(gallerySwipeGesture?.slide)settleGallerySlide(gallerySwipeGesture.slide);gallerySwipeGesture=null;return;}
 if(gallerySlideSettling||galleryCrossfadePending||!galleryOverlay.classList.contains('is-open')||galleryOverlay.classList.contains('is-morphing')||galleryOverlay.getAttribute('aria-busy')==='true')return;
 clearGalleryPhotoCrossfade();clearGallerySlide();gallerySwipeGesture={id:event.pointerId,x:event.clientX,y:event.clientY,lastX:event.clientX,lastTime:performance.now(),velocity:0,axis:null,slide:null};
 try{galleryImage.setPointerCapture(event.pointerId);}catch{}
});
galleryImage.addEventListener('pointermove',event=>{
 if(!gallerySwipeGesture||event.pointerId!==gallerySwipeGesture.id)return;
 const now=performance.now(),dx=event.clientX-gallerySwipeGesture.x,dy=event.clientY-gallerySwipeGesture.y;
 if(!gallerySwipeGesture.axis&&Math.hypot(dx,dy)>10)gallerySwipeGesture.axis=Math.abs(dx)>Math.abs(dy)?'x':'y';
 if(gallerySwipeGesture.axis!=='x')return;
 if(!gallerySwipeGesture.slide)gallerySwipeGesture.slide=beginGallerySlide();
 const elapsed=Math.min(50,Math.max(1,now-gallerySwipeGesture.lastTime)),sampleVelocity=(event.clientX-gallerySwipeGesture.lastX)/elapsed;gallerySwipeGesture.velocity=gallerySwipeGesture.velocity*.55+sampleVelocity*.45;gallerySwipeGesture.lastX=event.clientX;gallerySwipeGesture.lastTime=now;
 updateGallerySlide(gallerySwipeGesture.slide,dx);event.preventDefault();
});
function finishGallerySwipe(event,{cancelled=false}={}){
 if(!gallerySwipeGesture||event.pointerId!==gallerySwipeGesture.id)return;
 const gesture=gallerySwipeGesture;gallerySwipeGesture=null;
 try{if(galleryImage.hasPointerCapture?.(event.pointerId))galleryImage.releasePointerCapture(event.pointerId);}catch{}
 if(!gesture.slide)return;
 if(cancelled||gesture.axis==='y'||!galleryOverlay.classList.contains('is-open')){settleGallerySlide(gesture.slide);return;}
 const dx=event.clientX-gesture.x,dy=event.clientY-gesture.y,idleTime=Math.max(0,performance.now()-gesture.lastTime),releaseVelocity=THREE.MathUtils.clamp(gesture.velocity*Math.exp(-Math.max(0,idleTime-80)/250),-1.8,1.8),projected=dx+releaseVelocity*180,threshold=gesture.slide.pageWidth*.24,horizontal=Math.abs(dx)>Math.abs(dy)*1.25,directionAgrees=!dx||!projected||Math.sign(projected)===Math.sign(dx),commit=horizontal&&directionAgrees&&(Math.abs(projected)>=threshold||Math.abs(dx)>=24&&Math.abs(releaseVelocity)>=.45),direction=commit?(projected<0?1:-1):0;
 event.preventDefault();clearGalleryMorph();settleGallerySlide(gesture.slide,{direction,velocity:releaseVelocity});
}
galleryImage.addEventListener('pointerup',event=>finishGallerySwipe(event));
galleryImage.addEventListener('pointercancel',event=>finishGallerySwipe(event,{cancelled:true}));
galleryImage.addEventListener('lostpointercapture',event=>{if(gallerySwipeGesture?.id!==event.pointerId)return;const gesture=gallerySwipeGesture;gallerySwipeGesture=null;if(gesture.slide)settleGallerySlide(gesture.slide);});
galleryOverlay.addEventListener('pointerdown',event=>{if(gallerySlideSettling||gallerySwipeGesture?.slide)return;if(!event.target.closest?.('.gallery-stage img,.gallery-thumbnails'))closeGallery();});
galleryThumbnails.addEventListener('wheel',event=>{
 if(Math.abs(event.deltaY)<=Math.abs(event.deltaX))return;
 event.preventDefault();galleryThumbnails.scrollLeft+=event.deltaY;
},{passive:false});
document.addEventListener('keydown',event=>{
 if(!galleryOverlay.classList.contains('is-open'))return;
 if(event.key==='Escape')closeGallery({suppressOpenerFeedback:true});
 else if(event.key==='ArrowRight'){clearGalleryMorph();selectGalleryPhoto(selectedGalleryIndex+1,{crossfade:true});}
 else if(event.key==='ArrowLeft'){clearGalleryMorph();selectGalleryPhoto(selectedGalleryIndex-1,{crossfade:true});}
});
// Rearrange mode is deliberately opt-in so the default camera, gallery and audio
// interactions remain unchanged. Every editable object is a logical root; no
// cabinetry or architecture descendants are registered here.
let arrangeModeActive=false,selectedArrangeItem=null,arrangeDrag=null,arrangeHistoryIndex=0,arrangeDuplicateCount=0,arrangementRevision=0,snapshotDataUrl='',snapshotSharePointerType='',snapshotSharePending=false,shareToastTimer=0;
const arrangeHistory=[],arrangeItems=[],arrangeItemByRoot=new WeakMap(),arrangeItemById=new Map(),arrangePickProxies=[];
const arrangePickProxyMaterial=new THREE.MeshBasicMaterial({visible:false,side:THREE.DoubleSide});arrangePickProxyMaterial.name='Invisible Arrange pick proxy';
function addArrangePickProxy(root,metadata){
 const existing=root.getObjectByName('Arrange pick proxy');if(existing){existing.userData.arrangeItemId=metadata.id;if(!arrangePickProxies.includes(existing))arrangePickProxies.push(existing);return;}
 let [width,depth,height]=root.userData.size||[],center=new THREE.Vector3(0,Number(height)/2||0,0);
 if(![width,depth,height].every(Number.isFinite)){
  root.updateWorldMatrix(true,true);const bounds=new THREE.Box3().setFromObject(root);if(bounds.isEmpty())return;
  const worldCenter=bounds.getCenter(new THREE.Vector3());center=root.worldToLocal(worldCenter);const worldSize=bounds.getSize(new THREE.Vector3());width=worldSize.x;depth=worldSize.z;height=worldSize.y;
 }
 const padding=.02,proxy=new THREE.Mesh(new THREE.BoxGeometry(width+padding,height+padding,depth+padding),arrangePickProxyMaterial);
 proxy.name='Arrange pick proxy';proxy.position.copy(center);proxy.castShadow=false;proxy.receiveShadow=false;proxy.userData={arrangePickProxy:true,arrangeItemId:metadata.id};root.add(proxy);arrangePickProxies.push(proxy);
}
function registerArrangeItem(root,{duplicate=false,ownedMaterials=[]}={}){
 const metadata=root.userData.movableItem;
 if(arrangeItemById.has(metadata.id))throw new Error(`Duplicate movable item id: ${metadata.id}`);
 addArrangePickProxy(root,metadata);
 const item={root,metadata,duplicate,ownedMaterials,present:true,initial:duplicate?null:{position:root.position.clone(),quaternion:root.quaternion.clone(),scale:root.scale.clone(),visible:root.visible}};
 arrangeItems.push(item);arrangeItemByRoot.set(root,item);arrangeItemById.set(metadata.id,item);return item;
}
for(const root of [...layers.furniture.children,...layers.lighting.children])if(root.userData.movableItem)registerArrangeItem(root);
const arrangeRaycaster=new THREE.Raycaster(),arrangePointer=new THREE.Vector2(),arrangePoint=new THREE.Vector3(),arrangePlane=new THREE.Plane(),arrangeProjectionPoint=new THREE.Vector3(),arrangeOcclusionMeshes=[];
for(const layer of [layers.architecture,layers.cabinetry])layer.traverse(object=>{
 if(!object.isMesh)return;const materials=Array.isArray(object.material)?object.material:[object.material];
 if(materials.some(material=>material&&material.visible!==false&&(material.opacity??1)>.01&&material.alphaTest<=0&&(!material.transparent||(material.opacity??1)>=.98)))arrangeOcclusionMeshes.push(object);
});
const arrangeItemBounds=new THREE.Box3(),arrangeSelectionBounds=new THREE.Box3(),arrangeSelectionHelper=new THREE.Box3Helper(arrangeSelectionBounds,new THREE.Color('#02ADFC'));
arrangeSelectionHelper.name='Arrange selection outline';arrangeSelectionHelper.visible=false;arrangeSelectionHelper.renderOrder=1000;arrangeSelectionHelper.userData.arrangeHelper=true;
arrangeSelectionHelper.material.depthTest=false;arrangeSelectionHelper.material.transparent=true;arrangeSelectionHelper.material.opacity=.9;scene.add(arrangeSelectionHelper);
function setArrangePointer(event){
 const rect=renderer.domElement.getBoundingClientRect();arrangePointer.set((event.clientX-rect.left)/rect.width*2-1,-(event.clientY-rect.top)/rect.height*2+1);arrangeRaycaster.setFromCamera(arrangePointer,camera);
}
function arrangeItemForObject(object){
 for(let current=object;current;current=current.parent){const item=arrangeItemByRoot.get(current);if(item)return item;}
 return null;
}
function arrangeItemAtPointer(event){
 if(!arrangeModeActive||galleryOverlay.classList.contains('is-open')||snapshotDialog.classList.contains('is-open'))return null;
 setArrangePointer(event);
 const hits=arrangeRaycaster.intersectObjects(arrangePickProxies,false);
 for(const hit of hits){
  if(!isEffectivelyVisible(hit.object))continue;
  const item=arrangeItemForObject(hit.object);
  if(!item||!item.present||item.root.userData.arrangeDeleted)continue;
  const previousFar=arrangeRaycaster.far;arrangeRaycaster.far=Math.max(arrangeRaycaster.near,hit.distance-1e-4);
  const blocked=arrangeRaycaster.intersectObjects(arrangeOcclusionMeshes,false).some(result=>isEffectivelyVisible(result.object));arrangeRaycaster.far=previousFar;
  if(!blocked)return item;
 }
 return null;
}
function boundsForArrangeItem(item,target=new THREE.Box3()){
 const body=item.root.getObjectByName('product body'),bodyBounds=body?target.setFromObject(body):target.makeEmpty();
 return body&&!bodyBounds.isEmpty()?bodyBounds:target.setFromObject(item.root);
}
function arrangeItemIsVisible(item){
 return item.present&&!item.root.userData.arrangeDeleted&&isEffectivelyVisible(item.root);
}
function positionArrangeItemControls(){
 if(!selectedArrangeItem||arrangeItemControls.hidden)return;
 const viewerRect=viewer.getBoundingClientRect(),canvasRect=renderer.domElement.getBoundingClientRect();let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity,withinDepth=false;
 for(const x of [arrangeSelectionBounds.min.x,arrangeSelectionBounds.max.x])for(const y of [arrangeSelectionBounds.min.y,arrangeSelectionBounds.max.y])for(const z of [arrangeSelectionBounds.min.z,arrangeSelectionBounds.max.z]){
  arrangeProjectionPoint.set(x,y,z).project(camera);withinDepth=withinDepth||(arrangeProjectionPoint.z>=-1&&arrangeProjectionPoint.z<=1);
  const screenX=canvasRect.left-viewerRect.left+(arrangeProjectionPoint.x+1)*canvasRect.width/2,screenY=canvasRect.top-viewerRect.top+(1-arrangeProjectionPoint.y)*canvasRect.height/2;
  minX=Math.min(minX,screenX);maxX=Math.max(maxX,screenX);minY=Math.min(minY,screenY);maxY=Math.max(maxY,screenY);
 }
 const offscreen=!withinDepth||maxX<0||minX>viewerRect.width||maxY<0||minY>viewerRect.height;arrangeItemControls.style.visibility=offscreen?'hidden':'visible';arrangeDimensions.style.visibility=offscreen?'hidden':'visible';if(offscreen)return;
 const width=arrangeItemControls.offsetWidth||176,height=arrangeItemControls.offsetHeight||44,margin=8;
 let left=(minX+maxX-width)/2,top=minY-height-margin;if(top<margin)top=maxY+margin;
 left=THREE.MathUtils.clamp(left,margin,Math.max(margin,viewerRect.width-width-margin));top=THREE.MathUtils.clamp(top,margin,Math.max(margin,viewerRect.height-height-margin));
 arrangeItemControls.style.left=`${left}px`;arrangeItemControls.style.top=`${top}px`;
 const min=arrangeItemBounds.min,max=arrangeItemBounds.max,center=arrangeItemBounds.getCenter(new THREE.Vector3()),projectLabel=(label,point,offsetX,offsetY)=>{
  arrangeProjectionPoint.copy(point).project(camera);const x=canvasRect.left-viewerRect.left+(arrangeProjectionPoint.x+1)*canvasRect.width/2,y=canvasRect.top-viewerRect.top+(1-arrangeProjectionPoint.y)*canvasRect.height/2;label.style.left=`${x+offsetX}px`;label.style.top=`${y+offsetY}px`;
 };
 projectLabel(arrangeDimensionWidth,new THREE.Vector3(center.x,min.y,max.z),0,10);projectLabel(arrangeDimensionDepth,new THREE.Vector3(max.x,min.y,center.z),10,8);projectLabel(arrangeDimensionHeight,new THREE.Vector3(max.x,center.y,max.z),12,0);
}
function updateArrangeSelectionVisual(){
 const visible=Boolean(selectedArrangeItem&&arrangeItemIsVisible(selectedArrangeItem));
 arrangeSelectionHelper.visible=visible;arrangeItemControls.hidden=!visible;arrangeDimensions.hidden=!visible;
 if(!visible){requestMainRender();return;}
 boundsForArrangeItem(selectedArrangeItem,arrangeItemBounds);arrangeSelectionBounds.copy(arrangeItemBounds).expandByScalar(.025);
  arrangeSelectionHelper.box=arrangeSelectionBounds;arrangeSelectionHelper.updateMatrixWorld(true);
 const size=arrangeItemBounds.getSize(new THREE.Vector3()),format=value=>formatDimension(value,projectConfig.units);
 arrangeDimensionWidth.textContent=format(size.x);arrangeDimensionDepth.textContent=format(size.z);arrangeDimensionHeight.textContent=format(size.y);arrangeDimensionWidth.setAttribute('aria-label',`Width ${format(size.x)}`);arrangeDimensionDepth.setAttribute('aria-label',`Depth ${format(size.z)}`);arrangeDimensionHeight.setAttribute('aria-label',`Height ${format(size.y)}`);
 arrangeItemControls.setAttribute('aria-label',`Controls for ${selectedArrangeItem.metadata.label}`);positionArrangeItemControls();
 const rotationLocked=selectedArrangeItem.metadata.constraint==='wall';arrangeRotateLeft.disabled=rotationLocked;arrangeRotateRight.disabled=rotationLocked;arrangeDuplicate.disabled=selectedArrangeItem.metadata.duplicable===false;arrangeDelete.disabled=selectedArrangeItem.metadata.deletable===false;
 arrangeRotateLeft.setAttribute('aria-label',rotationLocked?`Rotation unavailable for ${selectedArrangeItem.metadata.label}`:`Rotate ${selectedArrangeItem.metadata.label} left 15 degrees`);arrangeRotateRight.setAttribute('aria-label',rotationLocked?`Rotation unavailable for ${selectedArrangeItem.metadata.label}`:`Rotate ${selectedArrangeItem.metadata.label} right 15 degrees`);arrangeDuplicate.setAttribute('aria-label',selectedArrangeItem.metadata.duplicable===false?`Duplication unavailable for ${selectedArrangeItem.metadata.label}`:`Duplicate ${selectedArrangeItem.metadata.label}`);arrangeDelete.setAttribute('aria-label',`Delete ${selectedArrangeItem.metadata.label}`);
 requestMainRender();
}
function selectArrangeItem(item){selectedArrangeItem=item;updateArrangeSelectionVisual();}
function arrangeState(item){return{position:item.root.position.clone(),quaternion:item.root.quaternion.clone(),visible:item.root.visible,deleted:Boolean(item.root.userData.arrangeDeleted),present:item.present};}
function applyArrangeState(item,state){
 item.present=state.present!==false;item.root.position.copy(state.position);item.root.quaternion.copy(state.quaternion);item.root.visible=item.present&&state.visible;item.root.userData.arrangeDeleted=!item.present||state.deleted;item.root.updateMatrixWorld(true);
 if((!item.present||state.deleted)&&selectedArrangeItem===item)selectedArrangeItem=null;
 arrangementRevision++;productFocusSolutionCache.clear();if(item.root.parent===layers.lighting||item.root.userData.wallFrame||item.root.userData.frameGrid)syncNightFixturePositions();invalidateReflectors();invalidateShadows();updateArrangeSelectionVisual();
}
function sameArrangeState(a,b){return a.present===b.present&&a.visible===b.visible&&a.deleted===b.deleted&&a.position.distanceToSquared(b.position)<1e-10&&1-Math.abs(a.quaternion.dot(b.quaternion))<1e-10;}
function updateArrangeHistoryControls(){
 const expanded=arrangeModeActive;arrangeControl.classList.toggle('has-history',expanded);
 arrangeToggle.setAttribute('aria-expanded',String(expanded));arrangeActions.setAttribute('aria-hidden',String(!expanded));for(const button of [arrangeUndo,arrangeRedo,arrangeSnapshot])button.tabIndex=expanded?0:-1;
 arrangeUndo.disabled=arrangeHistoryIndex===0;arrangeRedo.disabled=arrangeHistoryIndex===arrangeHistory.length;
 requestAnimationFrame(updateLayerControlsLayout);
}
function recordArrangeChange(item,before,after){
 if(sameArrangeState(before,after))return;
 arrangeHistory.splice(arrangeHistoryIndex);arrangeHistory.push({item,before,after});arrangeHistoryIndex=arrangeHistory.length;arrangementRevision++;productFocusSolutionCache.clear();updateArrangeHistoryControls();
}
function undoArrangeChange(){
 if(arrangeHistoryIndex===0)return;
 const change=arrangeHistory[--arrangeHistoryIndex];applyArrangeState(change.item,change.before);if(!change.before.deleted)selectArrangeItem(change.item);updateArrangeHistoryControls();
}
function redoArrangeChange(){
 if(arrangeHistoryIndex===arrangeHistory.length)return;
 const change=arrangeHistory[arrangeHistoryIndex++];applyArrangeState(change.item,change.after);if(!change.after.deleted)selectArrangeItem(change.item);updateArrangeHistoryControls();
}
function deleteSelectedArrangeItem(){
 const item=selectedArrangeItem;if(!item||item.metadata.deletable===false)return;
 const before=arrangeState(item),after={position:before.position.clone(),quaternion:before.quaternion.clone(),visible:false,deleted:true,present:true};applyArrangeState(item,after);recordArrangeChange(item,before,after);
}
function pointInsideMovementBoundary(x,z){
 let inside=false;
 for(let i=0,j=movementBoundary.length-1;i<movementBoundary.length;j=i++){
  const a=movementBoundary[i],b=movementBoundary[j];
  if((a.z>z)!==(b.z>z)&&x<(b.x-a.x)*(z-a.z)/(b.z-a.z)+a.x)inside=!inside;
 }
 return inside;
}
function clampArrangeValue(value,min,max,fallback){return Number.isFinite(min)&&Number.isFinite(max)&&min<=max?THREE.MathUtils.clamp(value,min,max):fallback;}
function fitArrangeItemToSurface(item){
 const surface=item.metadata.surfaceBounds;if(!surface)return;
 const bounds=boundsForArrangeItem(item,new THREE.Box3()),position=item.root.position;
 position.x=clampArrangeValue(position.x,surface.minX-(bounds.min.x-position.x),surface.maxX-(bounds.max.x-position.x),position.x);
 position.z=clampArrangeValue(position.z,surface.minZ-(bounds.min.z-position.z),surface.maxZ-(bounds.max.z-position.z),position.z);item.root.updateMatrixWorld(true);
}
function rotateSelectedArrangeItem(direction){
 const item=selectedArrangeItem;if(!item||item.metadata.constraint==='wall')return;
 const before=arrangeState(item);item.root.rotation.y=THREE.MathUtils.euclideanModulo(item.root.rotation.y+direction*Math.PI/12+Math.PI,Math.PI*2)-Math.PI;item.root.updateMatrixWorld(true);
 if(item.metadata.constraint==='surface')fitArrangeItemToSurface(item);
 const after=arrangeState(item);recordArrangeChange(item,before,after);if(item.root.parent===layers.lighting||item.root.userData.wallFrame||item.root.userData.frameGrid)syncNightFixturePositions();invalidateReflectors();invalidateShadows();updateArrangeSelectionVisual();
}
function placeDuplicateNearby(item){
 const root=item.root,metadata=item.metadata,bounds=boundsForArrangeItem(item,new THREE.Box3()),size=bounds.getSize(new THREE.Vector3()),origin=root.position.clone();
 if(metadata.constraint==='wall'){
  const wall=metadata.wallBounds,{tangent}=wallAxes(wall),capital=tangent.toUpperCase(),offsetMin=bounds.min[tangent]-origin[tangent],offsetMax=bounds.max[tangent]-origin[tangent],step=Math.max(.25,size[tangent]+.10);
  if(wall){
   const min=wall[`min${capital}`]-offsetMin,max=wall[`max${capital}`]-offsetMax,positive=THREE.MathUtils.clamp(origin[tangent]+step,min,max),negative=THREE.MathUtils.clamp(origin[tangent]-step,min,max);
   root.position[tangent]=Math.abs(positive-origin[tangent])>=Math.abs(negative-origin[tangent])?positive:negative;
  }else root.position[tangent]+=step;
 }else if(metadata.constraint==='surface'){
  root.position.z+=Math.max(.16,size.z+.05);root.updateMatrixWorld(true);fitArrangeItemToSurface(item);
 }else{
  const dx=Math.max(.45,size.x+.12),dz=Math.max(.45,size.z+.12),candidates=[[dx,0],[-dx,0],[0,dz],[0,-dz],[dx,dz],[-dx,dz],[dx,-dz],[-dx,-dz]];
  const offset=candidates.find(([x,z])=>pointInsideMovementBoundary(origin.x+x,origin.z+z));if(offset){root.position.x+=offset[0];root.position.z+=offset[1];}
 }
 root.updateMatrixWorld(true);
}
function cloneArrangeRootForDuplicate(source){
 const liveMirror=source.metadata.duplicateMode==='static-mirror'?source.root.children.find(child=>child.isReflector):null;
 if(!liveMirror)return{root:source.root.clone(true),ownedMaterials:[]};
 const root=source.root.clone(false),ownedMaterials=[];
 for(const child of source.root.children){
  if(child!==liveMirror){root.add(child.clone(true));continue;}
  // A non-live duplicate has no scene render target to illuminate it. Use a
  // lighting-independent warm silver so it retains the original mirror's
  // bright visual weight instead of reading as flat mid-gray.
  const material=new THREE.MeshBasicMaterial({color:'#f2f1e9',side:THREE.DoubleSide,toneMapped:false});material.name='Bright static duplicate mirror material';ownedMaterials.push(material);
  const surface=new THREE.Mesh(child.geometry,material);surface.name='static mirror surface';surface.position.copy(child.position);surface.quaternion.copy(child.quaternion);surface.scale.copy(child.scale);surface.visible=child.visible;surface.renderOrder=child.renderOrder;surface.castShadow=false;surface.receiveShadow=false;surface.userData={...child.userData,dynamicReflection:false,staticReflection:true,source:'Arrange-mode mirror duplicate'};root.add(surface);
 }
 root.userData={...root.userData,dynamicReflection:false,staticReflection:true};return{root,ownedMaterials};
}
function duplicateSelectedArrangeItem(){
 const source=selectedArrangeItem;if(!source||source.metadata.duplicable===false)return;
 closeActiveCatalogItem();
 const {root,ownedMaterials}=cloneArrangeRootForDuplicate(source),copyNumber=++arrangeDuplicateCount,baseId=`${source.metadata.id}-copy-${copyNumber}`;let id=baseId,suffix=2;while(arrangeItemById.has(id))id=`${baseId}-${suffix++}`;
 root.name=`${source.root.name} copy`;root.userData.movableItem={...source.metadata,id,label:`${source.metadata.label} copy`,duplicate:true};root.userData.arrangeDeleted=false;source.root.parent.add(root);root.updateMatrixWorld(true);
 const targets=collectInteractionTargets(root);modelInteractionMeshes.push(...targets.meshes);galleryPhotoMeshes.push(...targets.photos);
 const item=registerArrangeItem(root,{duplicate:true,ownedMaterials});placeDuplicateNearby(item);
 root.traverse(object=>{if(object.material&&!object.isReflector&&!object.userData.arrangeHelper&&!object.userData.arrangePickProxy)materialObjects.push(object);});
 const after=arrangeState(item),before={position:after.position.clone(),quaternion:after.quaternion.clone(),visible:false,deleted:true,present:false};recordArrangeChange(item,before,after);selectArrangeItem(item);nightView.syncSceneMaterials();if(root.parent===layers.lighting||root.userData.wallFrame||root.userData.frameGrid)syncNightFixturePositions();invalidateReflectors();invalidateShadows();requestMainRender();
}
function beginArrangeDrag(event,item){
 const metadata=item.metadata,wallInAxon=metadata.constraint==='wall'&&mode!=='plan';
 if(wallInAxon){const {normal,plane}=wallAxes(metadata.wallBounds),center=boundsForArrangeItem(item,new THREE.Box3()).getCenter(new THREE.Vector3());arrangePlane.set(new THREE.Vector3(normal==='x'?1:0,0,normal==='z'?1:0),-(plane??center[normal]));}
 else arrangePlane.set(new THREE.Vector3(0,1,0),-item.root.position.y);
 setArrangePointer(event);if(!arrangeRaycaster.ray.intersectPlane(arrangePlane,arrangePoint))return;
 const bounds=boundsForArrangeItem(item,new THREE.Box3()),start=item.root.position.clone();
 arrangeDrag={pointerId:event.pointerId,item,startState:arrangeState(item),start,initialX:event.clientX,initialY:event.clientY,moved:false,wallInAxon,offset:start.clone().sub(arrangePoint),boundsOffset:{minX:bounds.min.x-start.x,maxX:bounds.max.x-start.x,minY:bounds.min.y-start.y,maxY:bounds.max.y-start.y,minZ:bounds.min.z-start.z,maxZ:bounds.max.z-start.z}};
 controls.enabled=false;setSceneMotionQuality('arrange',true);renderer.domElement.classList.add('is-arrange-dragging');
 try{renderer.domElement.setPointerCapture(event.pointerId);}catch{}
}
function updateArrangeDrag(event){
 const drag=arrangeDrag;if(!drag||event.pointerId!==drag.pointerId)return;
 if(!drag.moved&&Math.hypot(event.clientX-drag.initialX,event.clientY-drag.initialY)<=4)return;
 drag.moved=true;setArrangePointer(event);if(!arrangeRaycaster.ray.intersectPlane(arrangePlane,arrangePoint))return;
 const {item,start,offset,boundsOffset}=drag,metadata=item.metadata,next=start.clone();
 if(metadata.constraint==='wall'){
  const constrained=constrainWallPosition({x:arrangePoint.x+offset.x,y:arrangePoint.y+offset.y,z:arrangePoint.z+offset.z},{x:start.x,y:start.y,z:start.z},metadata.wallBounds,boundsOffset,{allowHeight:drag.wallInAxon});
  next.set(constrained.x,constrained.y,constrained.z);
 }else{
  next.x=arrangePoint.x+offset.x;next.z=arrangePoint.z+offset.z;
  if(metadata.constraint==='surface'&&metadata.surfaceBounds){
   const surface=metadata.surfaceBounds;
   next.x=clampArrangeValue(next.x,surface.minX-boundsOffset.minX,surface.maxX-boundsOffset.maxX,start.x);
   next.z=clampArrangeValue(next.z,surface.minZ-boundsOffset.minZ,surface.maxZ-boundsOffset.maxZ,start.z);
  }else if(!pointInsideMovementBoundary(next.x,next.z))return;
 }
 // Keep drag feedback cheap: the object and outline move live, while expensive
 // mirror/shadow refreshes are committed once in finishArrangeDrag().
 item.root.position.copy(next);item.root.updateMatrixWorld(true);if(item.root.parent===layers.lighting||item.root.userData.wallFrame||item.root.userData.frameGrid)syncNightFixturePositions();updateArrangeSelectionVisual();
}
function finishArrangeDrag(event,{cancel=false}={}){
 const drag=arrangeDrag;if(!drag||event.pointerId!==drag.pointerId)return;
 try{renderer.domElement.releasePointerCapture(event.pointerId);}catch{}
 arrangeDrag=null;renderer.domElement.classList.remove('is-arrange-dragging');controls.enabled=!galleryOverlay.classList.contains('is-open')&&!snapshotDialog.classList.contains('is-open');
 setSceneMotionQuality('arrange',false);
 if(cancel)applyArrangeState(drag.item,drag.startState);
 else if(drag.moved)recordArrangeChange(drag.item,drag.startState,arrangeState(drag.item));
 invalidateReflectors();invalidateShadows();requestMainRender();
}
function resetArrangeItems(){
 const duplicateRoots=[],duplicateMaterials=new Set();
 for(const item of [...arrangeItems]){
  if(item.duplicate){duplicateRoots.push(item.root);for(const material of item.ownedMaterials)duplicateMaterials.add(material);item.root.removeFromParent();arrangeItemByRoot.delete(item.root);arrangeItemById.delete(item.metadata.id);continue;}
  item.present=true;item.root.position.copy(item.initial.position);item.root.quaternion.copy(item.initial.quaternion);item.root.scale.copy(item.initial.scale);item.root.visible=item.initial.visible;item.root.userData.arrangeDeleted=false;item.root.updateMatrixWorld(true);
 }
 for(let index=arrangeItems.length-1;index>=0;index--)if(arrangeItems[index].duplicate)arrangeItems.splice(index,1);
 for(let index=arrangePickProxies.length-1;index>=0;index--)if(duplicateRoots.some(root=>isDescendantOf(arrangePickProxies[index],root)))arrangePickProxies.splice(index,1);
 for(let index=materialObjects.length-1;index>=0;index--)if(duplicateRoots.some(root=>isDescendantOf(materialObjects[index],root)))materialObjects.splice(index,1);
 for(const list of [modelInteractionMeshes,galleryPhotoMeshes])for(let index=list.length-1;index>=0;index--)if(duplicateRoots.some(root=>isDescendantOf(list[index],root)))list.splice(index,1);
 for(const material of duplicateMaterials)material.dispose();
 arrangeDuplicateCount=0;selectedArrangeItem=null;arrangeHistory.length=0;arrangeHistoryIndex=0;arrangementRevision++;productFocusSolutionCache.clear();syncNightFixturePositions();arrangeSelectionHelper.visible=false;arrangeItemControls.hidden=true;arrangeDimensions.hidden=true;updateArrangeHistoryControls();invalidateReflectors();invalidateShadows();visibility();requestMainRender();
}
async function copySnapshotShareUrl(){
 if(navigator.clipboard?.writeText){try{await navigator.clipboard.writeText(SHARE_URL);return true;}catch{}}
 const field=document.createElement('textarea');field.value=SHARE_URL;field.readOnly=true;field.setAttribute('aria-hidden','true');field.style.cssText='position:fixed;top:0;left:-9999px;opacity:0;';document.body.appendChild(field);field.select();field.setSelectionRange(0,field.value.length);
 let copied=false;try{copied=document.execCommand('copy');}catch{}field.remove();return copied;
}
function showSnapshotShareToast(message='Link copied'){
 clearTimeout(shareToastTimer);shareToast.textContent='';shareToast.textContent=message;shareToast.classList.add('is-visible');
 shareToastTimer=setTimeout(()=>{shareToastTimer=0;shareToast.classList.remove('is-visible');shareToast.textContent='';},1000);
}
function updateSnapshotCardWidth(){
 if(!snapshotDialog.classList.contains('is-open'))return;
 const dialogStyle=getComputedStyle(snapshotDialog),cardStyle=getComputedStyle(snapshotCard),dialogPadding=parseFloat(dialogStyle.paddingLeft)+parseFloat(dialogStyle.paddingRight),cardPadding=parseFloat(cardStyle.paddingLeft)+parseFloat(cardStyle.paddingRight),maxCardWidth=Math.min(760,Math.max(0,snapshotDialog.clientWidth-dialogPadding)),maxImageWidth=Math.max(0,maxCardWidth-cardPadding),aspect=snapshotImage.naturalWidth&&snapshotImage.naturalHeight?snapshotImage.naturalWidth/snapshotImage.naturalHeight:desktopHoverQuery.matches?4/3:3/4,maxImageHeight=Math.max(0,snapshotDialog.clientHeight-150),baseImageWidth=Math.min(maxImageWidth,maxImageHeight*aspect),imageWidth=baseImageWidth*(desktopHoverQuery.matches?1:.75);
 snapshotCard.style.width=`${imageWidth+cardPadding}px`;
}
async function handleSnapshotShare(event){
 if(snapshotSharePending)return;const pointerType=event.pointerType||snapshotSharePointerType;snapshotSharePointerType='';const useNativeShare=pointerType==='touch'||!desktopHoverQuery.matches;snapshotSharePending=true;
 try{
  if(useNativeShare){
   // Start clipboard and Web Share inside the original tap. Neither action may
   // wait for the other or mobile Safari/Chrome can consume user activation.
   const copyPromise=copySnapshotShareUrl().catch(error=>(console.warn('Unable to copy the share URL.',error),false));let nativeSharePromise=null;
   if(typeof navigator.share==='function'){
    try{nativeSharePromise=Promise.resolve(navigator.share({title:projectConfig.title,url:SHARE_URL})).then(()=>null,error=>error);}
    catch(error){nativeSharePromise=Promise.resolve(error);}
   }
   const copied=await copyPromise,shareError=nativeSharePromise?await nativeSharePromise:null;
   if(!copied)console.warn('Unable to copy the share URL.');
   if(shareError&&shareError.name!=='AbortError')console.warn('Unable to open the system share sheet.',shareError);
   return;
  }
  const copied=await copySnapshotShareUrl();if(snapshotDialog.classList.contains('is-open'))showSnapshotShareToast(copied?'Link copied':'Unable to copy link');
 }finally{snapshotSharePending=false;}
}
function closeSnapshotDialog({restoreFocus=true}={}){
 if(!snapshotDialog.classList.contains('is-open'))return;
 clearTimeout(shareToastTimer);shareToastTimer=0;shareToast.classList.remove('is-visible');shareToast.textContent='';snapshotSharePointerType='';
 snapshotDialog.classList.remove('is-open');viewer.classList.remove('snapshot-open');snapshotDialog.hidden=true;snapshotDialog.setAttribute('aria-hidden','true');snapshotCard.style.removeProperty('width');snapshotImage.removeAttribute('src');if(snapshotDataUrl)URL.revokeObjectURL(snapshotDataUrl);snapshotDataUrl='';reportEmbeddedChildViewState();
 controls.enabled=!galleryOverlay.classList.contains('is-open');if(restoreFocus)arrangeSnapshot.focus();syncTvVideoPlayback();scheduleSceneAnimation();requestMainRender();
}
async function openSnapshotDialog(){
 if(!arrangeModeActive)return;
 const outlineVisible=arrangeSelectionHelper.visible,gridVisible=arrangeSurfaceGrid.group.visible;arrangeSelectionHelper.visible=false;arrangeSurfaceGrid.group.visible=false;invalidateReflectors();const snapshotCamera=createCenteredSnapshotCamera(camera);renderer.render(scene,snapshotCamera);
 const snapshotPromise=captureCanvasAtAspect(renderer.domElement,{aspectWidth:desktopHoverQuery.matches?4:3,aspectHeight:desktopHoverQuery.matches?3:4});
 arrangeSelectionHelper.visible=outlineVisible;arrangeSurfaceGrid.group.visible=gridVisible;invalidateReflectors();requestMainRender();
 const blob=await snapshotPromise;if(!blob||!arrangeModeActive)return;if(snapshotDataUrl)URL.revokeObjectURL(snapshotDataUrl);snapshotDataUrl=URL.createObjectURL(blob);
 snapshotImage.src=snapshotDataUrl;snapshotDialog.hidden=false;viewer.classList.add('snapshot-open');snapshotDialog.classList.add('is-open');snapshotDialog.setAttribute('aria-hidden','false');controls.enabled=false;reportEmbeddedChildViewState();syncTvVideoPlayback();scheduleSceneAnimation();requestAnimationFrame(updateSnapshotCardWidth);snapshotSave.focus();
}
window.addEventListener('resize',updateSnapshotCardWidth);window.visualViewport?.addEventListener('resize',updateSnapshotCardWidth);
snapshotImage.addEventListener('load',updateSnapshotCardWidth);
function triggerMobileControlHaptic(event){
 if(event.isTrusted&&event.detail!==0&&(event.pointerType==='touch'||mobileControlTouchQuery.matches)&&typeof navigator.vibrate==='function'){
  try{navigator.vibrate(12);}catch{}
 }
}
function bindMobileControlHaptic(button,{onPointerDown}={}){
 button.addEventListener('click',triggerMobileControlHaptic,true);
 if(!('switch' in document.createElement('input')))return;
 const target=document.createElement('label'),input=document.createElement('input');
 target.className='mobile-control-haptic-target';target.setAttribute('aria-hidden','true');target.dataset.hapticFor=button.id;
 input.type='checkbox';input.setAttribute('switch','');input.id=`${button.id}-haptic-switch`;input.className='mobile-control-haptic-switch';input.setAttribute('aria-hidden','true');input.tabIndex=-1;target.htmlFor=input.id;target.append(input);
 // Append outside the button sequence so its shared border joins stay intact.
 button.parentElement.append(target);mobileControlHapticTargets.push({button,target,input});
 input.addEventListener('change',()=>{
  button.click();
  requestAnimationFrame(()=>{if(document.activeElement===input)button.focus({preventScroll:true});});
 });
 if(onPointerDown)target.addEventListener('pointerdown',onPointerDown,{passive:true});
}
function syncMobileControlHapticTargets(){
 for(const {button,target,input} of mobileControlHapticTargets){
  const touch=mobileControlTouchQuery.matches;target.hidden=!touch;input.hidden=!touch;input.disabled=button.disabled;
  if(!touch)continue;
  target.style.top=`${button.offsetTop}px`;target.style.left=`${button.offsetLeft}px`;target.style.width=`${button.offsetWidth}px`;target.style.height=`${button.offsetHeight}px`;
 }
}
function syncArrangeHapticControl(){
 if(!arrangeHapticSwitch)return;
 const touch=mobileControlTouchQuery.matches;
 arrangeHapticSwitch.parentElement.hidden=!touch;arrangeHapticSwitch.hidden=!touch;arrangeHapticSwitch.checked=arrangeModeActive;
 if(touch)arrangeToggle.setAttribute('aria-hidden','true');else arrangeToggle.removeAttribute('aria-hidden');
 arrangeToggle.tabIndex=touch?-1:0;
}
function setArrangeMode(active){
 const next=Boolean(active);if(next===arrangeModeActive)return;
 if(!next){closeSnapshotDialog({restoreFocus:false});closeActiveCatalogItem();if(arrangeDrag)finishArrangeDrag({pointerId:arrangeDrag.pointerId},{cancel:true});selectArrangeItem(null);}
 arrangeModeActive=next;if(!next)setSceneMotionQuality('arrange',false);arrangeControl.classList.toggle('is-active',next);arrangeToggle.setAttribute('aria-pressed',String(next));arrangeToggle.setAttribute('aria-label',next?'Exit Rearrange mode':'Enter Rearrange mode');renderer.domElement.classList.toggle('is-arrange-active',next);renderer.domElement.setAttribute('aria-label',next?'Rearrange house items: select an item, then drag to move it':`${projectConfig.title} interactive house model`);
 syncArrangeHapticControl();
 const treeLayerInput=layerInputs.find(input=>input.dataset.layer==='trees');layers.trees.visible=!next;if(treeLayerInput)treeLayerInput.checked=!next;updateLayerMenuHiddenState();
 if(next){cancelIntroCamera();closeActiveCatalogItem();setDescriptionOpen(false);setAudioPlayerOpen(false);setLayerMenuOpen(false);}else renderer.domElement.classList.remove('is-arrange-hovered','is-arrange-dragging');
 updateLandscape();syncArrangeGridVisibility();invalidateReflectors();invalidateShadows();
 updateArrangeHistoryControls();requestMainRender();
}
arrangeToggle.onclick=event=>{
 triggerMobileControlHaptic(event);
 setArrangeMode(!arrangeModeActive);
};
if('switch' in document.createElement('input')){
 // WebKit emits a haptic only for a trusted native-switch activation. Hide
 // only its paint, preserving its native appearance and real tap target.
 arrangeHapticSwitch=document.createElement('input');arrangeHapticSwitch.type='checkbox';arrangeHapticSwitch.setAttribute('switch','');arrangeHapticSwitch.id='arrange-haptic-switch';arrangeHapticSwitch.className='arrange-haptic-switch';arrangeHapticSwitch.setAttribute('aria-label','Rearrange mode');arrangeHapticSwitch.setAttribute('aria-controls','arrange-actions');
 const target=document.createElement('label');target.className='arrange-haptic-target';target.htmlFor=arrangeHapticSwitch.id;target.append(arrangeHapticSwitch);arrangeToggle.after(target);arrangeHapticSwitch.addEventListener('change',()=>setArrangeMode(arrangeHapticSwitch.checked));
 mobileControlTouchQuery.addEventListener('change',syncArrangeHapticControl);syncArrangeHapticControl();
}
arrangeUndo.onclick=undoArrangeChange;arrangeRedo.onclick=redoArrangeChange;arrangeSnapshot.onclick=openSnapshotDialog;arrangeRotateLeft.onclick=()=>rotateSelectedArrangeItem(-1);arrangeRotateRight.onclick=()=>rotateSelectedArrangeItem(1);arrangeDuplicate.onclick=duplicateSelectedArrangeItem;arrangeDelete.onclick=deleteSelectedArrangeItem;
updateArrangeHistoryControls();
snapshotSave.onclick=()=>{if(!snapshotDataUrl)return;const link=document.createElement('a');link.href=snapshotDataUrl;link.download=`house-arrangement-${new Date().toISOString().slice(0,10)}.png`;link.click();closeSnapshotDialog();};
snapshotShare.addEventListener('pointerdown',event=>{snapshotSharePointerType=event.pointerType;});snapshotShare.addEventListener('pointercancel',()=>{snapshotSharePointerType='';});snapshotShare.onclick=handleSnapshotShare;
snapshotDialog.addEventListener('pointerdown',event=>{if(event.target===snapshotDialog)closeSnapshotDialog();});
let pendingArrangePointer=null,arrangePointerFrame=0;
function flushArrangePointer(){
 arrangePointerFrame=0;const event=pendingArrangePointer;pendingArrangePointer=null;if(!event||!arrangeModeActive)return;
 if(arrangeDrag)updateArrangeDrag(event);else renderer.domElement.classList.toggle('is-arrange-hovered',Boolean(arrangeItemAtPointer(event)));
}
function queueArrangePointer(event){
 pendingArrangePointer={pointerId:event.pointerId,clientX:event.clientX,clientY:event.clientY,buttons:event.buttons};
 if(!arrangePointerFrame)arrangePointerFrame=requestAnimationFrame(flushArrangePointer);
}
renderer.domElement.addEventListener('pointerdown',event=>{
 if(!arrangeModeActive||event.button!==0||galleryOverlay.classList.contains('is-open')||snapshotDialog.classList.contains('is-open'))return;
 const item=arrangeItemAtPointer(event);if(!item){selectArrangeItem(null);return;}
 event.preventDefault();event.stopImmediatePropagation();renderer.domElement.focus({preventScroll:true});selectArrangeItem(item);beginArrangeDrag(event,item);
},true);
renderer.domElement.addEventListener('pointermove',event=>{
 if(!arrangeModeActive)return;
 if(arrangeDrag){event.preventDefault();event.stopImmediatePropagation();}
 queueArrangePointer(event);
},true);
renderer.domElement.addEventListener('pointerup',event=>{if(arrangeDrag){event.preventDefault();event.stopImmediatePropagation();if(pendingArrangePointer?.pointerId===event.pointerId){pendingArrangePointer.clientX=event.clientX;pendingArrangePointer.clientY=event.clientY;if(arrangePointerFrame)cancelAnimationFrame(arrangePointerFrame);arrangePointerFrame=0;flushArrangePointer();}finishArrangeDrag(event);}},true);
renderer.domElement.addEventListener('pointercancel',event=>{if(arrangeDrag){event.stopImmediatePropagation();pendingArrangePointer=null;if(arrangePointerFrame)cancelAnimationFrame(arrangePointerFrame);arrangePointerFrame=0;finishArrangeDrag(event,{cancel:true});}},true);
renderer.domElement.addEventListener('pointerleave',()=>{if(!arrangeDrag){pendingArrangePointer=null;if(arrangePointerFrame)cancelAnimationFrame(arrangePointerFrame);arrangePointerFrame=0;renderer.domElement.classList.remove('is-arrange-hovered');}});
document.addEventListener('keydown',event=>{
 if(snapshotDialog.classList.contains('is-open')){if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();closeSnapshotDialog();}return;}
 if(!arrangeModeActive||galleryOverlay.classList.contains('is-open'))return;
 const target=event.target,editingText=target instanceof HTMLInputElement||target instanceof HTMLTextAreaElement||target?.isContentEditable;
 if(editingText)return;
 if((event.metaKey||event.ctrlKey)&&event.key.toLowerCase()==='z'){event.preventDefault();event.stopImmediatePropagation();if(event.shiftKey)redoArrangeChange();else undoArrangeChange();return;}
 if((event.metaKey||event.ctrlKey)&&event.key.toLowerCase()==='y'){event.preventDefault();event.stopImmediatePropagation();redoArrangeChange();return;}
 if((event.key==='Delete'||event.key==='Backspace')&&selectedArrangeItem){event.preventDefault();event.stopImmediatePropagation();deleteSelectedArrangeItem();return;}
 if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();if(selectedArrangeItem)selectArrangeItem(null);else setArrangeMode(false);}
},true);
const modelInteractionRaycaster=new THREE.Raycaster(),modelInteractionPointer=new THREE.Vector2(),modelInteractionMeshSet=new Set(modelInteractionMeshes),modelOcclusionMeshes=[],visibleModelOcclusionMeshes=[];
function isDescendantOf(object,ancestor){for(let current=object;current;current=current.parent)if(current===ancestor)return true;return false;}
function materialCanOccludeInteraction(material){
 if(!material||material.visible===false||(material.opacity??1)<=.01||material.alphaTest>0)return false;
 return !material.transparent||(material.opacity??1)>=.98;
}
scene.traverse(object=>{
 if(!object.isMesh||object.userData.nightViewEffect||modelInteractionMeshSet.has(object)||galleryGrid&&isDescendantOf(object,galleryGrid))return;
 const materials=Array.isArray(object.material)?object.material:[object.material];
 if(materials.some(materialCanOccludeInteraction))modelOcclusionMeshes.push(object);
});
function isEffectivelyVisible(object){for(let current=object;current;current=current.parent)if(current.visible===false)return false;return true;}
function hitMaterial(hit){
 const material=hit.object.material;if(!Array.isArray(material))return material;
 return material[hit.face?.materialIndex??0];
}
function interactionIsOccluded(interactionHit){
 visibleModelOcclusionMeshes.length=0;for(const object of modelOcclusionMeshes)if(isEffectivelyVisible(object))visibleModelOcclusionMeshes.push(object);
 const previousFar=modelInteractionRaycaster.far;modelInteractionRaycaster.far=Math.max(modelInteractionRaycaster.near,interactionHit.distance-1e-4);
 const blockers=modelInteractionRaycaster.intersectObjects(visibleModelOcclusionMeshes,false);modelInteractionRaycaster.far=previousFar;
 return blockers.some(hit=>materialCanOccludeInteraction(hitMaterial(hit)));
}
function galleryPhotoFacesCamera(photo){
 photo.updateWorldMatrix(true,false);const normal=new THREE.Vector3(0,0,1).transformDirection(photo.matrixWorld);
 // Orthographic rays are parallel, so use the actual pick-ray direction rather
 // than a perspective-style vector from the frame to the camera position.
 return normal.dot(modelInteractionRaycaster.ray.direction)<-1e-3;
}
function modelInteractionAtPointer(event){
 if(arrangeModeActive||galleryOverlay.classList.contains('is-open'))return null;
 const rect=renderer.domElement.getBoundingClientRect();modelInteractionPointer.set((event.clientX-rect.left)/rect.width*2-1,-(event.clientY-rect.top)/rect.height*2+1);
 modelInteractionRaycaster.setFromCamera(modelInteractionPointer,camera);const hit=modelInteractionRaycaster.intersectObjects(modelInteractionMeshes,false).find(result=>isEffectivelyVisible(result.object));
 if(!hit)return null;
 const galleryIndex=hit.object.userData.galleryIndex,photo=galleryPhotoForHit(hit.object)||galleryPhotoMeshes[galleryIndex];
 if(hit.object.userData.interaction==='gallery'&&(!photo||!galleryPhotoFacesCamera(photo))||interactionIsOccluded(hit))return null;
 const interaction=hit.object.userData.interaction;
 if(interaction==='gallery')return{type:'gallery',key:`gallery:${galleryIndex}`,galleryIndex,photo};
 if(interaction==='fireplace')return{type:'fireplace',key:'fireplace'};
 return{type:'audio',key:'audio'};
}
const modelControlSuppressedPointers=new Set();
renderer.domElement.addEventListener('pointerdown',event=>{
 // Plan drags can start over a hotspot; stationary taps still activate on release.
 if(mode==='plan')return;
 const interaction=modelInteractionAtPointer(event);
 if(!interaction||interaction.type==='fireplace')return;
 modelControlSuppressedPointers.add(event.pointerId);controls.enabled=false;
},true);
const releaseSuppressedModelControl=event=>{
 if(!modelControlSuppressedPointers.delete(event.pointerId)||modelControlSuppressedPointers.size)return;
 if(!galleryOverlay.classList.contains('is-open'))controls.enabled=true;
};
window.addEventListener('pointerup',releaseSuppressedModelControl,true);
window.addEventListener('pointercancel',releaseSuppressedModelControl,true);
function setModelInteractiveHover(hovered){renderer.domElement.classList.toggle('is-model-interactive-hovered',!arrangeModeActive&&hovered);}
const clearModelDraggingCursor=()=>renderer.domElement.classList.remove('is-model-dragging');
controls.addEventListener('start',()=>{renderer.domElement.classList.add('is-model-dragging');setModelInteractiveHover(false);});
controls.addEventListener('end',clearModelDraggingCursor);
renderer.domElement.addEventListener('lostpointercapture',clearModelDraggingCursor);
window.addEventListener('blur',clearModelDraggingCursor);
let pendingModelHoverPointer=null,modelHoverFrame=0;
renderer.domElement.addEventListener('pointermove',event=>{
 pendingModelHoverPointer={clientX:event.clientX,clientY:event.clientY,buttons:event.buttons};if(modelHoverFrame)return;
 modelHoverFrame=requestAnimationFrame(()=>{modelHoverFrame=0;const pointer=pendingModelHoverPointer;pendingModelHoverPointer=null;if(pointer)setModelInteractiveHover(pointer.buttons===0&&Boolean(modelInteractionAtPointer(pointer)));});
});
renderer.domElement.addEventListener('pointerdown',()=>setModelInteractiveHover(false));
renderer.domElement.addEventListener('pointerup',event=>setModelInteractiveHover(Boolean(modelInteractionAtPointer(event))));
renderer.domElement.addEventListener('pointerleave',()=>{pendingModelHoverPointer=null;if(modelHoverFrame)cancelAnimationFrame(modelHoverFrame);modelHoverFrame=0;setModelInteractiveHover(false);});
let activeCatalogItem=null,activeCatalogClose=null,catalogRepositionFrame=0,catalogMomentumFrame=0,catalogMomentumVelocity=0,catalogMomentumLastTime=0,catalogSuppressClickUntil=0;
const catalogTouchDragGain=1.3,catalogMomentumDecayMs=180,catalogMomentumMaxVelocity=1.6;
function stopCatalogRepositioning(){if(catalogRepositionFrame)cancelAnimationFrame(catalogRepositionFrame);catalogRepositionFrame=0;}
function stopCatalogMomentum(){if(catalogMomentumFrame)cancelAnimationFrame(catalogMomentumFrame);catalogMomentumFrame=0;catalogMomentumVelocity=0;catalogMomentumLastTime=0;}
function startCatalogMomentum(velocity){
 stopCatalogMomentum();
 if(reducedMotionQuery?.matches||Math.abs(velocity)<.02)return;
 catalogMomentumVelocity=THREE.MathUtils.clamp(velocity,-catalogMomentumMaxVelocity,catalogMomentumMaxVelocity);catalogMomentumLastTime=performance.now();
 const follow=now=>{
  catalogMomentumFrame=0;const elapsed=Math.min(32,Math.max(1,now-catalogMomentumLastTime)),current=catalogStrip.scrollLeft,max=Math.max(0,catalogStrip.scrollWidth-catalogStrip.clientWidth),next=THREE.MathUtils.clamp(current+catalogMomentumVelocity*elapsed,0,max);
  catalogMomentumLastTime=now;catalogStrip.scrollLeft=next;catalogMomentumVelocity*=Math.exp(-elapsed/catalogMomentumDecayMs);
  if(Math.abs(next-current)<.01||Math.abs(catalogMomentumVelocity)<.015){stopCatalogMomentum();return;}
  catalogMomentumFrame=requestAnimationFrame(follow);
 };
 catalogMomentumFrame=requestAnimationFrame(follow);
}
function preserveCatalogPosition(change){
 const beforePadding=parseFloat(getComputedStyle(catalogTrack).paddingLeft)||0,beforeScroll=catalogStrip.scrollLeft;change();
 const afterPadding=parseFloat(getComputedStyle(catalogTrack).paddingLeft)||0;catalogStrip.scrollLeft=beforeScroll+afterPadding-beforePadding;
}
function repositionCatalogItem(item){
 stopCatalogMomentum();stopCatalogRepositioning();const mobileMotion=window.matchMedia('(hover: none), (pointer: coarse)').matches,start=performance.now(),duration=200;let leftCorrectionActive=false;
 const follow=now=>{
  catalogRepositionFrame=0;if(activeCatalogItem!==item)return;
  const stripRect=catalogStrip.getBoundingClientRect(),itemRect=item.getBoundingClientRect(),clearance=Math.min(itemRect.width,Math.max(0,(stripRect.width-itemRect.width)/2)),rightOverflow=itemRect.right-(stripRect.right-clearance),leftAdjustment=itemRect.left-(stripRect.left+clearance),trackLeftPadding=parseFloat(getComputedStyle(catalogTrack).paddingLeft)||0,leftContentHidden=catalogStrip.scrollLeft-trackLeftPadding>.5,finished=now-start>=duration;
  if(!leftCorrectionActive&&leftContentHidden&&leftAdjustment<0)leftCorrectionActive=true;
  const adjustment=rightOverflow>0?rightOverflow:leftCorrectionActive&&leftAdjustment<0?leftAdjustment:0;
  if(adjustment)catalogStrip.scrollLeft+=finished?adjustment:adjustment*(mobileMotion ? .46 : .3);
  if(!finished)catalogRepositionFrame=requestAnimationFrame(follow);
 };
 catalogRepositionFrame=requestAnimationFrame(follow);
}
function closeActiveCatalogItem(){
 if(!activeCatalogItem)return;
 // Closing only dismisses the catalog presentation. Freeze any in-flight focus
 // move and retain its final projection so the model does not jump when the
 // expanded mobile cell (and its temporary viewport lift) disappears.
 cancelProductFocusCamera();stopCatalogMomentum();stopCatalogRepositioning();preserveCatalogPosition(()=>activeCatalogItem.classList.remove('is-expanded'));activeCatalogClose?.();activeCatalogItem=null;activeCatalogClose=null;requestMainRender();requestAnimationFrame(updateLayerControlsLayout);
}
function closeActiveCatalogOnEscape(event){
 if(event.key!=='Escape'||!desktopHoverQuery.matches||!activeCatalogItem)return;
 if(layerMenu.classList.contains('is-open')||audioControl.classList.contains('is-open')||descriptionControl.classList.contains('is-open')||galleryOverlay.classList.contains('is-open')||snapshotDialog.classList.contains('is-open')||arrangeModeActive)return;
 event.preventDefault();closeActiveCatalogItem();
}
document.addEventListener('keydown',closeActiveCatalogOnEscape,true);
function requestEmbeddedHouseCloseOnEscape(event){
 if(event.key!=='Escape'||event.repeat||event.defaultPrevented)return;
 if(layerMenu.classList.contains('is-open')||audioControl.classList.contains('is-open')||descriptionControl.classList.contains('is-open')||galleryOverlay.classList.contains('is-open')||snapshotDialog.classList.contains('is-open')||arrangeModeActive||desktopHoverQuery.matches&&activeCatalogItem)return;
 if(!embeddedHostBridge.requestClose())return;
 event.preventDefault();event.stopImmediatePropagation();
}
document.addEventListener('keydown',requestEmbeddedHouseCloseOnEscape,true);
function selectCatalogItem(item,onOpen,onClose){
 stopCatalogMomentum();stopCatalogRepositioning();setDescriptionOpen(false);setAudioPlayerOpen(false);
 if(activeCatalogItem===item){repositionCatalogItem(item);return;}
 const previousItem=activeCatalogItem,previousClose=activeCatalogClose;
 if(item.classList.contains('material-item')){
  item.classList.remove('material-image-anchor-left','material-image-anchor-right');
  if(previousItem?.classList.contains('material-item')){
   const targetIsLeft=Boolean(item.compareDocumentPosition(previousItem)&Node.DOCUMENT_POSITION_FOLLOWING);
   item.classList.add(targetIsLeft?'material-image-anchor-left':'material-image-anchor-right');
  }else item.classList.add('material-image-anchor-left');
 }
 if(previousItem)previousItem.classList.add('is-switching-out');
 preserveCatalogPosition(()=>{previousItem?.classList.remove('is-expanded');item.classList.remove('is-switching-out');item.classList.add('is-expanded');});
 if(previousItem){
  let fallbackTimer=0,finished=false;const finish=()=>{if(finished)return;finished=true;previousItem.removeEventListener('transitionend',onTransitionEnd);clearTimeout(fallbackTimer);requestAnimationFrame(()=>previousItem.classList.remove('is-switching-out'));},onTransitionEnd=event=>{if(event.target===previousItem&&event.propertyName==='height')finish();};
  previousItem.addEventListener('transitionend',onTransitionEnd);fallbackTimer=setTimeout(finish,360);
 }
 activeCatalogItem=item;activeCatalogClose=onClose;
 previousClose?.();onOpen();repositionCatalogItem(item);requestAnimationFrame(updateLayerControlsLayout);
}
function bindCatalogItem(item,onOpen,onClose){
 let gesture=null;
 item.addEventListener('pointerdown',event=>{
  if(event.pointerType!=='touch')return;
  stopCatalogMomentum();stopCatalogRepositioning();gesture={id:event.pointerId,x:event.clientX,y:event.clientY,lastX:event.clientX,lastTime:performance.now(),velocity:0,moved:false};
  item.setPointerCapture?.(event.pointerId);
 });
 item.addEventListener('pointermove',event=>{
  if(!gesture||event.pointerId!==gesture.id)return;
  const dx=event.clientX-gesture.x,dy=event.clientY-gesture.y;
  if(Math.hypot(dx,dy)>7)gesture.moved=true;
  if(!gesture.moved)return;
  const now=performance.now(),elapsed=Math.min(50,Math.max(1,now-gesture.lastTime)),current=catalogStrip.scrollLeft,max=Math.max(0,catalogStrip.scrollWidth-catalogStrip.clientWidth),next=THREE.MathUtils.clamp(current-(event.clientX-gesture.lastX)*catalogTouchDragGain,0,max),sampleVelocity=(next-current)/elapsed;
  catalogStrip.scrollLeft=next;gesture.velocity=gesture.velocity*.55+sampleVelocity*.45;gesture.lastX=event.clientX;gesture.lastTime=now;event.preventDefault();
 });
 item.addEventListener('pointerup',event=>{
  if(!gesture||event.pointerId!==gesture.id)return;
  item.releasePointerCapture?.(event.pointerId);const tapped=!gesture.moved,idleTime=Math.max(0,performance.now()-gesture.lastTime),releaseVelocity=gesture.velocity*Math.exp(-Math.max(0,idleTime-80)/250);gesture=null;catalogSuppressClickUntil=performance.now()+800;
  if(!tapped){startCatalogMomentum(releaseVelocity);return;}
  selectCatalogItem(item,onOpen,onClose);
 });
 item.addEventListener('pointercancel',()=>{stopCatalogMomentum();gesture=null;catalogSuppressClickUntil=performance.now()+800;});
 item.addEventListener('click',()=>selectCatalogItem(item,onOpen,onClose));
}
catalogStrip.addEventListener('click',event=>{
 if(event.detail===0||performance.now()>=catalogSuppressClickUntil)return;
 event.preventDefault();event.stopPropagation();
},true);
function closeCatalogFromOutside(event){
 if(!activeCatalogItem||activeCatalogItem.contains(event.target)||event.target.closest?.('.product-item,.material-item'))return;
 // Normal model navigation waits for a stationary pointerup before closing so
 // orbit gestures preserve catalog focus. Rearrange owns the canvas gesture,
 // so dismiss its expanded cell immediately and let selection/dragging proceed.
 if(event.target.closest?.('#scene')&&!arrangeModeActive)return;
 closeActiveCatalogItem();
}
viewer.addEventListener('pointerdown',closeCatalogFromOutside,true);
const modelPointerGestures=new Map();let modelGestureWasMultiTouch=false;
renderer.domElement.addEventListener('pointerdown',event=>{
 if(arrangeModeActive)return;
 const interaction=modelInteractionAtPointer(event);
 modelPointerGestures.set(event.pointerId,{x:event.clientX,y:event.clientY,moved:false,interactionKey:interaction?.key??null});
 if(modelPointerGestures.size>1)modelGestureWasMultiTouch=true;
});
renderer.domElement.addEventListener('pointermove',event=>{
 const gesture=modelPointerGestures.get(event.pointerId);if(!gesture)return;
 // Model manipulation must preserve catalog selection. Only a stationary
 // viewport click/tap collapses it in the pointerup handler below.
 if(Math.hypot(event.clientX-gesture.x,event.clientY-gesture.y)>7)gesture.moved=true;
});
renderer.domElement.addEventListener('pointerup',event=>{
 const gesture=modelPointerGestures.get(event.pointerId);if(!gesture)return;
 const collapse=!modelGestureWasMultiTouch&&!gesture.moved;modelPointerGestures.delete(event.pointerId);
 if(modelPointerGestures.size===0)modelGestureWasMultiTouch=false;
 if(collapse){
  const interaction=modelInteractionAtPointer(event);
  if(interaction&&interaction.key===gesture.interactionKey){
   if(interaction.type==='gallery')openGallery(interaction.galleryIndex,renderer.domElement,interaction.photo);
   else if(interaction.type==='audio'){setAudioPlayerOpen(true);toggleAudioPlayback();}
   else if(interaction.type==='fireplace'){toggleFireplaceFire(fireplace);scheduleSceneAnimation();requestMainRender();}
  }else closeActiveCatalogItem();
 }
});
renderer.domElement.addEventListener('pointercancel',event=>{
 modelPointerGestures.delete(event.pointerId);if(modelPointerGestures.size===0)modelGestureWasMultiTouch=false;
});
let pendingCatalogImages=displayedProducts.length+displayedMaterials.length;
function trackCatalogImage(image,thumbnail){
 let resolved=false;
 const ready=()=>{
  if(resolved)return;resolved=true;if(image.naturalWidth)thumbnail.classList.add('is-ready');pendingCatalogImages--;
  if(pendingCatalogImages===0)catalogStrip.classList.remove('catalog-loading');
 };
 image.addEventListener('load',ready,{once:true});image.addEventListener('error',ready,{once:true});return ready;
}
function buildMaterialStrip(){
 const list=document.querySelector('#material-strip-list');
 list.replaceChildren();
 for(const material of displayedMaterials){
  const asset=materialAssets[material.assetKey];
  const item=document.createElement('td');item.className='material-item';item.dataset.materialId=material.id;item.dataset.material=material.id;item.setAttribute('aria-label',material.name);
  const thumbnail=document.createElement('div');thumbnail.className='material-thumbnail';
  const image=document.createElement('img');image.alt=material.name;const ready=trackCatalogImage(image,thumbnail);image.src=asset.image;if(image.complete)queueMicrotask(ready);
  const meta=document.createElement('div');meta.className='product-meta';
  const name=document.createElement('strong');name.className='product-meta-name';name.textContent=material.name;
  const usage=document.createElement('span');usage.className='product-meta-variant';usage.textContent=material.usage;
  const file=document.createElement('span');file.className='product-meta-dimensions';file.textContent=material.file;
  meta.append(name,usage,file);thumbnail.append(image,meta);item.appendChild(thumbnail);list.appendChild(item);
  bindCatalogItem(item,()=>{const targets=highlightMaterial(asset);focusHouseMaterial(material.assetKey,asset,targets);},clearProductHighlight);
 }
}
buildMaterialStrip();

const dimmedObjects=new Map(),dimmedMaterials=new Map(),dimColor=new THREE.Color('#eeeeee'),materialObjects=[];
scene.traverse(object=>{if(object.material&&!object.isReflector&&!object.userData.arrangeHelper&&!object.userData.arrangePickProxy&&!object.userData.arrangeGrid)materialObjects.push(object);});
let treeVisibilityBeforeHighlight=null;
function clearProductHighlight(){
 for(const [object,material] of dimmedObjects)object.material=material;
 dimmedObjects.clear();
 if(treeVisibilityBeforeHighlight!==null){layers.trees.visible=treeVisibilityBeforeHighlight;treeVisibilityBeforeHighlight=null;}
 invalidateReflectors();requestMainRender();
}
function hideTreesForHighlight(){treeVisibilityBeforeHighlight=layers.trees.visible;layers.trees.visible=false;requestMainRender();}
function rootsForProduct(id){return[...layers.furniture.children,...layers.lighting.children].filter(root=>!root.userData.arrangeDeleted&&isEffectivelyVisible(root)&&(root.userData.productId===id||root.userData.catalogProductId===id));}
function highlightProduct(id){
 clearProductHighlight();
 const roots=rootsForProduct(id);
 if(!roots.length)return;
 hideTreesForHighlight();
 const highlightedObjects=new Set();roots.forEach(root=>root.traverse(object=>highlightedObjects.add(object)));
 applyMonochromeExcept(highlightedObjects);
}
function highlightMaterial(asset){
 clearProductHighlight();
 const targets=materialObjects.filter(object=>objectMatchesMaterialAsset(object,asset)),highlightedObjects=new Set();
 for(const object of targets)object.traverse(descendant=>highlightedObjects.add(descendant));
 if(highlightedObjects.size){hideTreesForHighlight();applyMonochromeExcept(highlightedObjects);}
 return targets;
}
function applyMonochromeExcept(highlightedObjects){
 const dimMaterial=material=>{
  if(dimmedMaterials.has(material))return dimmedMaterials.get(material);
  const gray=material.clone();
  if(gray.color)gray.color.copy(dimColor);
  // Preserve authored vertex colors while dimming unrelated scene objects.
  gray.vertexColors=false;
  if(gray.emissive)gray.emissive.set(0x000000);
  if('map' in gray)gray.map=null;
  if('emissiveMap' in gray)gray.emissiveMap=null;
  if('metalness' in gray)gray.metalness=0;
  if('roughness' in gray)gray.roughness=1;
  if('transmission' in gray)gray.transmission=0;
   gray.needsUpdate=true;dimmedMaterials.set(material,gray);return gray;
 };
 for(const object of materialObjects){
  if(!object.material||highlightedObjects.has(object))continue;
 dimmedObjects.set(object,object.material);
 object.material=Array.isArray(object.material)?object.material.map(dimMaterial):dimMaterial(object.material);
 }
 invalidateReflectors();requestMainRender();
}

function buildProductStrip(){
 const list=document.querySelector('#product-strip-list');
 list.replaceChildren();
 let previewRenderer=null;
 function ensurePreviewRenderer(){
  if(previewRenderer)return previewRenderer;
  previewRenderer=new THREE.WebGLRenderer({antialias:true,alpha:true});
  previewRenderer.setPixelRatio(Math.min(devicePixelRatio,2));previewRenderer.setSize(100,100,false);
  previewRenderer.outputColorSpace=THREE.SRGBColorSpace;previewRenderer.toneMapping=THREE.ACESFilmicToneMapping;previewRenderer.toneMappingExposure=.9;
  previewRenderer.setClearColor(0x000000,0);previewRenderer.domElement.setAttribute('aria-hidden','true');return previewRenderer;
 }
 function releasePreviewRenderer(){
  if(!previewRenderer)return;previewRenderer.domElement.remove();previewRenderer.dispose();previewRenderer.forceContextLoss?.();previewRenderer=null;
 }
 const previewScene=new THREE.Scene();
 previewScene.add(new THREE.HemisphereLight('#ffffff','#aaa8a3',2.2));
 const previewLight=new THREE.DirectionalLight('#fff7ed',2.4);previewLight.position.set(-3,6,4);previewScene.add(previewLight);
 previewScene.add(new THREE.AmbientLight('#ffffff',.5));
 const previewCamera=new THREE.OrthographicCamera(-1,1,1,-1,.001,100);
 const entries=displayedProducts.map(product=>{
  const item=document.createElement('td');item.className='product-item';item.dataset.productId=product.id;item.setAttribute('aria-label',`${product.brand} · ${product.name} · ${product.finish}`);
  const circle=document.createElement('div');circle.className='product-thumbnail';
  const image=document.createElement('img');image.alt=`${product.name} by ${product.brand}`;image.width=100;image.height=100;const ready=trackCatalogImage(image,circle);
  const meta=document.createElement('div');meta.className='product-meta';
  const name=document.createElement('strong');name.className='product-meta-name';name.textContent=`${product.brand} ${product.name}`;
  const variant=document.createElement('span');variant.className='product-meta-variant';variant.textContent=product.finish;
  const dimensions=document.createElement('span');dimensions.className='product-meta-dimensions';dimensions.textContent=formatProductDimensions(product.size,projectConfig.units);
  meta.append(name,variant,dimensions);circle.append(image,meta);item.appendChild(circle);list.appendChild(item);
  image.src=productThumbnailSources[product.id];if(image.complete)queueMicrotask(ready);
  return {product,item,circle,image,ready};
 });
 function createPreview(product){
  const root=createProduct(product.id,{showSuspension:Boolean(product.pendant)}),body=root.getObjectByName('product body'),bounds=new THREE.Box3().setFromObject(body);
  const center=bounds.getCenter(new THREE.Vector3()),pivot=new THREE.Group();root.position.x-=center.x;root.position.z-=center.z;pivot.add(root);pivot.userData={previewPivot:true,productId:product.id};return pivot;
 }
 function framedPreviewRoots(root,includeSuspension=false){
  const roots=[root.getObjectByName('product body')],suspension=root.getObjectByName('adjustable suspension');
  if(includeSuspension&&suspension)roots.push(suspension);return roots.filter(Boolean);
 }
 const previewCorner=new THREE.Vector3();
 function centerPreviewCamera(root,includeSuspension=false){
  root.updateWorldMatrix(true,true);previewCamera.updateMatrixWorld(true);
  let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
  for(const framedRoot of framedPreviewRoots(root,includeSuspension))framedRoot.traverse(object=>{
   if(!object.geometry||(!object.isMesh&&!object.isLineSegments))return;
   object.geometry.computeBoundingBox();const box=object.geometry.boundingBox;if(!box)return;
   for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z]){
    previewCorner.set(x,y,z).applyMatrix4(object.matrixWorld).applyMatrix4(previewCamera.matrixWorldInverse);minX=Math.min(minX,previewCorner.x);maxX=Math.max(maxX,previewCorner.x);minY=Math.min(minY,previewCorner.y);maxY=Math.max(maxY,previewCorner.y);
   }
  });
  if(!Number.isFinite(minX))return;
  const offsetX=(minX+maxX)/2,offsetY=(minY+maxY)/2;if(Math.abs(offsetX)<1e-6&&Math.abs(offsetY)<1e-6)return;
  const right=new THREE.Vector3().setFromMatrixColumn(previewCamera.matrixWorld,0),up=new THREE.Vector3().setFromMatrixColumn(previewCamera.matrixWorld,1),offset=right.multiplyScalar(offsetX).add(up.multiplyScalar(offsetY));
  previewCamera.position.add(offset);previewCamera.userData.previewTarget.add(offset);previewCamera.lookAt(previewCamera.userData.previewTarget);previewCamera.updateMatrixWorld(true);
 }
 function framePreview(root,aspect=1,includeSuspension=false){
  const body=root.getObjectByName('product body'),bounds=new THREE.Box3().setFromObject(body);
  const suspension=root.getObjectByName('adjustable suspension');if(includeSuspension&&suspension)bounds.expandByObject(suspension);
  const center=bounds.getCenter(new THREE.Vector3()),sphere=bounds.getBoundingSphere(new THREE.Sphere());
  const half=Math.max(sphere.radius*1.18,.08),direction=new THREE.Vector3(-1.2,.8,1.5).normalize();
  previewCamera.left=-half*aspect;previewCamera.right=half*aspect;previewCamera.top=half;previewCamera.bottom=-half;previewCamera.updateProjectionMatrix();
  previewCamera.position.copy(center).addScaledVector(direction,Math.max(sphere.radius*5,2));previewCamera.userData.previewTarget=center.clone();previewCamera.lookAt(center);centerPreviewCamera(root,includeSuspension);
 }
 const coarsePreviewPointer=window.matchMedia?.('(hover: none), (pointer: coarse)');
 let rotatingEntry=null,rotatingRoot=null,rotationFrame=0,previewRevealFrame=0,lastFrameTime=0,pendingRotation=null,pendingPreviewFrame=0,focusStartTimer=0,previewStartTimer=0;
 function stopRotation(){
  if(pendingRotation){pendingRotation.item.removeEventListener('transitionend',pendingRotation.listener);clearTimeout(pendingRotation.timeout);pendingRotation=null;}
  if(pendingPreviewFrame)cancelAnimationFrame(pendingPreviewFrame);pendingPreviewFrame=0;
  if(previewRevealFrame)cancelAnimationFrame(previewRevealFrame);previewRevealFrame=0;
  clearTimeout(focusStartTimer);focusStartTimer=0;
  clearTimeout(previewStartTimer);previewStartTimer=0;
  if(rotationFrame)cancelAnimationFrame(rotationFrame);rotationFrame=0;lastFrameTime=0;
  if(rotatingRoot){previewScene.remove(rotatingRoot);disposeProduct(rotatingRoot);rotatingRoot=null;}
  if(rotatingEntry){rotatingEntry.circle.classList.remove('is-rotating');rotatingEntry=null;}
  previewRenderer?.domElement.remove();clearProductHighlight();
 }
 function animateRotation(){
  const frameInterval=1000/(coarsePreviewPointer?.matches?24:30);
  const animate=time=>{
   if(!rotatingRoot)return;
   if(document.hidden||!appInViewport){stopRotation();return;}
   if(lastFrameTime&&time-lastFrameTime<frameInterval){rotationFrame=requestAnimationFrame(animate);return;}
   if(lastFrameTime)rotatingRoot.rotation.y+=(time-lastFrameTime)*.00045;
   lastFrameTime=time;ensurePreviewRenderer().render(previewScene,previewCamera);rotationFrame=requestAnimationFrame(animate);
  };
  rotationFrame=requestAnimationFrame(animate);
 }
 function prepareRotation(entry){
  rotatingRoot=createPreview(entry.product);previewScene.add(rotatingRoot);
  const renderer=ensurePreviewRenderer();renderer.setSize(240,240,false);framePreview(rotatingRoot,1,Boolean(entry.product.previewSuspension));
  entry.circle.appendChild(renderer.domElement);renderer.render(previewScene,previewCamera);
  previewRevealFrame=requestAnimationFrame(()=>{previewRevealFrame=0;if(rotatingEntry===entry&&rotatingRoot)entry.circle.classList.add('is-rotating');});
 }
 function beginRotation(entry){
  if(!rotatingRoot)prepareRotation(entry);lastFrameTime=0;
  animateRotation();
 }
 function startRotation(entry){
  stopRotation();rotatingEntry=entry;highlightProduct(entry.product.id);
  if(coarsePreviewPointer?.matches){
   // Paint the expanding cell first, then install its sharp static canvas. Start
   // the camera search after that handoff so the two costly phases never compete.
   pendingPreviewFrame=requestAnimationFrame(()=>{pendingPreviewFrame=requestAnimationFrame(()=>{
    pendingPreviewFrame=0;if(rotatingEntry!==entry||!entry.item.classList.contains('is-expanded'))return;
    if(!rotatingRoot)prepareRotation(entry);
    focusStartTimer=setTimeout(()=>{focusStartTimer=0;if(rotatingEntry===entry&&entry.item.classList.contains('is-expanded'))focusHouseProduct(entry.product.id);},120);
   });});
   previewStartTimer=setTimeout(()=>{previewStartTimer=0;if(rotatingEntry===entry&&entry.item.classList.contains('is-expanded'))beginRotation(entry);},520);
  }else{focusHouseProduct(entry.product.id);prepareRotation(entry);}
  let started=false;
  const finish=()=>{
   if(started)return;started=true;
   entry.item.removeEventListener('transitionend',listener);if(pendingRotation)clearTimeout(pendingRotation.timeout);pendingRotation=null;
   if(!coarsePreviewPointer?.matches&&rotatingEntry===entry&&(entry.item.matches(':hover')||entry.item.classList.contains('is-expanded')))beginRotation(entry);
  };
  const listener=event=>{
   if(event.propertyName!=='height')return;
   finish();
  };
  const timeout=setTimeout(finish,340);pendingRotation={item:entry.item,listener,timeout};entry.item.addEventListener('transitionend',listener);
 }
 const scheduleIdle=callback=>window.requestIdleCallback?requestIdleCallback(callback,{timeout:15000}):setTimeout(callback,1000);let previewPrewarmRetryTimer=0;
 const scroller=list.closest('.product-strip');scroller.addEventListener('wheel',event=>{
  if(Math.abs(event.deltaY)>Math.abs(event.deltaX)){event.preventDefault();scroller.scrollLeft+=event.deltaY;}
 },{passive:false});
 entries.forEach(entry=>bindCatalogItem(entry.item,()=>startRotation(entry),()=>{if(rotatingEntry===entry)stopRotation();}));
 const prepareCachedPreviewRenderer=()=>{
  previewPrewarmRetryTimer=0;
  if(startupNightWarmupPending||document.hidden||!appInViewport){previewPrewarmRetryTimer=setTimeout(()=>scheduleIdle(prepareCachedPreviewRenderer),500);return;}
  ensurePreviewRenderer();
 };
 if(coarsePreviewPointer?.matches)scheduleIdle(prepareCachedPreviewRenderer);
 window.addEventListener('pagehide',event=>{if(event.persisted)return;clearTimeout(previewPrewarmRetryTimer);previewPrewarmRetryTimer=0;releasePreviewRenderer();});
 return{stopRotation};
}
const productStripController=buildProductStrip();
const hemisphere=new THREE.HemisphereLight('#ffffff','#aaa8a3',2.4);scene.add(hemisphere);
const sun=new THREE.DirectionalLight('#fff7ed',2),daylight=createDaylightFrame(THREE,houseBounds,projectConfig.camera?.sunDirection);sun.position.copy(daylight.position);sun.target.position.copy(daylight.target);scene.add(sun.target);sun.castShadow=true;
sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-daylight.span,right:daylight.span,top:daylight.span,bottom:-daylight.span,near:daylight.near,far:daylight.far});sun.shadow.camera.updateProjectionMatrix();
sun.shadow.normalBias=.025;scene.add(sun);const ambient=new THREE.AmbientLight('#ffffff',.4);scene.add(ambient);
const deferReflectorRefresh=()=>{
 const deferred=[];
 for(const {mirror}of reflectors)if(isEffectivelyVisible(mirror)){
  const token=mirror.deferNextReflection?.();if(token)deferred.push({mirror,token});
 }
 return deferred.length?deferred:false;
};
const completeDeferredReflectorRefresh=deferred=>{
 let refresh=false;
 for(const {mirror,token}of deferred)refresh=mirror.completeDeferredReflection?.(token)||refresh;
 return refresh;
};
const nightView=createNightViewController(THREE,{scene,renderer,fixtureLayer:layers.lighting,hemisphere,sun,ambient,camera,materials:modelMaterials,reflectors,treeBases,shelfLighting:nightShelfLighting,frameLighting:nightFrameLighting,toggle:dayNightToggle,rootElement:document.documentElement,themeColorMeta:document.querySelector('meta[name="theme-color"]'),requestRender:()=>requestMainRender(),invalidateReflections:invalidateReflectors,deferReflections:deferReflectorRefresh,completeDeferredReflections:completeDeferredReflectorRefresh,onChange:setTvVideoLightingMode});
let firstMainFrameRendered=false,nightWarmupHandle=0,nightWarmupUsesIdle=false,nightWarmupCameraIndex=0,nightWarmupCameras=null,nightWarmupUrgent=false,nightWarmupRunning=false,nightWarmupGeneration=0,nightWarmupDisposed=false;
function cancelNightProgramWarmup(){
 if(!nightWarmupHandle)return;
 if(nightWarmupUsesIdle)globalThis.cancelIdleCallback?.(nightWarmupHandle);else clearTimeout(nightWarmupHandle);
 nightWarmupHandle=0;
}
function collectNightWarmupCameras(){
 const cameras=[camera];
 for(const {mirror}of reflectors){
  const reflectionCamera=mirror.getReflectionSourceCamera?.(camera);
  if(reflectionCamera&&!cameras.some(candidate=>candidate.isPerspectiveCamera===reflectionCamera.isPerspectiveCamera&&candidate.isOrthographicCamera===reflectionCamera.isOrthographicCamera))cameras.push(reflectionCamera);
 }
 return cameras;
}
function finishNightProgramWarmup(error=null){startupNightWarmupPending=false;nightWarmupCameras=null;nightWarmupCameraIndex=0;settleAppLoadingTask('night-view',error);}
async function runNightProgramWarmup(deadline){
 nightWarmupHandle=0;
 if(nightWarmupDisposed||!startupNightWarmupPending)return;
 if(nightWarmupRunning)return;
 if(document.hidden||!appInViewport)return;
 if(deadline&&!deadline.didTimeout&&deadline.timeRemaining()<8){scheduleNightProgramWarmup(false);return;}
 nightWarmupCameras??=collectNightWarmupCameras();
 const warmupCamera=nightWarmupCameras[nightWarmupCameraIndex++];
 const generation=nightWarmupGeneration;nightWarmupRunning=true;
 try{if(appLoadingFinished)nightView.preparePrograms(warmupCamera);else await nightView.prepareProgramsAsync(warmupCamera);}catch(error){
  nightWarmupRunning=false;
  if(generation!==nightWarmupGeneration||nightWarmupDisposed){if(!nightWarmupDisposed)scheduleNightProgramWarmup(!appLoadingFinished);return;}
  console.warn('Night-view shader warm-up skipped.',error);finishNightProgramWarmup(error);requestMainRender();return;
 }
 nightWarmupRunning=false;requestMainRender();
 if(generation!==nightWarmupGeneration||nightWarmupDisposed){if(!nightWarmupDisposed)scheduleNightProgramWarmup(!appLoadingFinished);return;}
 if(nightWarmupCameraIndex<(nightWarmupCameras?.length||0))scheduleNightProgramWarmup(!appLoadingFinished);else finishNightProgramWarmup();
}
function scheduleNightProgramWarmup(urgent=false){
 if(!performanceMode||nightWarmupDisposed||!startupNightWarmupPending)return;
 nightWarmupUrgent=nightWarmupUrgent||urgent;
 if(nightWarmupRunning)return;
 if(!firstMainFrameRendered)return;
 if(nightWarmupHandle){
  if(!nightWarmupUrgent)return;
  if(nightWarmupUsesIdle)globalThis.cancelIdleCallback?.(nightWarmupHandle);else clearTimeout(nightWarmupHandle);
  nightWarmupHandle=0;
 }
 if(appLoadingFinished&&!nightWarmupUrgent&&globalThis.requestIdleCallback){nightWarmupUsesIdle=true;nightWarmupHandle=requestIdleCallback(runNightProgramWarmup,{timeout:4000});}
 else{nightWarmupUsesIdle=false;nightWarmupHandle=setTimeout(runNightProgramWarmup,nightWarmupUrgent||!appLoadingFinished?0:600);}
 nightWarmupUrgent=false;
}
if(!performanceMode){try{nightView.preparePrograms(collectNightWarmupCameras());finishNightProgramWarmup();}catch(error){finishNightProgramWarmup(error);}}
function syncNightFixturePositions(){
 if(!nightView.syncFixturePositions()||!performanceMode||nightWarmupDisposed)return;
 cancelNightProgramWarmup();startupNightWarmupPending=true;nightWarmupCameraIndex=0;nightWarmupCameras=null;scheduleNightProgramWarmup(false);
}
dayNightToggle.addEventListener('pointerenter',event=>{if(event.pointerType!=='touch')scheduleNightProgramWarmup(true);},{passive:true});
dayNightToggle.addEventListener('pointerdown',()=>scheduleNightProgramWarmup(true),{passive:true});
dayNightToggle.addEventListener('focus',()=>scheduleNightProgramWarmup(true));
dayNightToggle.onclick=()=>{closeActiveCatalogItem();nightView.toggle();};
const resetNightProgramWarmup=()=>{
 cancelNightProgramWarmup();nightWarmupGeneration++;nightView.resetPreparedPrograms();startupNightWarmupPending=performanceMode;nightWarmupCameraIndex=0;nightWarmupCameras=null;firstMainFrameRendered=false;
};
const resumeNightProgramWarmup=()=>{invalidateReflectors();invalidateShadows();requestMainRender();};
renderer.domElement.addEventListener('webglcontextlost',resetNightProgramWarmup);
renderer.domElement.addEventListener('webglcontextrestored',resumeNightProgramWarmup);
let mode='axon',axonViewportShiftBlend=AXON_HOME_VIEW.viewportShiftBlend,axonViewportLiftBlend=AXON_HOME_VIEW.viewportLiftBlend,productFocusFrame=0,productFocusGeneration=0,productFocusFraming=null;const viewModeToggle=document.querySelector('#view-mode-toggle');
const productFocusRaycaster=new THREE.Raycaster(),productFocusOccluders=[],productFocusSolutionCache=new Map(),productFocusHouseBounds=new THREE.Box3().setFromObject(layers.architecture);
for(const layer of [layers.architecture,layers.cabinetry])layer.traverse(object=>{if(object.isMesh)productFocusOccluders.push(object);});
function productFocusPointVisible(_cameraPosition,point,viewDirection,distance,ignoredObjects=null){
 const origin=point.clone().addScaledVector(viewDirection,distance);productFocusRaycaster.set(origin,viewDirection.clone().negate());productFocusRaycaster.far=Math.max(0,distance-.04);
 const blocked=productFocusRaycaster.intersectObjects(productFocusOccluders,false).some(hit=>!ignoredObjects?.has(hit.object)&&isEffectivelyVisible(hit.object)&&materialCanOccludeInteraction(hitMaterial(hit)));productFocusRaycaster.far=Infinity;return!blocked;
}
function cancelProductFocusCamera(){
 productFocusGeneration++;if(productFocusFrame)cancelAnimationFrame(productFocusFrame);productFocusFrame=0;productFocusFraming=null;controls.enableDamping=true;setSceneMotionQuality('product-focus',false);
}
function focusHouseBounds({cacheId=null,bounds,samples,target:authoredTarget=null,minVerticalRatio=.65,preferredYaw=null,fixedYaw=null,fixedVerticalRatio=null,fixedZoom=null,fill=.34,minZoom=1.05,maxZoom=Math.min(4.5,controls.maxZoom),ignoredObjects=null,compact=true}){
 if(!bounds||bounds.isEmpty())return;
 cancelIntroCamera();cancelProductFocusCamera();if(mode==='plan')setView('axon');
 // Start from the rendered frustum, including home lift or an interrupted focus.
 // Removing those offsets before the camera moves would snap the model on click.
 const startViewportShift={leftFraction:(camera.left+camera.right)/(2*(camera.right-camera.left)),topFraction:-(camera.top+camera.bottom)/(2*(camera.top-camera.bottom))};
 productFocusFraming={startViewportShift,progress:0};
 axonViewportShiftBlend=0;axonViewportLiftBlend=0;
 const mobileMotion=window.matchMedia('(hover: none), (pointer: coarse)').matches,generation=++productFocusGeneration;
 const target=Array.isArray(authoredTarget)?new THREE.Vector3(...authoredTarget):authoredTarget?.isVector3?authoredTarget.clone():bounds.getCenter(new THREE.Vector3()),sphere=bounds.getBoundingSphere(new THREE.Sphere()),startTarget=controls.target.clone(),startPosition=camera.position.clone(),startZoom=camera.zoom,startOffset=startPosition.clone().sub(startTarget),distance=Math.max(20,startOffset.length());
 const startDirection=new THREE.Spherical().setFromVector3(startOffset),focusCacheKey=cacheId?`${cacheId}:${arrangementRevision}:${mobileMotion?'coarse':'fine'}:${Math.round(startDirection.theta/(Math.PI/6))}:${Math.round(startDirection.phi/(Math.PI/12))}`:null;
 const hasAuthoredDirection=Number.isFinite(fixedYaw)&&Number.isFinite(fixedVerticalRatio);
 let focusView=hasAuthoredDirection?{offset:new THREE.Vector3(Math.sin(fixedYaw),fixedVerticalRatio,Math.cos(fixedYaw)).normalize().multiplyScalar(distance)}:focusCacheKey?productFocusSolutionCache.get(focusCacheKey):null;if(focusView&&!hasAuthoredDirection)focusView={...focusView,offset:focusView.offset.clone()};else if(!focusView){
  const isVisible=(cameraPosition,point,viewDirection,focusDistance,sample)=>(!sample?.normal||sample.doubleSided||sample.normal.dot(viewDirection)>.02)&&productFocusPointVisible(cameraPosition,point,viewDirection,focusDistance,ignoredObjects);
  focusView=chooseProductFocusOffset(THREE,{target,currentOffset:startOffset,distance,samples,bounds,minVerticalRatio,preferredYaw,isVisible,compact});
  if(focusView&&focusCacheKey)productFocusSolutionCache.set(focusCacheKey,{...focusView,offset:focusView.offset.clone()});
 }
 const endOffset=focusView?.offset||startOffset.clone(),startSpherical=new THREE.Spherical().setFromVector3(startOffset),endSpherical=new THREE.Spherical().setFromVector3(endOffset),thetaDelta=Math.atan2(Math.sin(endSpherical.theta-startSpherical.theta),Math.cos(endSpherical.theta-startSpherical.theta));
 const viewportHalfSpan=Math.min((camera.right-camera.left)/2,(camera.top-camera.bottom)/2),targetZoom=Number.isFinite(fixedZoom)?THREE.MathUtils.clamp(fixedZoom*viewportHalfSpan/AXON_HOME_VIEW.halfHeight,minZoom,maxZoom):productFocusZoom(THREE,camera,sphere.radius,{fill,minZoom,maxZoom}),startTime=performance.now(),duration=reducedMotionQuery?.matches?1:mobileMotion?700+Math.abs(thetaDelta)/Math.PI*400:1800+Math.abs(thetaDelta)/Math.PI*1200,frameInterval=1000/30,currentTarget=new THREE.Vector3(),currentOffset=new THREE.Vector3(),spherical=new THREE.Spherical();let lastFrameTime=startTime-frameInterval;controls.enableDamping=false;setSceneMotionQuality('product-focus',true);
 const animate=now=>{
  if(generation!==productFocusGeneration)return;
  if(now-startTime<duration&&now-lastFrameTime<frameInterval){productFocusFrame=requestAnimationFrame(animate);return;}lastFrameTime=now;
  const linear=THREE.MathUtils.clamp((now-startTime)/duration,0,1),eased=mobileMotion?linear*linear*(3-2*linear):linear**3*(linear*(linear*6-15)+10);
  currentTarget.lerpVectors(startTarget,target,eased);spherical.radius=THREE.MathUtils.lerp(startSpherical.radius,endSpherical.radius,eased);spherical.phi=THREE.MathUtils.lerp(startSpherical.phi,endSpherical.phi,eased);spherical.theta=startSpherical.theta+thetaDelta*eased;currentOffset.setFromSpherical(spherical);
  controls.target.copy(currentTarget);camera.position.copy(currentTarget).add(currentOffset);camera.zoom=THREE.MathUtils.lerp(startZoom,targetZoom,eased);productFocusFraming.progress=eased;updateCameraProjection();controls.update();requestMainRender();
  if(linear<1)productFocusFrame=requestAnimationFrame(animate);else{productFocusFrame=0;productFocusFraming=null;controls.enableDamping=true;setSceneMotionQuality('product-focus',false);invalidateReflectors();requestMainRender();}
 };
 productFocusFrame=requestAnimationFrame(animate);
}
function focusHouseProduct(id){
 const roots=rootsForProduct(id);if(!roots.length)return;
 const mobileMotion=window.matchMedia('(hover: none), (pointer: coarse)').matches,{bounds,samples}=productFocusBounds(THREE,roots,mobileMotion?2:8),focusHint=roots.find(root=>root.userData.focusView)?.userData.focusView;
 focusHouseBounds({cacheId:`product:${id}`,bounds,samples,minVerticalRatio:Math.max(productFocusMinimumVerticalRatio(THREE,bounds,productFocusHouseBounds),focusHint?.minVerticalRatio||0),preferredYaw:focusHint?.yaw,compact:true});
}
function focusAudioSpeaker(){
 if(!audioSpeaker||audioSpeaker.userData.arrangeDeleted||!isEffectivelyVisible(audioSpeaker))return false;
 const {bounds,samples}=productFocusBounds(THREE,[audioSpeaker],8),hint=audioSpeaker.userData.focusView;
 focusHouseBounds({cacheId:'sound:speaker',bounds,samples,minVerticalRatio:hint?.minVerticalRatio||.65,preferredYaw:hint?.yaw,fill:.42,maxZoom:Math.min(14,controls.maxZoom),compact:true});return true;
}
function focusHouseMaterial(assetKey,asset,targets){
 const mobileMotion=window.matchMedia('(hover: none), (pointer: coarse)').matches,{meshes,bounds,samples}=materialFocusTargets(THREE,targets,asset,{maxSamples:mobileMotion?12:32,isVisible:isEffectivelyVisible});
 if(!meshes.length)return;
 const preset=materialFocusPreset(assetKey);
 focusHouseBounds({bounds,samples,target:preset?.target,minVerticalRatio:materialFocusMinimumVerticalRatio(THREE,bounds),fixedYaw:preset?.yaw,fixedVerticalRatio:preset?.verticalRatio,fixedZoom:preset?.zoom,fill:.45,minZoom:controls.minZoom,maxZoom:preset?Math.min(4.5,controls.maxZoom):Math.min(1.35,controls.maxZoom),ignoredObjects:new Set(meshes),compact:mobileMotion});
}
const tvProjectedBounds=new THREE.Box3(),tvProjectionPoint=new THREE.Vector3(),coarseTvPointer=window.matchMedia?.('(pointer: coarse)');
tvPlaybackAllowed=()=>{
 if(mode==='plan'||galleryOverlay.classList.contains('is-open')||snapshotDialog.classList.contains('is-open')||!isEffectivelyVisible(mediaVideoDisplay))return false;
 tvProjectedBounds.setFromObject(mediaVideoDisplay);let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity,withinDepth=false;
 for(const x of [tvProjectedBounds.min.x,tvProjectedBounds.max.x])for(const y of [tvProjectedBounds.min.y,tvProjectedBounds.max.y])for(const z of [tvProjectedBounds.min.z,tvProjectedBounds.max.z]){
  tvProjectionPoint.set(x,y,z).project(camera);minX=Math.min(minX,tvProjectionPoint.x);maxX=Math.max(maxX,tvProjectionPoint.x);minY=Math.min(minY,tvProjectionPoint.y);maxY=Math.max(maxY,tvProjectionPoint.y);withinDepth=withinDepth||(tvProjectionPoint.z>=-1&&tvProjectionPoint.z<=1);
 }
 if(!withinDepth||maxX< -1||minX>1||maxY< -1||minY>1)return false;
 const pixelWidth=(Math.min(1,maxX)-Math.max(-1,minX))*mount.clientWidth/2,pixelHeight=(Math.min(1,maxY)-Math.max(-1,minY))*mount.clientHeight/2;
 return pixelWidth>=(coarseTvPointer?.matches?8:24)&&pixelHeight>=(coarseTvPointer?.matches?4:12);
};
const speakerProjectedBounds=new THREE.Box3(),speakerProjectionPoint=new THREE.Vector3();
speakerAnimationAllowed=()=>{
 if(galleryOverlay.classList.contains('is-open')||snapshotDialog.classList.contains('is-open'))return false;
 for(const root of layers.furniture.children.filter(root=>root.userData.audioPlayerTrigger&&!root.userData.arrangeDeleted&&isEffectivelyVisible(root))){
  speakerProjectedBounds.setFromObject(root);let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity,withinDepth=false;
  for(const x of [speakerProjectedBounds.min.x,speakerProjectedBounds.max.x])for(const y of [speakerProjectedBounds.min.y,speakerProjectedBounds.max.y])for(const z of [speakerProjectedBounds.min.z,speakerProjectedBounds.max.z]){
   speakerProjectionPoint.set(x,y,z).project(camera);minX=Math.min(minX,speakerProjectionPoint.x);maxX=Math.max(maxX,speakerProjectionPoint.x);minY=Math.min(minY,speakerProjectionPoint.y);maxY=Math.max(maxY,speakerProjectionPoint.y);withinDepth=withinDepth||(speakerProjectionPoint.z>=-1&&speakerProjectionPoint.z<=1);
  }
  if(!withinDepth||maxX< -1||minX>1||maxY< -1||minY>1)continue;
  const pixelWidth=(Math.min(1,maxX)-Math.max(-1,minX))*mount.clientWidth/2,pixelHeight=(Math.min(1,maxY)-Math.max(-1,minY))*mount.clientHeight/2;
  if(pixelWidth>=8&&pixelHeight>=8)return true;
 }
 return false;
};
const fireplaceAnimator=animators.find(animator=>animator.name==='illustrated fireplace fire'),authoredFireplaceAnimationAllowed=fireplaceAnimator?.isActive?.bind(fireplaceAnimator),fireplaceProjectedBounds=new THREE.Box3(),fireplaceProjectionPoint=new THREE.Vector3();let fireplaceProjectedActive=false;
function stopProjectedFireplaceAnimation(){fireplaceProjectedActive=false;return false;}
function fireplaceAnimationAllowed(){
 if(!fireplaceAnimator||!illustratedFlames||authoredFireplaceAnimationAllowed?.()===false||mode==='plan'||galleryOverlay.classList.contains('is-open')||snapshotDialog.classList.contains('is-open')||!isEffectivelyVisible(illustratedFlames)||!mount.clientWidth||!mount.clientHeight)return stopProjectedFireplaceAnimation();
 fireplaceProjectedBounds.setFromObject(illustratedFlames);if(fireplaceProjectedBounds.isEmpty())return stopProjectedFireplaceAnimation();
 let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity,withinDepth=false;
 for(let corner=0;corner<8;corner++){
  fireplaceProjectionPoint.set(corner&1?fireplaceProjectedBounds.max.x:fireplaceProjectedBounds.min.x,corner&2?fireplaceProjectedBounds.max.y:fireplaceProjectedBounds.min.y,corner&4?fireplaceProjectedBounds.max.z:fireplaceProjectedBounds.min.z).project(camera);
  minX=Math.min(minX,fireplaceProjectionPoint.x);maxX=Math.max(maxX,fireplaceProjectionPoint.x);minY=Math.min(minY,fireplaceProjectionPoint.y);maxY=Math.max(maxY,fireplaceProjectionPoint.y);withinDepth=withinDepth||(fireplaceProjectionPoint.z>=-1&&fireplaceProjectionPoint.z<=1);
 }
 if(!withinDepth||maxX< -1||minX>1||maxY< -1||minY>1)return stopProjectedFireplaceAnimation();
 const pixelWidth=(Math.min(1,maxX)-Math.max(-1,minX))*mount.clientWidth/2,pixelHeight=(Math.min(1,maxY)-Math.max(-1,minY))*mount.clientHeight/2;
 fireplaceProjectedActive=pixelWidth>=(fireplaceProjectedActive?8:12)&&pixelHeight>=(fireplaceProjectedActive?4:6);return fireplaceProjectedActive;
}
if(fireplaceAnimator)fireplaceAnimator.isActive=fireplaceAnimationAllowed;
function catalogCellSizePixels(){return parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--catalog-cell-size'))||56;}
function updateCatalogBackdrop(){catalogBackdrop.style.height=`${Math.ceil(catalogStrip.getBoundingClientRect().height)}px`;}
function resetViewportLiftPixels(){const style=getComputedStyle(catalogStrip);return(catalogCellSizePixels()+parseFloat(style.paddingTop||0)+parseFloat(style.paddingBottom||0))/2;}
let introCameraFrame=0,introCameraActive=false;
function axonHomeTarget(){return new THREE.Vector3(...AXON_HOME_VIEW.target);}
function axonHomeOffset(){return new THREE.Vector3(...AXON_HOME_VIEW.offset);}
function introCameraOffset(){
 if(!mediaVideoDisplay)return axonHomeOffset();
 mediaVideoDisplay.updateWorldMatrix(true,false);const front=new THREE.Vector3(0,0,1).transformDirection(mediaVideoDisplay.matrixWorld);front.y=.9;
 return front.normalize().multiplyScalar(axonHomeOffset().length());
}
function applyAxonHomePose(){
 axonViewportShiftBlend=AXON_HOME_VIEW.viewportShiftBlend;axonViewportLiftBlend=AXON_HOME_VIEW.viewportLiftBlend;
 controls.target.set(...AXON_HOME_VIEW.target);camera.up.set(0,1,0);camera.position.copy(controls.target).add(axonHomeOffset());camera.zoom=AXON_HOME_VIEW.zoom;controls.enableRotate=true;
}
function cancelIntroCamera(){
 if(!introCameraActive)return;
 introCameraActive=false;if(introCameraFrame)cancelAnimationFrame(introCameraFrame);introCameraFrame=0;
 setReflectorRefreshThrottled(false);controls.enableDamping=true;controls.update();requestMainRender();
}
function prepareIntroCameraPose(){
 if(!mediaScreenFocus||reducedMotionQuery?.matches||new URLSearchParams(location.search).get('intro')==='off'||projectConfig.camera?.intro===false)return false;
 const focusTarget=mediaScreenFocus.clone();
 const resetOffset=introCameraOffset();
 axonViewportShiftBlend=AXON_HOME_VIEW.viewportShiftBlend;axonViewportLiftBlend=0;controls.enableDamping=false;controls.target.copy(focusTarget);camera.position.copy(focusTarget).add(resetOffset);camera.zoom=5.5;updateCameraProjection();controls.update();visibility();updateLandscape();requestMainRender();return true;
}
function startIntroCamera({prepared=false}={}){
 if(!mediaScreenFocus||reducedMotionQuery?.matches||new URLSearchParams(location.search).get('intro')==='off'||projectConfig.camera?.intro===false)return;
 if(!prepared&&!prepareIntroCameraPose())return;
 const focusTarget=mediaScreenFocus.clone();
 const resetTarget=axonHomeTarget(),resetOffset=axonHomeOffset(),introOffset=introCameraOffset(),introSpherical=new THREE.Spherical().setFromVector3(introOffset),homeSpherical=new THREE.Spherical().setFromVector3(resetOffset),introTheta=Math.atan2(Math.sin(homeSpherical.theta-introSpherical.theta),Math.cos(homeSpherical.theta-introSpherical.theta)),viewSpherical=new THREE.Spherical();
 const introZoom=5.5,startTime=performance.now(),duration=40000,frameInterval=1000/30;let lastFrameTime=startTime-frameInterval;
 introCameraActive=true;setReflectorRefreshThrottled(true);
 const animate=now=>{
  if(!introCameraActive)return;
  if(now-startTime<duration&&now-lastFrameTime<frameInterval){introCameraFrame=requestAnimationFrame(animate);return;}
  lastFrameTime=now;
  const progress=THREE.MathUtils.clamp((now-startTime)/duration,0,1);
  const recenterTime=THREE.MathUtils.clamp((progress-.7)/.3,0,1),recenterEase=recenterTime*recenterTime*(3-2*recenterTime);
  controls.target.lerpVectors(focusTarget,resetTarget,recenterEase);viewSpherical.radius=resetOffset.length();viewSpherical.phi=THREE.MathUtils.lerp(introSpherical.phi,homeSpherical.phi,recenterEase);viewSpherical.theta=introSpherical.theta+introTheta*recenterEase;camera.position.copy(controls.target).add(new THREE.Vector3().setFromSpherical(viewSpherical));
  axonViewportLiftBlend=recenterEase;
  camera.zoom=THREE.MathUtils.lerp(introZoom,AXON_HOME_VIEW.zoom,progress);
  updateCameraProjection();visibility();requestMainRender();
  if(progress<1)introCameraFrame=requestAnimationFrame(animate);
  else{introCameraActive=false;introCameraFrame=0;setReflectorRefreshThrottled(false);applyAxonHomePose();controls.enableDamping=true;updateCameraProjection();controls.update();visibility();updateLandscape();invalidateReflectors();requestMainRender();}
 };
 introCameraFrame=requestAnimationFrame(animate);
}
function settleIntroCamera(){
 if(!introCameraActive)return;
 cancelIntroCamera();applyAxonHomePose();
 updateCameraProjection();controls.update();visibility();updateLandscape();invalidateReflectors();requestMainRender();
}
function syncReflectorVisibility(){
 let changed=false;
 for(const {group,mirror,back,hostWall} of reflectors){
  if(!group){if(mirror)mirror.visible=mode!=='plan';continue;}
  const groupVisible=(hostWall?.visible??true)&&!group.userData.arrangeDeleted,mirrorVisible=groupVisible&&mode!=='plan';
  if(group.visible!==groupVisible){group.visible=groupVisible;changed=true;}
  if(mirror.visible!==mirrorVisible){mirror.visible=mirrorVisible;changed=true;}
  if(back&&back.visible!==mirrorVisible){back.visible=mirrorVisible;changed=true;}
 }
 return changed;
}
function syncArrangeGridVisibility(){
 const gridVisible=arrangeModeActive&&layers.architecture.visible;let changed=false;
 if(arrangeSurfaceGrid.group.visible!==gridVisible){arrangeSurfaceGrid.group.visible=gridVisible;changed=true;}
 if(gridVisible){
  if(arrangeSurfaceGrid.floorOverlay&&arrangeSurfaceGrid.floorOverlay.visible!==true){arrangeSurfaceGrid.floorOverlay.visible=true;changed=true;}
  for(const {overlay,source} of arrangeSurfaceGrid.wallEntries){const visible=isEffectivelyVisible(source);if(overlay.visible!==visible){overlay.visible=visible;changed=true;}}
 }
 return changed;
}
function visibility(){
 let changed=false;
 exterior.forEach(({group,normal})=>{
  const visible=mode==='plan'||!cutaway.checked||normal.dot(camera.position.clone().sub(group.getWorldPosition(new THREE.Vector3())))<=0;
  if(group.visible!==visible){group.visible=visible;changed=true;}
 });
 for(const root of [...layers.furniture.children,...layers.lighting.children]){const metadata=root.userData.movableItem;if(metadata?.constraint!=='wall'||!metadata.hostWall)continue;const wall=layers.architecture.getObjectByName(metadata.hostWall);if(!wall)continue;const visible=wall.visible&&!root.userData.arrangeDeleted;if(root.visible!==visible){root.visible=visible;changed=true;}}
 if(bindings.tv?.mount&&bindings.tv.hostWall){const visible=bindings.tv.hostWall.visible;if(bindings.tv.mount.visible!==visible){bindings.tv.mount.visible=visible;changed=true;}}
 changed=syncReflectorVisibility()||changed;
 changed=syncArrangeGridVisibility()||changed;
 nightFrameLighting?.syncVisibility();
 if(changed){invalidateReflectors();invalidateShadows();}
 return changed;
}
function updateLandscape(){bindings.landscape?.updateView?.(mode,camera);}
function setView(next){
 cancelProductFocusCamera();mode=next;controls.enableDamping=false;
 controls.mouseButtons.LEFT=mode==='plan'?THREE.MOUSE.PAN:THREE.MOUSE.ROTATE;
 controls.touches.ONE=mode==='plan'?THREE.TOUCH.PAN:THREE.TOUCH.ROTATE;
 if(mode==='axon')applyAxonHomePose();
 else{
  axonViewportShiftBlend=0;axonViewportLiftBlend=0;controls.target.set(AXON_HOME_VIEW.target[0],0,AXON_HOME_VIEW.target[2]);
  // Looking straight down, -X as camera-up rotates the plan 90° clockwise.
  camera.up.set(-1,0,0);camera.position.copy(controls.target).add(new THREE.Vector3(0,AXON_HOME_VIEW.offset[1]+30,.001));camera.zoom=1;controls.enableRotate=false;
 }
 controls.update();controls.enableDamping=true;
 viewModeToggle.dataset.currentView=mode;
 resize();visibility();updateLandscape();syncTvVideoPlayback();requestMainRender();
}
viewModeToggle.onclick=()=>{cancelIntroCamera();setView(mode==='axon'?'plan':'axon');};
function resetLayerVisibility(){
 cutaway.checked=false;
 layerInputs.forEach(input=>{input.checked=true;});
 Object.values(layers).forEach(layer=>{layer.visible=true;});
 glazingGroups.forEach(group=>{group.visible=true;});
 updateLayerMenuHiddenState();visibility();updateLandscape();invalidateReflectors();invalidateShadows();syncTvVideoPlayback();scheduleSceneAnimation();requestMainRender();
}
document.querySelector('#reset-view').onclick=()=>{cancelIntroCamera();closeActiveCatalogItem();if(arrangeModeActive)setArrangeMode(false);resetArrangeItems();resetLayerVisibility();nightView.setNightView(false);setView('axon');};
document.querySelector('#rotate-view').onclick=()=>{
 cancelIntroCamera();cancelProductFocusCamera();
 if(mode==='plan')setView('axon');
 const offset=camera.position.clone().sub(controls.target);
 offset.applyAxisAngle(new THREE.Vector3(0,1,0),Math.PI/2);
 controls.enableDamping=false;camera.position.copy(controls.target).add(offset);controls.update();controls.enableDamping=true;visibility();requestMainRender();
};
for(const button of [viewModeToggle,document.querySelector('#rotate-view'),dayNightToggle,document.querySelector('#reset-view')])bindMobileControlHaptic(button,button===dayNightToggle?{onPointerDown:()=>scheduleNightProgramWarmup(true)}:{});
if(mobileControlHapticTargets.length){
 new ResizeObserver(syncMobileControlHapticTargets).observe(viewModeToggle.parentElement);
 mobileControlTouchQuery.addEventListener('change',syncMobileControlHapticTargets);window.addEventListener('resize',syncMobileControlHapticTargets);syncMobileControlHapticTargets();
}
layerInputs.forEach(c=>c.onchange=()=>{
 layers[c.dataset.layer].visible=c.checked;if(c.dataset.layer==='glazing')glazingGroups.forEach(g=>g.visible=c.checked);
 if(selectedArrangeItem&&!arrangeItemIsVisible(selectedArrangeItem))selectArrangeItem(null);else updateArrangeSelectionVisual();
 updateLayerMenuHiddenState();
 invalidateReflectors();invalidateShadows();syncTvVideoPlayback();scheduleSceneAnimation();requestMainRender();
});
cutaway.onchange=()=>{updateLayerMenuHiddenState();visibility();requestMainRender();};
let touchTooltipTimer=null,touchTooltipControl=null;
document.querySelectorAll('.icon-control,.arrange-action').forEach(control=>control.addEventListener('pointerup',event=>{
 if(event.pointerType!=='touch')return;
 if(touchTooltipControl)touchTooltipControl.classList.remove('touch-tooltip-visible');
 clearTimeout(touchTooltipTimer);touchTooltipControl=control;control.classList.add('touch-tooltip-visible');
 touchTooltipTimer=setTimeout(()=>{control.classList.remove('touch-tooltip-visible');if(touchTooltipControl===control)touchTooltipControl=null;},900);
}));
function resize(){
 updateCameraProjection();renderer.setSize(mount.clientWidth,mount.clientHeight,false);updateLayerControlsLayout();positionArrangeItemControls();requestMainRender();
}
function updateCameraProjection(){
 const w=Math.max(1,mount.clientWidth),h=Math.max(1,mount.clientHeight),a=w/h,houseSize=houseBounds.getSize(new THREE.Vector3()),hh=mode==='plan'?Math.max(houseSize.x*.68,houseSize.z*.68/a):Math.max(AXON_HOME_VIEW.halfHeight,AXON_HOME_VIEW.halfWidth/a);
 const shiftBlend=mode==='axon'?axonViewportShiftBlend:0;
 const focusedCatalogItemOnMobile=mode==='axon'&&activeCatalogItem?.matches('.product-item,.material-item')&&window.matchMedia('(max-width: 720px), (max-height: 520px) and (pointer: coarse)').matches;
 const expandedStripHeight=focusedCatalogItemOnMobile?catalogStrip.getBoundingClientRect().height:0;
 const collapsedStripHeight=catalogCellSizePixels()+parseFloat(getComputedStyle(catalogStrip).paddingTop||0)+parseFloat(getComputedStyle(catalogStrip).paddingBottom||0);
 const shortTouchViewport=window.matchMedia('(max-height: 520px) and (pointer: coarse)').matches,focusLiftLimit=shortTouchViewport?92:48,focusLiftRatio=shortTouchViewport ? .44 : .22;
 // Orthographic zoom amplifies projection offsets, so normalize the requested
 // on-screen lift to keep focused selections about the same distance above the card.
 const focusLiftPixels=focusedCatalogItemOnMobile?Math.min(focusLiftLimit,Math.max(0,(expandedStripHeight-collapsedStripHeight)*focusLiftRatio))/Math.max(1,camera.zoom):0;
 const halfWidth=hh*a,stripLiftPixels=(mode==='axon'?resetViewportLiftPixels()*axonViewportLiftBlend:0)+focusLiftPixels;
 const desiredViewportShift=mode==='axon'?{leftFraction:.08*shiftBlend,topFraction:.06*shiftBlend+stripLiftPixels/h}:{leftFraction:0,topFraction:0};
 // Framing travels with the focus pose/zoom, including layout-driven mobile lift.
 // Resize calls use the same blend so they cannot snap ahead of the animation.
 const viewportShift=mode==='axon'&&productFocusFraming?{leftFraction:THREE.MathUtils.lerp(productFocusFraming.startViewportShift.leftFraction,desiredViewportShift.leftFraction,productFocusFraming.progress),topFraction:THREE.MathUtils.lerp(productFocusFraming.startViewportShift.topFraction,desiredViewportShift.topFraction,productFocusFraming.progress)}:desiredViewportShift;
 const centerX=2*halfWidth*viewportShift.leftFraction,centerY=-2*hh*viewportShift.topFraction;
 // Shift the Axon framing toward the viewport's top-left without changing the
 // orbit target: positive camera-space X shows more space on the right, while
 // a negative camera-space Y center shows more space below the model.
 camera.left=-halfWidth+centerX;camera.right=halfWidth+centerX;
 camera.top=hh+centerY;camera.bottom=-hh+centerY;
 camera.userData.viewportShift=viewportShift;
 camera.updateProjectionMatrix();
}
let scheduledFrame=0,controlsActive=false,videoFallbackTimer=0,sceneAnimationTimer=0;
const sceneAnimationFps=Math.max(1,...animators.map(animator=>animator.fps||24));
const sceneAnimatorActive=animator=>typeof animator.isActive==='function'?animator.isActive():layers.cabinetry.visible;
function collectSceneAnimationState(){
 const eligible=animators.filter(sceneAnimatorActive),active=appLoadingFinished&&eligible.length>0&&!reducedMotionQuery?.matches&&!document.hidden&&appInViewport;
 return{eligible,active,affectsMotionQuality:active&&eligible.some(animator=>animator.affectsMotionQuality!==false)};
}
function updateSceneAnimations(now,state=collectSceneAnimationState()){
 const seconds=reducedMotionQuery?.matches?2.4:now*.001;
 for(const animator of state.eligible)animator.update(seconds);
}
function scheduleSceneAnimation(state=collectSceneAnimationState()){
 clearTimeout(sceneAnimationTimer);sceneAnimationTimer=0;
 setSceneMotionQuality('scene-animation',state.affectsMotionQuality);
 if(performanceMode&&state.active)sceneAnimationTimer=setTimeout(()=>{sceneAnimationTimer=0;requestMainRender();},1000/sceneAnimationFps);
}
function renderMainFrame(now=performance.now()){
 scheduledFrame=0;
 if(document.hidden||!appInViewport){scheduleSceneAnimation();return;}
 if(nightWarmupRunning)return;
 const controlsChanged=controls.update();visibility();updateLandscape();
 const sceneAnimationState=collectSceneAnimationState();updateSceneAnimations(now,sceneAnimationState);
 if(selectedArrangeItem&&(controlsChanged||controlsActive||introCameraActive||productFocusFrame))positionArrangeItemControls();
 scheduleSceneAnimation(sceneAnimationState);applySceneRenderQuality();
 renderer.render(scene,camera);
 syncTvVideoPlayback();
 completeAfterMainRender(now);
 if(appLoadingReadyForFrame&&!appLoadingTasks.get('first-frame'))settleAppLoadingTask('first-frame');
 if(!firstMainFrameRendered){firstMainFrameRendered=true;scheduleNightProgramWarmup(!appLoadingFinished);}
 if(controlsActive||controlsChanged)requestMainRender();
}
if(performanceMode){
 renderer.shadowMap.autoUpdate=false;renderer.shadowMap.needsUpdate=true;
 requestMainRender=()=>{
  if(!scheduledFrame&&!document.hidden&&appInViewport)scheduledFrame=requestAnimationFrame(renderMainFrame);
 };
 invalidateShadows=()=>{renderer.shadowMap.needsUpdate=true;requestMainRender();};
 controls.addEventListener('start',()=>{controlsActive=true;setSceneMotionQuality('controls',true);requestMainRender();});
 controls.addEventListener('change',requestMainRender);
 controls.addEventListener('end',()=>{controlsActive=false;setSceneMotionQuality('controls',false);invalidateReflectors();requestMainRender();});
 if('requestVideoFrameCallback' in tvVideo){
  let lastVideoRender=0;const onVideoFrame=now=>{if(now-lastVideoRender>=1000/15){lastVideoRender=now;requestMainRender();}tvVideo.requestVideoFrameCallback(onVideoFrame);};
  tvVideo.requestVideoFrameCallback(onVideoFrame);
 }else{
  const videoFallback=()=>{
   videoFallbackTimer=0;if(tvVideo.paused)return;requestMainRender();videoFallbackTimer=setTimeout(videoFallback,1000/15);
  };
  tvVideo.addEventListener('play',()=>{if(!videoFallbackTimer)videoFallback();});
  tvVideo.addEventListener('pause',()=>{clearTimeout(videoFallbackTimer);videoFallbackTimer=0;});
 }
 if('IntersectionObserver' in window){
  new IntersectionObserver(([entry])=>{
   appInViewport=entry.isIntersecting&&entry.intersectionRatio>0;
   if(!appInViewport){settleIntroCamera();productStripController?.stopRotation();if(scheduledFrame){cancelAnimationFrame(scheduledFrame);scheduledFrame=0;}}
   syncTvVideoPlayback();scheduleSceneAnimation();if(appInViewport){scheduleNightProgramWarmup(!appLoadingFinished);requestMainRender();}
  },{threshold:.01}).observe(mount);
 }
 document.addEventListener('visibilitychange',()=>{scheduleSceneAnimation();if(!document.hidden){scheduleNightProgramWarmup(!appLoadingFinished);requestMainRender();}});
}else{
 renderer.setAnimationLoop(now=>{controls.update();visibility();updateLandscape();const sceneAnimationState=collectSceneAnimationState();updateSceneAnimations(now,sceneAnimationState);positionArrangeItemControls();applySceneRenderQuality();renderer.render(scene,camera);syncTvVideoPlayback();completeAfterMainRender(now);if(appLoadingReadyForFrame&&!appLoadingTasks.get('first-frame'))settleAppLoadingTask('first-frame');});
}
const onMotionPreferenceChange=()=>{scheduleSceneAnimation();requestMainRender();};
if(reducedMotionQuery?.addEventListener)reducedMotionQuery.addEventListener('change',onMotionPreferenceChange);
else reducedMotionQuery?.addListener?.(onMotionPreferenceChange);
window.addEventListener('pagehide',event=>{
 if(event.persisted)return;
 nightWarmupDisposed=true;cancelNightProgramWarmup();startupNightWarmupPending=false;clearTimeout(sceneAnimationTimer);
 renderer.domElement.removeEventListener('webglcontextlost',resetNightProgramWarmup);renderer.domElement.removeEventListener('webglcontextrestored',resumeNightProgramWarmup);
 if(reducedMotionQuery?.removeEventListener)reducedMotionQuery.removeEventListener('change',onMotionPreferenceChange);
 else reducedMotionQuery?.removeListener?.(onMotionPreferenceChange);
 nightView.dispose();
 tvVideoTransition?.dispose();
 for(const animator of animators)animator.dispose?.();
 arrangeSurfaceGrid.group.traverse(object=>object.geometry?.dispose());arrangeSurfaceGrid.material.dispose();
 for(const {mirror,frame} of reflectors){mirror.dispose();mirror.geometry.dispose();frame.geometry.dispose();}
});
viewer.addEventListener('pointerdown',cancelIntroCamera,true);
viewer.addEventListener('wheel',cancelIntroCamera,{capture:true,passive:true});
viewer.addEventListener('keydown',cancelIntroCamera,true);
controls.addEventListener('start',cancelIntroCamera);
viewer.addEventListener('pointerdown',cancelProductFocusCamera,true);
viewer.addEventListener('wheel',cancelProductFocusCamera,{capture:true,passive:true});
viewer.addEventListener('keydown',cancelProductFocusCamera,true);
controls.addEventListener('start',cancelProductFocusCamera);
new ResizeObserver(resize).observe(mount);new ResizeObserver(()=>{updateLayerControlsLayout();updateCatalogBackdrop();}).observe(catalogStrip);setView('axon');prepareIntroCameraPose();requestAnimationFrame(()=>{updateLayerControlsLayout();updateCatalogBackdrop();});requestMainRender();requestAppLoadingFinalFrame();

// Inspection is opt-in and used by the standalone verification harness.
if(new URLSearchParams(location.search).has('inspect')){
 window.houseStarter={project:projectConfig,scene,renderer,camera,layers,bindings,nightView,houseBounds,
  setView,reset:()=>document.querySelector('#reset-view').click(),
  get arrangement(){return arrangeItems.map(item=>({id:item.metadata.id,present:item.present,deleted:!!item.root.userData.arrangeDeleted,position:item.root.position.toArray()}));},
  selectItem:id=>{if(!arrangeModeActive)setArrangeMode(true);selectArrangeItem(arrangeItemById.get(id)||null);},
  get selectedItem(){return selectedArrangeItem?.metadata.id||null;},
  get galleryIndex(){return selectedGalleryIndex;},
  focusProduct:focusHouseProduct,
  requestRender:()=>requestMainRender(),
 };
}
