export function createArrangeSurfaceGrid(THREE,{layers,wallSchedule,movementBoundary,exterior=[]}){
  const spacing=4*.0254;
  const material=new THREE.LineBasicMaterial({color:'#02ADFC',transparent:true,opacity:.48,depthWrite:false,toneMapped:false});
  material.name='Four-inch Rearrange grid';
  const group=new THREE.Group(),wallEntries=[];
  group.name='Rearrange surface grid';group.visible=false;group.userData={arrangeGrid:true,spacingIn:4,color:'#02ADFC',exteriorFaces:false,exteriorTerminalCaps:false,wallJointFaces:true,wallSurfaceOffsetMm:.5,roomFinishOffsetMm:.5,floorClearanceMm:2,wallTopInsetMm:3};
  const exteriorNormals=new Map(exterior.map(({group:wall,normal})=>[wall,normal]));
  const exteriorEntries=exterior.map(entry=>({...entry,wall:wallSchedule.find(wall=>wall.group===entry.group)}));
  const samePoint=(a,b)=>Math.abs(a[0]-b[0])<1e-6&&Math.abs(a[1]-b[1])<1e-6;
  const suppressedTerminalCaps=new Map();
  for(const {group:wallGroup,wall} of exteriorEntries){
    const dx=wall.b[0]-wall.a[0],dz=wall.b[1]-wall.a[1],length=Math.hypot(dx,dz),run={x:dx/length,z:dz/length},flags={start:false,end:false};
    for(const [index,key] of [[0,'start'],[1,'end']]){
      const point=index===0?wall.a:wall.b;
      const joined=exteriorEntries.find(entry=>entry.group!==wallGroup&&(samePoint(point,entry.wall.a)||samePoint(point,entry.wall.b)));
      const extension=wall.endExtensions?.[index]||0,displacement=index===0?-extension:extension;
      if(joined)flags[key]=displacement*(run.x*joined.normal.x+run.z*joined.normal.z)>1e-6;
    }
    suppressedTerminalCaps.set(wallGroup,flags);
  }
  const values=(min,max,origin=0)=>{
    const result=[];
    for(let value=origin+Math.ceil((min-origin-1e-6)/spacing)*spacing;value<=max+1e-6;value+=spacing)result.push(value);
    return result;
  };
  const addLines=(positions,name,visibilityRoot=null)=>{
    if(!positions.length)return null;
    const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.computeBoundingBox();geometry.computeBoundingSphere();
    const overlay=new THREE.LineSegments(geometry,material);overlay.name=name;overlay.renderOrder=20;overlay.raycast=()=>{};overlay.userData.arrangeGrid=true;group.add(overlay);
    if(visibilityRoot)wallEntries.push({overlay,source:visibilityRoot});return overlay;
  };
  const floorPositions=[],xs=movementBoundary.map(point=>point.x),zs=movementBoundary.map(point=>point.z);
  const floorSource=layers.architecture.children.find(object=>object.isMesh&&(object.userData.floorRegion||object.name==='floor finish'));
  const floorFinishes=layers.architecture.children.filter(object=>object.isMesh&&(object.userData.floorRegion||object.name==='floor finish'||object.name.includes(' floor')));
  const intersectPolygon=(value,vertical)=>{
    const intersections=[];
    for(let i=0,j=movementBoundary.length-1;i<movementBoundary.length;j=i++){
      const a=movementBoundary[j],b=movementBoundary[i],aAxis=vertical?a.x:a.z,bAxis=vertical?b.x:b.z;
      if((aAxis<=value&&bAxis>value)||(bAxis<=value&&aAxis>value)){
        const ratio=(value-aAxis)/(bAxis-aAxis);intersections.push(vertical?a.z+(b.z-a.z)*ratio:a.x+(b.x-a.x)*ratio);
      }
    }
    return intersections.sort((a,b)=>a-b);
  };
  const floorDatum=floorSource?new THREE.Box3().setFromObject(floorSource).max.y:0;
  const highestFloorFinish=floorFinishes.reduce((highest,finish)=>Math.max(highest,new THREE.Box3().setFromObject(finish).max.y),floorDatum),floorY=highestFloorFinish+.002;
  for(const x of values(Math.min(...xs),Math.max(...xs))){
    const intersections=intersectPolygon(x,true);
    for(let index=0;index+1<intersections.length;index+=2)floorPositions.push(x,floorY,intersections[index],x,floorY,intersections[index+1]);
  }
  for(const z of values(Math.min(...zs),Math.max(...zs))){
    const intersections=intersectPolygon(z,false);
    for(let index=0;index+1<intersections.length;index+=2)floorPositions.push(intersections[index],floorY,z,intersections[index+1],floorY,z);
  }
  const floorOverlay=addLines(floorPositions,'Arrange floor grid');
  const wallSurfaceOffset=.0005,wallEdgeInset=.003;
  for(const wall of wallSchedule){
    const positions=[],outward=exteriorNormals.get(wall.group),suppressed=suppressedTerminalCaps.get(wall.group),wallLength=Math.hypot(wall.b[0]-wall.a[0],wall.b[1]-wall.a[1]),horizontal=Math.abs(wall.b[0]-wall.a[0])>Math.abs(wall.b[1]-wall.a[1]),tangentSign=Math.sign(horizontal?wall.b[0]-wall.a[0]:wall.b[1]-wall.a[1]);
    for(const surface of wall.group.children.filter(object=>object.isMesh&&(object.name==='wall surface'||object.userData.roomWallFinish))){
      const bounds=new THREE.Box3().setFromObject(surface),wallBottom=bounds.min.y+wallEdgeInset,wallTop=bounds.max.y-wallEdgeInset,surfaceOffset=wallSurfaceOffset;
      const addXFace=faceX=>{
        for(const z of values(bounds.min.z,bounds.max.z))positions.push(faceX,wallBottom,z,faceX,wallTop,z);
        for(const y of values(wallBottom,wallTop,floorDatum))positions.push(faceX,y,bounds.min.z,faceX,y,bounds.max.z);
      };
      const addZFace=faceZ=>{
        for(const x of values(bounds.min.x,bounds.max.x))positions.push(x,wallBottom,faceZ,x,wallTop,faceZ);
        for(const y of values(wallBottom,wallTop,floorDatum))positions.push(bounds.min.x,y,faceZ,bounds.max.x,y,faceZ);
      };
      if(wallTop<=wallBottom)continue;
      if(outward){
        // Keep the broad room-facing plane and every real interior return or
        // opening reveal. At a perimeter joint, suppress only the terminal cap
        // whose butt-joint extension points toward the joined wall's exterior.
        if(Math.abs(outward.x)>Math.abs(outward.z))addXFace(outward.x>0?bounds.min.x-surfaceOffset:bounds.max.x+surfaceOffset);
        else addZFace(outward.z>0?bounds.min.z-surfaceOffset:bounds.max.z+surfaceOffset);
        const interval=surface.userData.wallInterval,atStart=Boolean(interval&&Math.abs(interval.from)<1e-6),atEnd=Boolean(interval&&Math.abs(interval.to-wallLength)<1e-6);
        const minTerminal=tangentSign>0?'start':'end',maxTerminal=tangentSign>0?'end':'start';
        const skipMin=(minTerminal==='start'?atStart:atEnd)&&suppressed?.[minTerminal];
        const skipMax=(maxTerminal==='start'?atStart:atEnd)&&suppressed?.[maxTerminal];
        if(horizontal){if(!skipMin)addXFace(bounds.min.x-surfaceOffset);if(!skipMax)addXFace(bounds.max.x+surfaceOffset);}
        else{if(!skipMin)addZFace(bounds.min.z-surfaceOffset);if(!skipMax)addZFace(bounds.max.z+surfaceOffset);}
      }else{
        addXFace(bounds.min.x-surfaceOffset);addXFace(bounds.max.x+surfaceOffset);
        addZFace(bounds.min.z-surfaceOffset);addZFace(bounds.max.z+surfaceOffset);
      }
    }
    const overlay=addLines(positions,`Arrange wall grid · ${wall.group.name}`,wall.group);if(overlay)overlay.userData.gridFaces=outward?'interior-and-room-facing-joints':'all';
  }
  return{group,material,floorOverlay,wallEntries,spacing,floorDatum,floorY};
}
