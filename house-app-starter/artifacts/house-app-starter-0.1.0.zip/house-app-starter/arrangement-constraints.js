export function wallAxes(bounds={}){
  return bounds.axis==='z'?{normal:'z',tangent:'x',plane:bounds.planeZ}:{normal:'x',tangent:'z',plane:bounds.planeX};
}

export function constrainWallPosition(candidate,start,bounds,offsets,{allowHeight=true}={}){
  const axes=wallAxes(bounds),next={...start};
  next[axes.tangent]=candidate[axes.tangent];
  if(allowHeight)next.y=candidate.y;
  if(!bounds)return next;
  const clamp=(value,min,max,fallback)=>Number.isFinite(min)&&Number.isFinite(max)&&min<=max?Math.min(max,Math.max(min,value)):fallback;
  const axis=axes.tangent,capital=axis.toUpperCase();
  next[axis]=clamp(next[axis],bounds[`min${capital}`]-offsets[`min${capital}`],bounds[`max${capital}`]-offsets[`max${capital}`],start[axis]);
  next.y=clamp(next.y,bounds.minY-offsets.minY,bounds.maxY-offsets.maxY,start.y);
  return next;
}
