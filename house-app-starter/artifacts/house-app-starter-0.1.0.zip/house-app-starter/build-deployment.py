#!/usr/bin/env python3
"""Create a verified deployment folder using only the declared runtime files."""
import argparse
import json
from pathlib import Path
import shutil
import tempfile
import uuid
from verify_deployment_support import verify

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, default=ROOT / 'dist')
args = parser.parse_args()
output = args.output.resolve()
if output == ROOT or output in ROOT.parents or output.is_symlink():
    raise SystemExit('Refusing to replace source, parent or symlink output')
if output.exists() and not (output / 'build-manifest.json').is_file():
    raise SystemExit('Output exists without a recognized deployment manifest')
verify(ROOT)
manifest = json.loads((ROOT / 'build-manifest.json').read_text())
output.parent.mkdir(parents=True, exist_ok=True)
stage = Path(tempfile.mkdtemp(prefix='.house-deploy-', dir=output.parent))
backup = output.parent / ('.house-backup-' + uuid.uuid4().hex)
try:
    for relative in [*manifest['files'], 'build-manifest.json']:
        target = stage / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / relative, target)
    verify(stage, deployed=True)
    if output.exists():
        output.rename(backup)
    try:
        stage.rename(output)
    except BaseException:
        if backup.exists():
            backup.rename(output)
        raise
    if backup.exists():
        shutil.rmtree(backup)
finally:
    if stage.exists():
        shutil.rmtree(stage)
print(f'Created verified deployment: {output}')
