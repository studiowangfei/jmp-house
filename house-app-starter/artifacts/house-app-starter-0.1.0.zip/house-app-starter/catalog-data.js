import {projectConfig} from './project-config.js';

// Geometry and initial placement are separate from human-readable metadata.
export const productCatalog=projectConfig.products;
export const materialCatalog=projectConfig.materials;
