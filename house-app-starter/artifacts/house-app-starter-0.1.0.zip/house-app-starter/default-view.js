// Fit any authored scene to the same responsive viewer shell.
export function createHomeView(THREE,bounds,overrides={}){
  if(!bounds||bounds.isEmpty())throw new TypeError('Home framing requires a nonempty scene');
  const center=bounds.getCenter(new THREE.Vector3()),size=bounds.getSize(new THREE.Vector3());
  const target=Array.isArray(overrides?.target)?new THREE.Vector3(...overrides.target):center.clone();
  const direction=new THREE.Vector3(...(overrides?.direction||[1.25,1.1,1])).normalize();
  const right=new THREE.Vector3(0,1,0).cross(direction).normalize(),up=direction.clone().cross(right).normalize();
  let width=0,height=0;
  for(const x of [bounds.min.x,bounds.max.x])for(const y of [bounds.min.y,bounds.max.y])for(const z of [bounds.min.z,bounds.max.z]){
    const corner=new THREE.Vector3(x,y,z).sub(target);width=Math.max(width,Math.abs(corner.dot(right)));height=Math.max(height,Math.abs(corner.dot(up)));
  }
  const distance=Math.max(30,size.length()*3),margin=overrides?.margin||1.38;
  return{
    target:target.toArray(),offset:direction.multiplyScalar(distance).toArray(),
    halfWidth:Math.max(1,width*margin),halfHeight:Math.max(1,height*margin),
    zoom:overrides?.zoom||1,viewportShiftBlend:0,viewportLiftBlend:1,
  };
}

export function createDaylightFrame(THREE,bounds,direction=[-1,2.1,1.25]){
  if(!bounds||bounds.isEmpty())throw new TypeError('Daylight framing requires a nonempty scene');
  const target=bounds.getCenter(new THREE.Vector3()),radius=bounds.getBoundingSphere(new THREE.Sphere()).radius;
  const distance=Math.max(20,radius*3),span=Math.max(3,radius*1.25);
  return{target,position:target.clone().add(new THREE.Vector3(...direction).normalize().multiplyScalar(distance)),span,near:.1,far:distance+radius*2};
}
