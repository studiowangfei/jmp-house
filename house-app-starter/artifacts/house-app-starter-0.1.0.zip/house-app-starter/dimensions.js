// Scene geometry is authored in meters. These helpers affect displayed labels.
export function formatDimension(meters,units='in'){
  if(!Number.isFinite(meters)||meters<0)throw new TypeError('Dimension must be a finite nonnegative meter value');
  return units==='cm'?`${Math.round(meters*100)} cm`:`${Math.round(meters/.0254)}\"`;
}

export function formatProductDimensions(size,units='in'){
  const factor=units==='cm'?100:1/.0254;
  return size.map(value=>(value*factor).toFixed(1).replace(/\.0$/,'')).join(' × ')+(units==='cm'?' cm':' in');
}
