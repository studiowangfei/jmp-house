# Staged intake for the agent

Read the user's supplied files and answers first. Ask only for missing facts in
small batches. The homeowner can send drawings, screenshots, ordinary notes,
links and product names. Maintain the structured records yourself. File paths
below are relative to the starter root; guides live in `docs/`.

Use [project/input-template.json](../project/input-template.json) to start
`project/input.json`. Preserve the
blank template. It is an intake record, not the object consumed by `buildHouse`.
[WORKFLOW.md](WORKFLOW.md) explains its conversion into `project/house-brief.json` and config.

## Batch 1: minimum for a measured house shell

Request only the absent critical items:

1. The latest readable plan or usable measured geometry, its revision and the
   intended number of levels. Ask for a useful export if a supplied binary file
   cannot be inspected with available tools.
2. Units and reliable scale in both plan directions. A usable measured model or
   dimensioned drawing may already establish these. Resolve inside-face,
   outside-face or centerline interpretations where they materially change fit.
3. Finished-floor-to-ceiling heights, real level changes, and important user
   corrections that supersede the drawing.

Room names, elevations, window/door dimensions, built-in drawings and room photos
help clarify the shell. Read available evidence before asking for more.
Unmeasured thickness, swings or hidden details can be labeled estimates when
appropriate; a disputed scale or ceiling height remains unresolved.

A floor datum of zero can be an agent-chosen coordinate origin. Record that
choice separately from physical level measurements. Template/demo values are
not evidence for the homeowner's house.

**Example first reply after file inspection**

> I found your plan and room photographs. To make the measured shell, I still
> need [only the missing scale, units, height or level facts]. Send them in the
> format you have. I can research any furniture names already supplied while
> those house questions are open.

The existing builder supports one level and orthogonal walls. Identify angled
walls, stairs, different room levels/heights or additional floors early, then
plan the required geometry, movement and viewing changes for the user's scope.

## Batch 2: products and materials

**A product name is enough to begin research.** Brand, URL, SKU, size/handedness,
finish or reference photos can help but are not prerequisites for starting.

- Research manufacturer specifications and photographs, then useful retailer
  evidence. Identify variant ambiguity before treating the dimensions as final.
- Inspect several useful angles and dimensions; author a procedural model,
  preview it, refine distinctive details and regenerate its thumbnail.
- Ask the homeowner only for unresolved choices or references that tools cannot
  retrieve. User-provided 3D furniture files are optional.
- Collect quantity and room/placement preferences as integration approaches.
  Unspecified arrangements can be clearly labeled proposals for review.

For materials, collect a name/link or swatch/photo and intended surfaces. Research
physical tile/slab/repeat sizes, grain direction and finish. Preserve user
selections and record color/shape estimates separately from factual dimensions.

**Example input**

> Add two IKEA MARIUS stools in black near the dining table. Research the photos
> and dimensions and show me the models. Use the tile swatch on the living floor.

## Batch 3: placements, identity and optional media

Collect the remaining information when the furnished preview is useful:

- Marked placement plan or room/wall/table relationships, quantities, rotations,
  clearances, pendant body heights/cord drops and wall mounting heights.
- Project title/description, inches or centimeters for labels, Gallery photos and
  captions.
- Desired audio/video, landscape and fireplace imagery where applicable.
- Intended local/deployment output and a page URL for Share when available.

Record provisional placements and media as proposals or synthetic placeholders.
Discuss missing object-dependent features using the actual house. An absent
fireplace or speaker is a reason to mark its interaction inapplicable, rather
than adding unsupported building elements.

## Evidence and persistent records

Use these files so another session can continue:

| File | Contents |
| --- | --- |
| `project/input.json` | Transcribed supplied facts, references and open questions |
| `project/sources.json` | Evidence conforming to `project/sources.schema.json` |
| `project/decisions.json` | User choices/corrections, affected files and superseded decisions |
| `project/progress.json` | Current stage, pending reviews, next work and actual verification results |
| `project/house-brief.json` | Authored runtime house data, produced after transcription/calibration |
| `references/project-reviews/` | Shell, product and furnished-house previews |

For each important fact, retain its source ID, original units and interpretation,
converted meter value, target and confirmed/estimated/unresolved status. Sources
can be explicit user measurements/corrections, manufacturer specs, retailer
specs, measured drawings or labeled inference. Precedence depends on the fact:
a user-selected finish overrides the photographed finish, while published
manufacturer dimensions remain separate from image-derived detail.

[project/sources.schema.json](../project/sources.schema.json) defines record structure. The current build does
not automatically validate intake/source records or convert them into geometry;
check those records yourself and create the runtime brief deliberately.

## Review behavior

Show a concrete shell preview, product/material previews and a furnished-house
preview. Ask specific questions about uncertain areas or corrections. Batch
reviews and continue confirmed/independent work while waiting. Standing user
instructions and accepted choices persist. Silence does not answer an unresolved
critical question.
