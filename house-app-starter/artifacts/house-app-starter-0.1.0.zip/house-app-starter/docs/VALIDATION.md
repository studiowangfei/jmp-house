# Verify and deliver your house app

Run commands from the starter root, beside `README.md`. Previewing the shipped
`runtime/` viewers requires Python 3.10+. Source builds and automated browser
checks also require Node.js 22+ and npm. Browser evidence needs a browser that
the agent can launch, or a manual review in the owner's browser. Record the
checks actually completed.

## 1. Save the untouched demo baseline

Keep the supplied starter ZIP unchanged and work in an extracted project copy.
Preview that untouched copy's prebuilt files:

```sh
python3 scripts/serve.py
```

Open `http://127.0.0.1:4175/` and `/runtime/products.html`. Leave the server
running. For automated captures, install the development/browser tools in a
second terminal in the same checkout:

```sh
npm ci
npx playwright install chromium
npm run visual:smoke -- --output artifacts/baseline
npm run visual:smoke -- --record --motion --output artifacts/baseline-motion
```

The default run uses reduced motion for screenshots. The second run records the
automated sequence with normal motion. Save its manifests and the shipped
`runtime/build-manifest.json` identity with the baseline. Also capture the supplementary interactions in section 4; the
automated sequence covers a subset of the app.

If browser launch is unavailable, use section 5 to obtain real UI evidence before
editing when possible. The bundled [plan](../references/demo-plan.svg) and [axon image](../references/demo-axon.png) are
geometry references. UI captures saved under `references/project-reviews/` are
separate browser evidence. After adaptation, compare control styling, layouts and
behavior against the untouched app. Compare the new house geometry against its
own inputs. Pixel equality is not expected between different houses.

## 2. Check the new house and researched products

Complete these checks at the shell, product and furnished-house review points:

- Check measured spans in both plan directions, ceiling/floor levels, wall-face
  interpretations, room names, openings and built-ins against user inputs.
- Verify room floor regions cover the footprint exactly once. Keep one visible
  finish surface per interior region; avoid a competing foundation cap underneath
  it. Review floors while orbiting through low angles for flashing or seams.
- Verify positive finite geometry, connected walls, opening fit, material
  assignments/repeat scale, quantities, orientation and mounting heights.
- Check each researched product's exact variant, nominal W/D/H, finish and
  supporting evidence. Inspect its front, side and 3D silhouette. Confirm a
  pendant's body dimensions exclude its cord/canopy.
- Keep product finishes independently owned; check movement bounds, emitter and
  mirror tags, feature bindings and camera focus for this footprint.
- Check completed source records against [project/sources.schema.json](../project/sources.schema.json). Its
  statuses are `confirmed`, `estimated`, `synthetic` and `unresolved`; retain the
  correct status for inferred dimensions and illustrative appearance.

Expected counts come from this project's catalogs, placements, photos and
bindings. The demo's eight products, four materials and six photos are examples.
Update demo-specific regression expectations for the new measured house; do not
retain fictional objects or counts merely to make a check pass. Add regressions
for meaningful measured spans and user corrections.

After changes:

```sh
npm run render:thumbnails
npm run check
```

Inspect the regenerated thumbnails. CPU geometry renders can confirm shape and
placement using approximate lighting. They do not verify live WebGL shading,
reflections, UI, motion, picking, drag or touch behavior. Keep CPU evidence and
browser evidence labeled by their actual method.

## 3. Capture the finished app's UI

With the updated app served at port 4175:

```sh
npm run visual:smoke -- --output artifacts/final-ui
npm run visual:smoke -- --record --motion --output artifacts/final-motion
```

For another server use `--current-url`, for example:

```sh
npm run visual:smoke -- --current-url http://127.0.0.1:4180/ --output artifacts/final-ui
```

Inspect `manifest.json`, the PNGs and any recordings in each evidence folder.
The manifest records the browser, viewport, motion preference, recording choice,
settle waits, loaded counts, screenshot hashes, failures and scenario status.
A passing run establishes its listed assertions; inspect the images for layout,
materials, occlusion and readable metadata. Browser/GPU differences can change
pixels. The script pauses/seeks TV before screenshots, but does not establish
frame-perfect TV playback or transition behavior.

| Required states | Desktop 1440×900 | Phone 390×844 | Landscape 844×390 |
|---|---|---|---|
| Loaded Day/3D, Reset, Plan | Capture | Capture | Capture |
| Night | Capture | Capture | Capture |
| Expanded material and product | Capture | Capture | Capture |
| Gallery and information | Capture | Capture | Capture |
| Rearrange selection and snapshot | Capture | Capture | Capture |
| Layers/cutaway, wall/surface edits, applicable media | Supplement | Supplement | Supplement |

The harness opens the first material/product, uses the Gallery toolbar and a
keyboard step, selects a floor item through the inspection API, exercises
rotate/duplicate/undo/redo controls, checks snapshot orientation and saves PNG.
It assumes at least one material, product and editable floor item, plus a usable
Gallery. If the new house legitimately omits a scenario, adapt its fixture
selection or record that case as inapplicable and test the applicable controls.
The script reports counts; it does not verify all objects or every interaction.

Normal-motion mode uses `no-preference`, longer general settling and a 4.5-second
wait for catalog focus. Recordings show the automated sequence only. Supplement
them with direct interaction checks below.

## 4. Supplement with normal-motion interaction checks

Use the real UI in desktop and phone-sized layouts. Use a touch-capable browser
or actual phone for touch gestures. Save short recordings of the relevant flows
and note the results; `--record --motion` alone does not perform these checks.

- **Viewer/layers:** orbit, zoom/pan, Plan pan, 90-degree rotate, Reset and each
  layer/cutaway toggle. Frames/glass/media follow their host walls. Check steady
  framing, floors, lighting and mirror views at several angles.
- **Catalog:** select several products/materials, verify correct highlighted
  targets and readable metadata, live previews, camera focus and restoration.
  Swipe the catalog on touch without accidental activation or competing model
  gestures. Check the focused object remains clear of the expanded card.
- **Rearrange:** physically pick and drag floor, surface and wall items; test
  boundaries, 15-degree rotation, duplicate/delete, undo/redo and Reset. Verify
  dimensions and fixed architecture/cabinetry. Check edited lights/mirrors/photos
  and their duplicates still behave correctly.
- **Gallery:** click a visible scene frame and verify the matching image and
  Genie transition. Test thumbnail selection, arrows, touch swipe, close/Escape,
  focus restoration and the return to the scene. Toolbar opening alone does not
  test the frame transition.
- **Snapshot/Share:** preview/save the correct orientation without editor
  helpers; dismiss cleanly. Verify project-link copy/native share and cancellation
  in the actual browser. Share does not encode edits or send the snapshot image.
- **Audio:** speaker hotspot, play/pause, previous/next, progress, repeat mode,
  audible output and reactive parts. Account for user-gesture media permission.
- **TV/fireplace/mirror:** verify day/night TV media and transition, fireplace
  on/off and flame motion, real reflections and layer/overlay visibility. Confirm
  unnecessary media/animation stops when hidden. These are not automated by the
  screenshot sequence.
- **Responsive/accessibility:** information panel, controls and overlays fit
  portrait/landscape; keyboard focus/Escape and reduced-motion behavior remain
  usable. Review console/network failures as well as visible behavior.

## 5. When the agent cannot launch a browser

Finish the build and provide the owner a running local preview, product-preview
URL, review checkpoints and the section 4 checklist. Have the owner open the app
in their ordinary browser and review the applicable desktop/phone layouts. Save
actual screenshots/recordings when available and incorporate reported issues.

Record who reviewed it, browser/device, date, covered states, results and evidence
paths in the verification summary. Keep an automated-launch failure recorded as
such. Mark any checks not completed as pending; CPU renders and successful
Node/build checks do not establish that the UI works. Avoid repeated failed
launch attempts or changes to browser/security settings.

## 6. Build, package and test a clean extraction

After corrections and validation:

```sh
npm run check
npm run build:deployment
npm run package:starter
```

`dist/` is the verified static deployment folder. The packager prints the source
ZIP path and excludes `node_modules`, local artifacts and the deployment folder.
Make a separate ZIP for deployment if needed:

```sh
python3 - <<'PY'
from pathlib import Path
import shutil
Path('artifacts').mkdir(exist_ok=True)
print(shutil.make_archive('artifacts/house-deployment', 'zip', root_dir='dist'))
PY
```

Check and extract the source ZIP into a new directory:

```sh
python3 - <<'PY'
import json
from pathlib import Path
import tempfile
import zipfile
version = json.loads(Path('package.json').read_text())['version']
archive = Path('artifacts') / f'house-app-starter-{version}.zip'
target = Path(tempfile.mkdtemp(prefix='house-app-clean-'))
with zipfile.ZipFile(archive) as package:
    assert not any('node_modules' in Path(name).parts for name in package.namelist())
    package.extractall(target)
print('Clean source directory:', target / 'house-app-starter')
PY
```

First preview the prebuilt output from the printed clean source directory:

```sh
python3 scripts/serve.py --port 4180
```

Open `http://127.0.0.1:4180/` and `http://127.0.0.1:4180/runtime/products.html`; verify
relative assets and the relevant flows again. In that clean source directory,
then verify dependency installation and rebuilding:

```sh
npm ci
npm run check
```

Extract the deployment ZIP into
another fresh folder and serve it with `python3 -m http.server 4181 --directory`
followed by that folder's path. Confirm it runs independently of source files
and installed packages.

Deliver source ZIP, deployment folder/ZIP, completed input/source/decision records,
run/update/deploy instructions, actual evidence and a concise verification summary
with pending checks and remaining estimates. This viewer does not certify
surveyed geometry, fabrication dimensions or photometric lighting.

For a reusable starter release, separately test the prompt with a fresh agent and
substantially different house inputs. Record that adaptation's results alongside
the demo checks; distinguish researched products from synthetic demo content.
