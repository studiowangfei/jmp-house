# Agent build workflow

Follow these six stages with the supplied starter as the working project. Read
[README.md](../README.md), [GUIDE.md](GUIDE.md), [APP_SPEC.md](APP_SPEC.md),
[INPUTS.md](INPUTS.md) and [SCENE_CONTRACT.md](SCENE_CONTRACT.md) first. The user
can provide ordinary files, notes and product names; maintain the records below
on their behalf. File paths and commands below are relative to the starter root,
where `README.md`, `BUILD_PROMPT.txt` and `index.html` live.

## Records and review checkpoints

| Output | Purpose |
|---|---|
| `project/input.json` | Supplied facts, measurements, selections and unresolved inputs |
| `project/sources.json` | Research evidence, selected variants and factual status |
| `project/house-brief.json` | Completed runtime house records used by the scene |
| `project/decisions.json` | Corrections, choices, source IDs and superseded interpretations |
| `project/progress.json` | Current stage, questions, reviews, checks and next steps |
| `references/project-reviews/` | Annotated previews, browser captures and review evidence |

Initialize the three working records by copying `input-template.json`,
`decisions-template.json` and `progress-template.json` from `project/`. Their
entry templates describe record shapes; they are not actual selections or
decisions. Start an evidence registry for this house using
`project/sources.schema.json`. Keep any retained demo records labeled synthetic.

At a checkpoint, show the relevant preview and state the specific facts or
choices that need clarification. Continue confirmed work and independent
research while answers are pending. Keep a critical fact unresolved until the
user or suitable evidence resolves it; silence does not settle it. Record
feedback and apply corrections to the input, runtime brief and affected tests.

## 1. Start, critical intake and baseline

Inspect every supplied plan, drawing, photo, measurement and selection before
asking questions. Inventory source files in `project/input.json`. Ask for
missing critical data in small related batches: house layout, reliable plan
lengths in both directions, original units and measured wall faces, ceiling
height, levels, major openings and built-ins. Keep unknown values null. A zero
floor level may be a chosen coordinate origin; label that choice explicitly.

The current demo supports one level and orthogonal wall runs. Identify angled
walls, multiple levels, roofs or stairs early and plan the necessary scene and
view extensions. Furniture research can proceed while unrelated house facts
are being resolved.

Preview the untouched shipped browser files in `runtime/` using Python 3.10 or
newer:

```sh
python3 scripts/serve.py
```

Open [the house](http://127.0.0.1:4175/) and
[product previews](http://127.0.0.1:4175/runtime/products.html). Capture the working UI before
adapting the project, under
`references/project-reviews/stage-01-baseline/`. Inspect desktop, phone portrait
and landscape layouts. The bundled plan and CPU geometry references document
geometry; obtain the UI baseline from the running viewer. Record unavailable
browser capabilities in progress rather than recording a passed check.

**Outputs:** initial input/source records, critical questions, baseline evidence
and a short scope decision.

## 2. Measured shell

Before editing/building, use Node.js 22 or newer and npm to install the locked
dependencies once:

```sh
npm ci
```

Edit JavaScript/CSS/product-page sources under `src/`; generated browser outputs
and `runtime/build-manifest.json` are written under `runtime/`. Rebuild with
`npm run build` after source or imported-data changes before reviewing the app.

Calibrate the plan in both directions using confirmed spans. Register image
anchors and document distortion, inside/outside wall faces and each original
unit conversion. Convert the final scene to meters, with Y up and X/Z on the
ground. Resolve conflicting measurements that materially change fit before
constructing the affected geometry. Label traced or interpolated details as
estimates.

Author `project/house-brief.json` with a `house` object, then update the import
in `src/project-config.js`:

```js
import houseBrief from '../project/house-brief.json' with {type:'json'};
```

Set its exported config's house property to `house: houseBrief.house`. Align the
fallback brief import in `src/model.js` too. There is no automatic intake converter,
and the build/check commands do not validate the source registry against its
JSON schema.

| Intake record | Runtime transcription |
|---|---|
| `project.displayUnits` | `projectConfig.units`, either `in` or `cm` |
| Named `house.dimensions` measurement records | Runtime `house.dimensions: {width,depth}` for footprint centerline bounds; retain other spans in evidence and geometry checks |
| Extracted `house.openings` | Openings nested in ordered `exteriorWalls` or partition records |
| Product `sizeMeters`, `referenceUrl` | Catalog `size: [width,depth,height]`, `source` |
| Product quantity and placement notes | Individual runtime `house.placements` with stable instance IDs |

The current validator requires a footprint with positive signed X/Z area, an
exterior-wall record per perimeter edge, finite orthogonal wall runs, valid
opening offsets and nonoverlapping room polygons that cover the house. Runtime
width/depth describe wall centerlines. Convert measurements taken between other
faces before assigning those values.

Establish the floor datum, ceiling, partitions, actual opening voids and fixed
cabinetry. Preserve `floorRegion` metadata on finishes. Finishes own the interior
top surface: keep the foundation's interior cap removed and its remaining
sides/outside ledge 3 mm below the floor to prevent competing horizontal surfaces, including reflections.

Show a Plan preview and several 3D directions under
`references/project-reviews/stage-02-shell/`, with measured spans and estimates
identified. Ask concrete questions about uncertain walls or opening positions.
Keep unrelated work moving.

**Outputs:** runtime brief, authored shell, calibration evidence and meaningful
measured-span/opening checks.

## 3. Product and material research and modeling

Begin each selected product with its name. Identify the manufacturer, exact
variant/SKU, finish, dimensions and useful front/side images or drawings. Prefer
exact manufacturer information, then reliable retailer specifications. Ask
about ambiguities that change dimensions or appearance. User-supplied 3D files
are optional.

Record evidence in `project/sources.json`: source URL/file, original and converted
dimensions, selected variant, checked date and usage. Use `confirmed` for facts
supported by the user or applicable specifications, `estimated` for inference,
`synthetic` for fictional examples and `unresolved` for missing facts. A verified
envelope does not make authored curves, upholstery or screen colors verified
manufacturer geometry. Record those estimates separately. If some dimensions
are published and others inferred, retain each dimension's evidence/status;
partial values can be recorded individually until a complete envelope is available.

For every new product ID, add both catalog metadata and an actual builder to
`src/product-library.js`. Reconstruct distinctive parts and silhouette, inspect
front/side/3D views in `runtime/products.html`, and refine against references. Normalizing
the envelope should follow shape refinement.

Preserve these executable conventions:

- Fresh owned groups/materials; `product body` centered on X/Z with its lowest
  point at Y zero, and local +Z front. `size` is W/D/H in meters.
- Pendant cord/canopy outside `product body` in `adjustable suspension`.
- `lighting:true` on every Night fixture, plus placement `fixtureLight` metadata.
  `pendant` or `floorLamp` flags alone do not choose the lighting layer.
- `lightEmitter` tags on actual emitter meshes; derive root-local light anchors
  after final normalization. Fixture power uses lumens and remains illustrative.
- Current live-mirror builders provide `mirror face` and `mirror frame` meshes,
  with `mirrorSurface`/`mirrorFrame` tags; wall-mounted roots carry `wallFrame`.
- Keep the `src/scene/room-reflector.js` helper for live reflection so orthographic
  zoom/offsets clip objects behind the mirror and preserve physical wall occlusion.
- Reactive speaker parts use `audioReactive` objects with an `indicator`, `dial`
  or `driver` kind, following [SCENE_CONTRACT.md](SCENE_CONTRACT.md).

For materials, record selected finish, assigned surfaces, swatch evidence,
physical repeat dimensions, grain direction and appearance estimates. Update
`assetKey` bindings, static image imports and `materialCatalogKey` mesh tags.
Keep product finishes independent from house materials.

Regenerate thumbnails after refinement:

```sh
npm run render:thumbnails
npm run build
```

The thumbnail renderer uses CPU geometry and approximate lighting. Review its
images and the actual browser preview. Store selection references and product
reviews under `references/project-reviews/stage-03-products/`.

**Outputs:** source evidence, dimensioned builders/materials, revised catalog,
matching thumbnails and product review questions.

## 4. Furnished integration, identity and review

Use supplied quantities, orientation and placement instructions. Where these
are unspecified, produce clearly labeled proposals for review and record their
status. Place objects in meter coordinates. Apply house calibration once;
preserve each product's independent physical envelope. In the brief, placement Y and wall-bound heights are relative to
`floorLevel`. Record body-bottom installation height separately from pendant
drop and ceiling attachment.

Assign stable `movableItem` IDs and floor, surface or wall constraints. Surface
bounds include the actual support plane. Wall bounds name the fixed normal
coordinate: `axis:'x'` uses `planeX` and allows Y/Z movement; `axis:'z'` uses
`planeZ` and allows X/Y movement. Match actual host geometry and full item bounds.
Wall-mounted TV geometry needs a real solid wall face and mounting plate, with
host visibility retained under cabinetry. Author another real support if the
user selected a stand. Set TV dimensions and installation height from the user's
data; these are separate from the media-cabinet size.

Return explicit bindings for the user's applicable gallery, audio, TV, fireplace,
mirrors and landscape. Gallery frames use local XY/+Z and stable photo indices.
Shelf cells and fixture anchors stay local to their roots so movement and
duplication preserve Night effects. Preserve functional roots during batching.

Set title, description, display units, photo captions and media paths in
`src/project-config.js`; update `src/media-assets.js` and `src/product-thumbnails.js` imports.
Share uses the configured project URL or current page URL. Recompute home/focus
framing and check control clearance for the new footprint. Handle absent optional
objects/media without inventing house elements for interaction targets.

Show furnished Plan, 3D and Night views under
`references/project-reviews/stage-04-furnished/`. Request specific corrections to
placements, clearances, mounts or variants. Write accepted corrections into the
runtime brief; Rearrange edits alone remain in session memory.

**Outputs:** furnished scene, identity/media, applicable feature bindings and
review feedback linked to decisions.

## 5. Verification and corrections

Follow [VALIDATION.md](VALIDATION.md) and run the complete production gate after source or asset
changes:

```sh
npm run check
```

This runs tests, rebuilds both viewers and verifies runtime hashes/source
freshness. `build:products` rebuilds only the product preview and is insufficient
after a shared builder change. Adapt assertions about demo IDs, counts and spans
to this house while retaining factory and interaction contracts. Check actual
geometry against important measurements and corrections, including floor
coverage, opening voids, host supports and ceiling attachments.

With the server running, capture browser evidence, for example:

```sh
npx playwright install chromium
npm run visual:smoke -- --output references/project-reviews/stage-05-verification --record
```

The deterministic harness uses reduced motion. Use `--record --motion` for the
normal-motion automated sequence, and complete the supplementary direct
interaction checks described in VALIDATION.md.
Inspect desktop, phone portrait and landscape images, and exercise gestures,
catalog focus, Night, Rearrange/history/reset, snapshots, Share and applicable
media. Complete checks not covered by automation. Identify the evidence method;
CPU/vector geometry references do not establish browser behavior.

Fix concrete failures, record user corrections with `supersedes` links and
update affected records, geometry and checks. Rebuild after the final change.
Store each check's outcome, evidence path and `runtime/build-manifest.json` hash in progress.
If a capability is unavailable, record exactly what remains unverified and the
needed environment while completing unaffected work.

**Outputs:** corrected app, measurement/product checks, browser evidence and an
explicit account of estimates or verification still needed.

## 6. Delivery

Build the deployment and source archive from the verified final source:

```sh
npm run build:deployment
npm run package:starter
```

These commands verify existing outputs; they do not rebuild source. An existing
`dist` must match `runtime/build-manifest.json` before packaging. Keep version
values in the package, build and packaging scripts aligned if changing them.

Deliver the source archive, deployment folder/archive, completed project records,
review evidence, run/update/deploy instructions and remaining estimates. The
source archive excludes `node_modules`, `dist` and `artifacts`; provide deployment
and selected evidence separately or keep supported evidence under `references`.
Check the packaging allowlist for new top-level modules and unusual input file
types. Geometry helpers under `src/scene/` and JSON/Markdown project records have
supported directories. Deliver any needed raw CAD/PDF inputs and working
artifacts separately.

Extract the source archive into a clean location and preview its prebuilt output
with `python3 scripts/serve.py --port 4180`. Confirm the main page and
`/runtime/products.html` work with relative assets before installing dependencies.
Then run `npm ci` and `npm run check` there to verify source rebuilding.
Record the delivered build/archive identities and actionable next steps in
progress so another agent can resume without chat history.

For a reusable starter release, separately test a fresh agent using only the
package, prompt and a substantially different house brief. Record that adaptation
result separately from the bundled demo's verification.

## Updating the project records

- Add real measurement/product entries to `project/input.json`; leave unknown
  facts null and link them to source IDs. Template products start empty.
- Validate source records against the bundled schema using an available JSON
  Schema validator or an explicit field check. This is a separate documentation
  check, not a gate implemented by `npm run check`.
- Append decisions with stage, target, chosen/previous values, reason, source
  IDs, superseded decision IDs, affected files and linked review/check IDs.
- Update progress after each substantive action or correction. Keep stage
  status, open critical questions, review outcomes, exact check results,
  build/evidence identities and next steps current. Entry templates are format
  references; append actual records to their corresponding arrays.
