export function createEmbeddedHostBridge(currentWindow=globalThis.window){
 const parentWindow=currentWindow?.parent;
 const embedded=Boolean(parentWindow&&parentWindow!==currentWindow&&typeof parentWindow.postMessage==='function');
 const targetOrigin=currentWindow?.location?.protocol==='file:'
  ?'*'
  :(currentWindow?.location?.origin||'*');
 if(embedded)currentWindow.jmpHouseChildIntegrationInstalled=true;
 const post=data=>{
  if(!embedded)return false;
  parentWindow.postMessage(data,targetOrigin);
  return true;
 };
 return {
  setChildViewOpen(open){
   return post({type:'house-viewer:child-view',open:Boolean(open)});
  },
  requestClose(){return post('house-viewer:close');},
 };
}
