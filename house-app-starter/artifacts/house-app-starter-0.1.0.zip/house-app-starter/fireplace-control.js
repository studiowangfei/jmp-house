export function setFireplaceFireActive(fireplace,active){
  const fire=fireplace?.getObjectByName('illustrated fireplace fire');
  if(!fire)return false;
  const enabled=Boolean(active);fire.visible=enabled;fire.userData.enabled=enabled;fireplace.userData.fireOn=enabled;return enabled;
}

export function toggleFireplaceFire(fireplace){
  const fire=fireplace?.getObjectByName('illustrated fireplace fire');
  return setFireplaceFireActive(fireplace,!fire?.visible);
}
