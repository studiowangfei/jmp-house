const VERTEX_SHADER=`
varying vec2 vUv;

uniform vec2 uResolution;
uniform vec2 uSourceTopLeft;
uniform vec2 uSourceTopRight;
uniform vec2 uSourceBottomRight;
uniform vec2 uSourceBottomLeft;
uniform vec4 uTargetRect;
uniform vec2 uTravelDirection;
uniform vec2 uCurveDirection;
uniform vec2 uSourceCenter;
uniform vec2 uTargetCenter;
uniform float uTargetProjectionMin;
uniform float uTargetProjectionSpan;
uniform float uProgress;
uniform float uStagger;
uniform float uCurve;
uniform float uSqueeze;

float smoothHermite(float value){
  return value*value*value*(value*(value*6.0-15.0)+10.0);
}

void main(){
  vUv=uv;

  vec2 sourceBottom=mix(uSourceBottomLeft,uSourceBottomRight,uv.x);
  vec2 sourceTop=mix(uSourceTopLeft,uSourceTopRight,uv.x);
  vec2 source=mix(sourceBottom,sourceTop,uv.y);

  vec2 target=vec2(
    uTargetRect.x+uv.x*uTargetRect.z,
    uTargetRect.y+(1.0-uv.y)*uTargetRect.w
  );

  float projected=dot(target-uTargetCenter,uTravelDirection);
  float leading=clamp((projected-uTargetProjectionMin)/uTargetProjectionSpan,0.0,1.0);

  // The far edge leads while the edge nearest the source lingers. Interpolating
  // that delay across a dense mesh creates the curved, liquid funnel instead of
  // moving the photo as one rigid rectangle.
  float lag=1.0-leading;
  float moveDelay=lag*uStagger*0.57;
  float shapeDelay=lag*uStagger;
  float moveTime=clamp((uProgress-moveDelay)/max(0.001,1.0-moveDelay),0.0,1.0);
  float shapeTime=clamp((uProgress-shapeDelay)/max(0.001,1.0-shapeDelay),0.0,1.0);
  float moveMotion=smoothHermite(moveTime);
  float shapeMotion=smoothHermite(shapeTime);

  // Translation gets a shorter delay than expansion. The trailing portion
  // therefore follows the leading edge while it is still pinched at the wall,
  // producing the characteristic stretched neck of the Genie effect.
  vec2 movingCenter=mix(uSourceCenter,uTargetCenter,moveMotion);
  vec2 localShape=mix(source-uSourceCenter,target-uTargetCenter,shapeMotion);
  vec2 position=movingCenter+localShape;

  // Keep the trailing side pinched while the leading side opens. Because this
  // scales only across the travel axis and never reaches zero, it adds the
  // recognizable funnel neck without folding the texture over itself.
  float globalMotion=smoothHermite(uProgress);
  vec2 globalCenter=mix(uSourceCenter,uTargetCenter,globalMotion);
  float squeeze=sin(3.14159265*uProgress)*uSqueeze*pow(1.0-leading,1.35);
  float transverse=dot(position-globalCenter,uCurveDirection);
  position-=uCurveDirection*(transverse*squeeze);

  // A restrained quadratic bow keeps the flow from reading as a straight
  // diagonal stretch. It is zero at both endpoints, preserving exact alignment.
  float bow=4.0*moveMotion*(1.0-moveMotion);
  position+=uCurveDirection*(uCurve*bow*(0.35+0.65*leading));

  vec2 clip=vec2(
    position.x/uResolution.x*2.0-1.0,
    1.0-position.y/uResolution.y*2.0
  );
  gl_Position=vec4(clip,0.0,1.0);
}
`;

const FRAGMENT_SHADER=`
uniform sampler2D uMap;
varying vec2 vUv;

void main(){
  gl_FragColor=texture2D(uMap,vUv);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}
`;

function point(THREE,value){return new THREE.Vector2(value.x,value.y);}

/**
 * Creates a reusable, transparent WebGL layer for the gallery Genie transition.
 * The DOM gallery remains the owner of visibility/focus; this renderer only
 * draws and cancels the warped photo so it can be removed without restructuring
 * the rest of the gallery implementation.
 */
export function createGalleryGenieTransition(THREE,{viewer,segments=48}={}){
 let renderer=null,scene=null,camera=null,geometry=null,material=null,canvas=null,renderWidth=0,renderHeight=0,renderDpr=0;
 let animationFrame=0,runId=0,available=true,active=false,idled=false,abortCallback=null;

 const uniforms={
  uMap:{value:null},
  uResolution:{value:new THREE.Vector2(1,1)},
  uSourceTopLeft:{value:new THREE.Vector2()},
  uSourceTopRight:{value:new THREE.Vector2()},
  uSourceBottomRight:{value:new THREE.Vector2()},
  uSourceBottomLeft:{value:new THREE.Vector2()},
  uTargetRect:{value:new THREE.Vector4()},
  uTravelDirection:{value:new THREE.Vector2(0,-1)},
  uCurveDirection:{value:new THREE.Vector2(1,0)},
  uSourceCenter:{value:new THREE.Vector2()},
  uTargetCenter:{value:new THREE.Vector2()},
  uTargetProjectionMin:{value:0},
  uTargetProjectionSpan:{value:1},
  uProgress:{value:0},
  uStagger:{value:.28},
  uCurve:{value:12},
  uSqueeze:{value:.46},
 };

 function deactivateCanvas(){
  if(!canvas)return;
  canvas.classList.remove('is-active');
 }

 function cancel(){
  runId++;
  active=false;
  if(animationFrame)cancelAnimationFrame(animationFrame);
  animationFrame=0;abortCallback=null;deactivateCanvas();
 }

 function handleContextLoss(event){
  event.preventDefault();const notify=abortCallback;available=false;cancel();notify?.();
 }

 function handleContextRestored(){
  available=true;
  try{
   if(idled)shrinkDrawingBuffer();else syncSize();
   renderer?.compile(scene,camera);
  }catch{available=false;}
 }

 function destroyRenderer({loseContext=false,permanent=false}={}){
  const oldRenderer=renderer,oldCanvas=canvas;
  oldCanvas?.removeEventListener('webglcontextlost',handleContextLoss,false);oldCanvas?.removeEventListener('webglcontextrestored',handleContextRestored,false);
  geometry?.dispose();material?.dispose();oldRenderer?.dispose?.();
  if(loseContext)oldRenderer?.forceContextLoss?.();
  oldCanvas?.remove();
  geometry=null;material=null;renderer=null;scene=null;camera=null;canvas=null;
  renderWidth=0;renderHeight=0;renderDpr=0;uniforms.uMap.value=null;
  if(permanent)available=false;
 }

 function ensureRenderer(){
  if(!available)return false;
  if(renderer)return true;
  try{
   renderer=new THREE.WebGLRenderer({alpha:true,antialias:false,depth:false,stencil:false,premultipliedAlpha:true});
   renderer.outputColorSpace=THREE.SRGBColorSpace;
   renderer.setClearColor(0x000000,0);
   canvas=renderer.domElement;canvas.className='gallery-genie-canvas';canvas.setAttribute('aria-hidden','true');
   canvas.addEventListener('webglcontextlost',handleContextLoss,false);canvas.addEventListener('webglcontextrestored',handleContextRestored,false);viewer.appendChild(canvas);

   scene=new THREE.Scene();camera=new THREE.Camera();
   geometry=new THREE.PlaneGeometry(1,1,segments,segments);
   material=new THREE.ShaderMaterial({uniforms,vertexShader:VERTEX_SHADER,fragmentShader:FRAGMENT_SHADER,transparent:true,depthTest:false,depthWrite:false,side:THREE.DoubleSide,toneMapped:false});
   const mesh=new THREE.Mesh(geometry,material);mesh.frustumCulled=false;scene.add(mesh);
   if(idled)shrinkDrawingBuffer();else syncSize();renderer.compile(scene,camera);
   return true;
  }catch(error){
   console.warn('Gallery Genie transition unavailable; using classic morph.',error);
   destroyRenderer({permanent:true});
   return false;
  }
 }

 function syncSize(){
  if(!renderer)return false;
  const width=viewer.clientWidth,height=viewer.clientHeight;
  if(!width||!height)return false;
  const deviceDpr=Math.min(devicePixelRatio||1,2),pixelBudgetDpr=Math.sqrt(12000000/(width*height));
  const dpr=Math.max(.75,Math.min(deviceDpr,pixelBudgetDpr));
  if(width!==renderWidth||height!==renderHeight||Math.abs(dpr-renderDpr)>.01){
   renderWidth=width;renderHeight=height;renderDpr=dpr;renderer.setPixelRatio(dpr);renderer.setSize(width,height,false);
  }
  uniforms.uResolution.value.set(width,height);return true;
 }

 function shrinkDrawingBuffer(){
  if(!renderer)return false;
  renderer.setPixelRatio(1);renderer.setSize(1,1,false);
  renderWidth=1;renderHeight=1;renderDpr=1;uniforms.uResolution.value.set(1,1);return true;
 }

 function smoothHermite(value){return value*value*value*(value*(value*6-15)+10);}

 function mixPoint(a,b,amount){return{x:a.x+(b.x-a.x)*amount,y:a.y+(b.y-a.y)*amount};}

 function sourcePoint(sourceCorners,u,v){
  return mixPoint(mixPoint(sourceCorners[3],sourceCorners[2],u),mixPoint(sourceCorners[0],sourceCorners[1],u),v);
 }

 function targetPoint(targetRect,u,v){return{x:targetRect.left+u*targetRect.width,y:targetRect.top+(1-v)*targetRect.height};}

 function warpedPoint(layout,u,v,time,stagger,curve,squeezeAmount){
  const source=sourcePoint(layout.sourceCorners,u,v),target=targetPoint(layout.targetRect,u,v);
  const projected=(target.x-layout.targetCenter.x)*layout.direction.x+(target.y-layout.targetCenter.y)*layout.direction.y;
  const leading=THREE.MathUtils.clamp((projected-layout.projectionMin)/layout.projectionSpan,0,1),lag=1-leading;
  const moveDelay=lag*stagger*.57,shapeDelay=lag*stagger;
  const moveTime=THREE.MathUtils.clamp((time-moveDelay)/Math.max(.001,1-moveDelay),0,1);
  const shapeTime=THREE.MathUtils.clamp((time-shapeDelay)/Math.max(.001,1-shapeDelay),0,1);
  const moveMotion=smoothHermite(moveTime),shapeMotion=smoothHermite(shapeTime);
  const center=mixPoint(layout.sourceCenter,layout.targetCenter,moveMotion);
  const localSource={x:source.x-layout.sourceCenter.x,y:source.y-layout.sourceCenter.y};
  const localTarget={x:target.x-layout.targetCenter.x,y:target.y-layout.targetCenter.y};
  const local=mixPoint(localSource,localTarget,shapeMotion),globalMotion=smoothHermite(time),globalCenter=mixPoint(layout.sourceCenter,layout.targetCenter,globalMotion);
  const squeeze=Math.sin(Math.PI*time)*squeezeAmount*((1-leading)**1.35);
  let x=center.x+local.x,y=center.y+local.y;
  const transverse=(x-globalCenter.x)*layout.curveDirection.x+(y-globalCenter.y)*layout.curveDirection.y;
  x-=layout.curveDirection.x*transverse*squeeze;y-=layout.curveDirection.y*transverse*squeeze;
  const bow=4*moveMotion*(1-moveMotion)*curve*(.35+.65*leading);
  return{x:x+layout.curveDirection.x*bow,y:y+layout.curveDirection.y*bow};
 }

 function cross(a,b,c){return(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);}

 function deformationIsValid(layout,stagger,curve,squeeze){
  const divisions=12,frames=32;
  const first00=warpedPoint(layout,0,0,0,stagger,curve,squeeze),first10=warpedPoint(layout,1/divisions,0,0,stagger,curve,squeeze),first01=warpedPoint(layout,0,1/divisions,0,stagger,curve,squeeze);
  const winding=Math.sign(cross(first00,first10,first01));if(!winding)return false;
  for(let frame=1;frame<frames;frame++){
   const time=frame/frames;
   for(let y=0;y<divisions;y++)for(let x=0;x<divisions;x++){
    const u=x/divisions,v=y/divisions,nextU=(x+1)/divisions,nextV=(y+1)/divisions;
    const p00=warpedPoint(layout,u,v,time,stagger,curve,squeeze),p10=warpedPoint(layout,nextU,v,time,stagger,curve,squeeze),p01=warpedPoint(layout,u,nextV,time,stagger,curve,squeeze),p11=warpedPoint(layout,nextU,nextV,time,stagger,curve,squeeze);
    if(cross(p00,p10,p01)*winding<=1e-4||cross(p10,p11,p01)*winding<=1e-4)return false;
   }
  }
  return true;
 }

 function safeDeformation(layout,stagger,curve,squeeze){
  let safeStagger=THREE.MathUtils.clamp(stagger,0,.7),safeCurve=curve,safeSqueeze=THREE.MathUtils.clamp(squeeze,0,.8);
  for(let attempt=0;attempt<7;attempt++){
   if(deformationIsValid(layout,safeStagger,safeCurve,safeSqueeze))return{stagger:safeStagger,curve:safeCurve,squeeze:safeSqueeze};
   safeStagger*=.72;safeCurve*=.8;safeSqueeze*=.85;
  }
  return deformationIsValid(layout,0,0,0)?{stagger:0,curve:0,squeeze:0}:null;
 }

 function setGeometry(sourceCorners,targetRect,stagger,curve,squeeze){
  const [topLeft,topRight,bottomRight,bottomLeft]=sourceCorners;
  uniforms.uSourceTopLeft.value.copy(point(THREE,topLeft));
  uniforms.uSourceTopRight.value.copy(point(THREE,topRight));
  uniforms.uSourceBottomRight.value.copy(point(THREE,bottomRight));
  uniforms.uSourceBottomLeft.value.copy(point(THREE,bottomLeft));
  uniforms.uTargetRect.value.set(targetRect.left,targetRect.top,targetRect.width,targetRect.height);

  const sourceCenter=sourceCorners.reduce((sum,corner)=>sum.add(point(THREE,corner)),new THREE.Vector2()).multiplyScalar(.25);
  const targetCenter=new THREE.Vector2(targetRect.left+targetRect.width/2,targetRect.top+targetRect.height/2);
  const direction=targetCenter.clone().sub(sourceCenter),travelDistance=direction.length();
  if(travelDistance<1)direction.set(0,-1);else direction.multiplyScalar(1/travelDistance);
  const curveDirection=new THREE.Vector2(-direction.y,direction.x);
  // Prefer an upward bow in screen coordinates so the photo feels lifted from
  // the wall rather than sagging, regardless of which frame was selected.
  if(curveDirection.y>0)curveDirection.multiplyScalar(-1);

  const targetCorners=[
   new THREE.Vector2(targetRect.left,targetRect.top),
   new THREE.Vector2(targetRect.left+targetRect.width,targetRect.top),
   new THREE.Vector2(targetRect.left+targetRect.width,targetRect.top+targetRect.height),
   new THREE.Vector2(targetRect.left,targetRect.top+targetRect.height),
  ];
  const projections=targetCorners.map(corner=>corner.clone().sub(targetCenter).dot(direction));
  const projectionMin=Math.min(...projections),projectionMax=Math.max(...projections);
  const layout={
   sourceCorners,targetRect,
   sourceCenter:{x:sourceCenter.x,y:sourceCenter.y},targetCenter:{x:targetCenter.x,y:targetCenter.y},
   direction:{x:direction.x,y:direction.y},curveDirection:{x:curveDirection.x,y:curveDirection.y},
   projectionMin,projectionSpan:Math.max(1,projectionMax-projectionMin),
  };
  // Very short trips have no meaningful travel axis; fade the directional
  // funnel into a uniform mesh expansion instead of allowing an arbitrary bow.
  const directionalStrength=smoothHermite(THREE.MathUtils.clamp(travelDistance/80,0,1));
  const safe=safeDeformation(layout,stagger*directionalStrength,curve*directionalStrength,squeeze*directionalStrength);if(!safe)return false;
  uniforms.uTravelDirection.value.copy(direction);
  uniforms.uCurveDirection.value.copy(curveDirection);
  uniforms.uSourceCenter.value.copy(sourceCenter);
  uniforms.uTargetCenter.value.copy(targetCenter);
  uniforms.uTargetProjectionMin.value=projectionMin;
  uniforms.uTargetProjectionSpan.value=Math.max(1,projectionMax-projectionMin);
  uniforms.uStagger.value=safe.stagger;uniforms.uCurve.value=safe.curve;uniforms.uSqueeze.value=safe.squeeze;
  if(canvas){canvas.dataset.stagger=safe.stagger.toFixed(3);canvas.dataset.curve=safe.curve.toFixed(1);canvas.dataset.squeeze=safe.squeeze.toFixed(3);}
  return true;
 }

 function settle(id,onComplete,holdFinalFrame){
  if(id!==runId)return;
  active=false;animationFrame=0;abortCallback=null;onComplete?.();if(!holdFinalFrame)deactivateCanvas();
 }

 function animate({sourceCorners,targetRect,texture,duration=825,stagger=.28,curve=12,squeeze=.46,progressMap=value=>value,onProgress,onComplete,onAbort,holdFinalFrame=false}={}){
  cancel();
  idled=false;
  if(!ensureRenderer()||!syncSize()||!texture?.image||!sourceCorners?.every(corner=>Number.isFinite(corner.x)&&Number.isFinite(corner.y))||!targetRect?.width||!targetRect?.height)return false;
  const id=runId,start=performance.now();onProgress?.(0);
  uniforms.uMap.value=texture;uniforms.uProgress.value=0;
  if(!setGeometry(sourceCorners,targetRect,stagger,curve,squeeze))return false;
  canvas.classList.add('is-active');active=true;
  try{renderer.render(scene,camera);}catch{available=false;cancel();return false;}
  abortCallback=onAbort;

  const frame=now=>{
   if(id!==runId)return;
   const elapsed=now-start,linear=THREE.MathUtils.clamp(elapsed/duration,0,1);
   onProgress?.(linear);
   uniforms.uProgress.value=THREE.MathUtils.clamp(progressMap(linear),0,1);
   try{renderer.render(scene,camera);}catch{const notify=abortCallback;available=false;cancel();notify?.();return;}
   if(linear<1)animationFrame=requestAnimationFrame(frame);
   // Keep the exact uProgress=1 render alive for one real paint before the DOM
   // photo replaces it. Settling in this same callback can skip that frame.
   else animationFrame=requestAnimationFrame(()=>settle(id,onComplete,holdFinalFrame));
  };
  animationFrame=requestAnimationFrame(frame);return true;
 }

 function resize(){if(active)cancel();else if(!idled)syncSize();}

 function warm(texture){
  if(!texture?.image||!ensureRenderer())return false;
  try{renderer.initTexture?.(texture);return true;}catch{return false;}
 }

 // The default idle path keeps the compiled shader and texture uploads warm but
 // releases the full-viewport drawing buffer. Call with {release:true}, or use
 // release(), to relinquish the secondary WebGL context and recreate it lazily.
 function idle({release=false}={}){
  if(active)return false;
  idled=true;deactivateCanvas();uniforms.uMap.value=null;
  if(!renderer)return true;
  if(release)destroyRenderer({loseContext:true});
  else shrinkDrawingBuffer();
  return true;
 }

 function release(){return idle({release:true});}

 function dispose(){
  cancel();idled=true;destroyRenderer({loseContext:true,permanent:true});
 }

 return{animate,cancel,resize,warm,idle,release,dispose,get available(){return available;},get active(){return active;},get idled(){return idled;}};
}
