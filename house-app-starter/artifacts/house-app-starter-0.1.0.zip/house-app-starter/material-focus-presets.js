import {projectConfig} from './project-config.js';

// Optional new-project compositions; otherwise the viewer uses target bounds.
export function materialFocusPreset(assetKey){
  const hint=projectConfig.materialFocus?.[assetKey];
  return hint?{...hint,yaw:Number.isFinite(hint.yawDegrees)?hint.yawDegrees*Math.PI/180:hint.yaw}:null;
}
