function materialsForObject(object){
 return Array.isArray(object?.material)?object.material:[object?.material];
}

function hasExcludedAncestor(object,asset){
 for(let current=object;current;current=current.parent){
  if(asset.excludeRoots?.includes(current))return true;
  if(asset.excludeProductIds?.includes(current.userData?.productId))return true;
 }
 return false;
}

export function objectMatchesMaterialAsset(object,asset){
 if(!object?.isMesh||!object.material||hasExcludedAncestor(object,asset))return false;
 return materialsForObject(object).some(material=>material&&(asset.material?material===asset.material:material.map===asset.texture));
}

function matchingMaterialIndexes(object,asset){
 const indexes=[];
 materialsForObject(object).forEach((material,index)=>{
  if(material&&(asset.material?material===asset.material:material.map===asset.texture))indexes.push(index);
 });
 return new Set(indexes);
}

function triangleSegments(object,asset){
 const geometry=object.geometry,position=geometry?.attributes?.position,index=geometry?.index;
 if(!position)return[];
 const total=index?.count||position.count,matchingIndexes=matchingMaterialIndexes(object,asset);
 if(!Array.isArray(object.material)||!geometry.groups.length)return[{start:0,count:total}];
 return geometry.groups.filter(group=>matchingIndexes.has(group.materialIndex)).map(group=>({start:group.start,count:group.count}));
}

function meshSurfaceSamples(THREE,object,asset,limit){
 const geometry=object.geometry,position=geometry?.attributes?.position,index=geometry?.index,segments=triangleSegments(object,asset);
 const triangleCount=segments.reduce((sum,segment)=>sum+Math.floor(segment.count/3),0);
 if(!position||!triangleCount)return[];
 object.updateWorldMatrix(true,false);
 const a=new THREE.Vector3(),b=new THREE.Vector3(),c=new THREE.Vector3(),ab=new THREE.Vector3(),ac=new THREE.Vector3(),matchingMaterials=materialsForObject(object).filter(material=>material&&(asset.material?material===asset.material:material.map===asset.texture)),doubleSided=matchingMaterials.some(material=>material.side===THREE.DoubleSide);
 const triangleSample=ordinal=>{
  let triangleIndex=ordinal,segment=segments[0];
  for(const candidate of segments){const candidateCount=Math.floor(candidate.count/3);if(triangleIndex<candidateCount){segment=candidate;break;}triangleIndex-=candidateCount;}
  const offset=segment.start+triangleIndex*3,readVertex=(target,vertexOffset)=>target.fromBufferAttribute(position,index?index.getX(vertexOffset):vertexOffset).applyMatrix4(object.matrixWorld);
  readVertex(a,offset);readVertex(b,offset+1);readVertex(c,offset+2);
  const point=a.clone().add(b).add(c).multiplyScalar(1/3),normal=ab.subVectors(b,a).cross(ac.subVectors(c,a)).normalize();
  return [point.x,point.y,point.z].every(Number.isFinite)?{point,normal,object,doubleSided,weight:1}:null;
 };
 const objectSize=new THREE.Box3().setFromObject(object).getSize(new THREE.Vector3()),flat=objectSize.y<=Math.max(.08,Math.max(objectSize.x,objectSize.z)*.025),upwardSamples=[];
 if(flat)for(let triangleIndex=0;triangleIndex<triangleCount;triangleIndex++){const sample=triangleSample(triangleIndex);if(sample?.normal.y>.35)upwardSamples.push(sample);}
 const samples=[];
 if(upwardSamples.length){
  const count=Math.min(limit,upwardSamples.length);for(let sampleIndex=0;sampleIndex<count;sampleIndex++)samples.push(upwardSamples[Math.min(upwardSamples.length-1,Math.floor((sampleIndex+.5)*upwardSamples.length/count))]);
 }else{
  const count=Math.min(limit,triangleCount);for(let sampleIndex=0;sampleIndex<count;sampleIndex++){const sample=triangleSample(Math.min(triangleCount-1,Math.floor((sampleIndex+.5)*triangleCount/count)));if(sample)samples.push(sample);}
 }
 return samples;
}

function spatiallyDistributedSamples(THREE,candidates,bounds,limit){
 if(candidates.length<=limit)return candidates;
 const center=bounds.getCenter(new THREE.Vector3()),selected=[],remaining=[...candidates];
 let firstIndex=0,firstDistance=Infinity;
 for(let index=0;index<remaining.length;index++){
  const distance=remaining[index].point.distanceToSquared(center);
  if(distance<firstDistance){firstDistance=distance;firstIndex=index;}
 }
 selected.push(remaining.splice(firstIndex,1)[0]);
 while(selected.length<limit&&remaining.length){
  let bestIndex=0,bestDistance=-1;
  for(let index=0;index<remaining.length;index++){
   let nearest=Infinity;
   for(const sample of selected)nearest=Math.min(nearest,remaining[index].point.distanceToSquared(sample.point));
   if(nearest>bestDistance){bestDistance=nearest;bestIndex=index;}
  }
  selected.push(remaining.splice(bestIndex,1)[0]);
 }
 return selected;
}

export function materialFocusTargets(THREE,objects,asset,{maxSamples=48,isVisible=()=>true}={}){
 const meshes=objects.filter(object=>isVisible(object)&&objectMatchesMaterialAsset(object,asset)),bounds=new THREE.Box3().makeEmpty();
 for(const mesh of meshes){mesh.updateWorldMatrix(true,false);bounds.expandByObject(mesh);}
 if(bounds.isEmpty())return{meshes,bounds,samples:[]};
 const perMeshLimit=Math.min(64,Math.max(2,Math.ceil(maxSamples*2/Math.max(1,meshes.length)))),candidates=[];
 for(const mesh of meshes)candidates.push(...meshSurfaceSamples(THREE,mesh,asset,perMeshLimit));
 const samples=spatiallyDistributedSamples(THREE,candidates,bounds,maxSamples);
 if(!samples.length)samples.push({point:bounds.getCenter(new THREE.Vector3()),object:null,weight:1});
 return{meshes,bounds,samples};
}

export function materialFocusMinimumVerticalRatio(THREE,bounds){
 if(!bounds||bounds.isEmpty())return.85;
 const size=bounds.getSize(new THREE.Vector3()),horizontal=Math.max(size.x,size.z);
 return size.y<=Math.max(.08,horizontal*.2)?1.8:.85;
}
