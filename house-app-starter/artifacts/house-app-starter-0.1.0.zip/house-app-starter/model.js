import {createRoomReflector} from './scene/room-reflector.js';
import {createProduct,productCatalog} from './product-library.js';
import demoBrief from './project/demo-brief.json' with {type:'json'};
import {offsetOrthogonalFootprint,validateHouseInput} from './scene/geometry.js';

const radians=degrees=>(degrees||0)*Math.PI/180;

// This scene is driven by a fictional meter-based brief. The viewer consumes
// explicit targets, so replacing a house does not depend on its object names.
export function buildHouse(T,{project,materialTextures={},tvVideoTexture=null,fireplaceFireTexture=null}={}){
  const house=validateHouseInput(project?.house??demoBrief.house),floorLevel=house.floorLevel??0,ceilingLevel=floorLevel+house.ceilingHeight;
  const layers=Object.fromEntries(['architecture','cabinetry','glazing','furniture','lighting','trees'].map(key=>{
    const group=new T.Group();group.name=key[0].toUpperCase()+key.slice(1);return [key,group];
  }));
  const materials={},materialSpecs=new Map(),wallSchedule=[],exterior=[],glazingGroups=[],animators=[],animatedRoots=[],reflectors=[];
  const bindings={gallery:null,audio:null,tv:null,fireplace:null,landscape:null};
  const defaults={tile:{color:'#ded6c6',roughness:.82,repeat:[.6,.6]},stone:{color:'#c7beac',roughness:.56,repeat:[1.1,.8]},wood:{color:'#b28b5b',roughness:.64,repeat:[.28,1.4]},paint:{color:'#eeeae1',roughness:.9,repeat:[1,1]}};
  for(const key of new Set([...Object.keys(defaults),...(project?.materials||[]).map(record=>record.assetKey)])){
    const spec={...(defaults[key]||defaults.paint),...(project?.materials||[]).find(record=>record.assetKey===key)};
    if(!Array.isArray(spec.repeat)||spec.repeat.length!==2||spec.repeat.some(value=>!Number.isFinite(value)||value<=0))throw new Error(`Invalid material repeat: ${key}`);
    const texture=materialTextures[key]||null;
    if(texture){texture.wrapS=texture.wrapT=T.RepeatWrapping;texture.colorSpace=T.SRGBColorSpace;texture.repeat.set(1,1);}
    const material=new T.MeshStandardMaterial({color:spec.color,roughness:spec.roughness,map:texture});
    material.name=spec.name||`Demo ${key}`;materials[key]=material;materialSpecs.set(material,spec);
  }
  const dark=new T.MeshStandardMaterial({color:'#343938',roughness:.72});dark.name='Neutral dark metal';
  const porcelain=new T.MeshStandardMaterial({color:'#f3eee4',roughness:.3});porcelain.name='Demo porcelain';
  const fabric=new T.MeshStandardMaterial({color:'#e6dfd0',roughness:.94});fabric.name='Demo linen';
  const glass=new T.MeshStandardMaterial({color:'#bfd2ce',transparent:true,opacity:.22,roughness:.12,metalness:.02,depthWrite:false});glass.name='Demo glazing';

  function mesh(parent,name,geometry,material,position=[0,0,0],assetKey=null){
    const object=new T.Mesh(geometry,material);object.name=name;object.position.set(...position);
    object.castShadow=true;object.receiveShadow=true;if(assetKey)object.userData.materialCatalogKey=assetKey;
    parent.add(object);return object;
  }
  function mapBoxUV(object){
    const spec=materialSpecs.get(object.material);if(!spec)return;
    const {position,normal,uv}=object.geometry.attributes;
    for(let index=0;index<position.count;index++){
      const x=position.getX(index)+object.position.x,y=position.getY(index)+object.position.y,z=position.getZ(index)+object.position.z;
      if(Math.abs(normal.getY(index))>.5)uv.setXY(index,x/spec.repeat[0],z/spec.repeat[1]);
      else if(Math.abs(normal.getX(index))>.5)uv.setXY(index,z/spec.repeat[0],y/spec.repeat[1]);
      else uv.setXY(index,x/spec.repeat[0],y/spec.repeat[1]);
    }
    uv.needsUpdate=true;
  }
  function box(parent,name,size,position,material=materials.paint,assetKey=null){
    const object=mesh(parent,name,new T.BoxGeometry(...size),material,position,assetKey);mapBoxUV(object);return object;
  }
  function groupFor(record,parent=layers.cabinetry){
    const group=new T.Group();group.name=record.id;group.position.set(record.position[0],floorLevel+record.position[1],record.position[2]);group.rotation.y=radians(record.yaw);
    group.userData.builtInType=record.type;parent.add(group);return group;
  }
  function shapeFor(points){
    const shape=new T.Shape();points.forEach(([x,z],index)=>shape[index?'lineTo':'moveTo'](x,-z));shape.closePath();return shape;
  }
  const foundationPoints=offsetOrthogonalFootprint(house.footprint,house.wallThickness/2);
  const solidFoundationGeometry=new T.ExtrudeGeometry(shapeFor(foundationPoints),{depth:.2,bevelEnabled:false,steps:1});solidFoundationGeometry.rotateX(-Math.PI/2);
  // The room finishes own the interior top surface. Even a small vertical gap
  // can quantize to the same depth at grazing angles or in a reflection buffer.
  // Keep the slab's sides/bottom and remove its upward cap beneath every room.
  const retainedVertices=[],foundationNormals=solidFoundationGeometry.attributes.normal;
  for(let vertex=0;vertex<foundationNormals.count;vertex+=3){
    if([0,1,2].every(offset=>foundationNormals.getY(vertex+offset)>.9))continue;
    retainedVertices.push(vertex,vertex+1,vertex+2);
  }
  const foundationGeometry=new T.BufferGeometry();
  for(const [name,attribute] of Object.entries(solidFoundationGeometry.attributes)){
    const values=new attribute.array.constructor(retainedVertices.length*attribute.itemSize);
    retainedVertices.forEach((vertex,index)=>{
      for(let component=0;component<attribute.itemSize;component++)values[index*attribute.itemSize+component]=attribute.array[vertex*attribute.itemSize+component];
    });
    foundationGeometry.setAttribute(name,new T.BufferAttribute(values,attribute.itemSize,attribute.normalized));
  }
  solidFoundationGeometry.dispose();
  const foundationClearance=.003;
  const foundation=mesh(layers.architecture,'Foundation',foundationGeometry,materials.paint,[0,floorLevel-.2-foundationClearance,0]);
  foundation.castShadow=false;
  foundation.userData.foundation=true;foundation.userData.perimeter=foundationPoints;foundation.userData.finishedFloorClearance=foundationClearance;foundation.userData.interiorCapRemoved=true;
  // Preserve the narrow slab edge outside the house footprint without placing
  // another horizontal surface underneath its room finishes.
  const foundationLedgeShape=shapeFor(foundationPoints),interiorHole=new T.Path();
  house.footprint.forEach(([x,z],index)=>interiorHole[index?'lineTo':'moveTo'](x,-z));interiorHole.closePath();foundationLedgeShape.holes.push(interiorHole);
  const foundationLedgeGeometry=new T.ShapeGeometry(foundationLedgeShape);foundationLedgeGeometry.rotateX(-Math.PI/2);
  const foundationLedge=mesh(foundation,'Foundation outside ledge',foundationLedgeGeometry,materials.paint,[0,.2,0]);
  foundationLedge.castShadow=false;foundationLedge.userData.foundationLedge=true;
  for(const [index,room] of house.rooms.entries()){
    const material=materials[room.material];if(!material)throw new Error(`Unknown room material: ${room.material}`);
    const geometry=new T.ShapeGeometry(shapeFor(room.polygon));geometry.rotateX(-Math.PI/2);
    const floor=mesh(layers.architecture,index===0?'floor finish':`${room.name||room.id} floor`,geometry,material,[0,floorLevel,0],room.material);
    floor.castShadow=false;floor.userData.floorRegion={id:room.id,polygon:room.polygon};
    const {position,uv}=geometry.attributes,repeat=materialSpecs.get(material).repeat;
    for(let vertex=0;vertex<position.count;vertex++)uv.setXY(vertex,position.getX(vertex)/repeat[0],position.getZ(vertex)/repeat[1]);
    uv.needsUpdate=true;
  }

  function addWall(record,a,b,isExterior=false){
    const dx=b[0]-a[0],dz=b[1]-a[1],length=Math.hypot(dx,dz),thickness=record.thickness??house.wallThickness;
    const group=new T.Group();group.name=record.id;group.position.set(a[0],0,a[1]);group.rotation.y=-Math.atan2(dz,dx);layers.architecture.add(group);
    const openings=(record.openings||[]).map(opening=>({...opening,sill:opening.sill??0})).sort((left,right)=>left.from-right.from);
    const wall={id:record.id,group,a:[...a],b:[...b],thickness,height:house.ceilingHeight,openings,endExtensions:[thickness/2,thickness/2]};wallSchedule.push(wall);
    if(isExterior)exterior.push({group,normal:new T.Vector3(dz/length,0,-dx/length)});
    const wallPart=(from,to,bottom,height)=>{
      if(to-from<1e-8||height<1e-8)return;
      const start=from===0?from-thickness/2:from,end=Math.abs(to-length)<1e-8?to+thickness/2:to;
      const surface=box(group,'wall surface',[end-start,height,thickness],[(start+end)/2,floorLevel+bottom+height/2,0],materials.paint,'paint');
      surface.userData.wallInterval={from,to};surface.userData.wallId=record.id;
    };
    let cursor=0;
    for(const opening of openings){
      wallPart(cursor,opening.from,0,house.ceilingHeight);
      wallPart(opening.from,opening.to,0,opening.sill);
      wallPart(opening.from,opening.to,opening.sill+opening.height,house.ceilingHeight-opening.sill-opening.height);
      const width=opening.to-opening.from,center=(opening.from+opening.to)/2,rail=.035;
      if(opening.type==='window'||opening.glazed){
        const glazing=new T.Group();glazing.name=`Glazing · ${record.id} · ${glazingGroups.length+1}`;glazing.userData.hostWall=record.id;
        glazing.userData.opening={...opening};group.add(glazing);glazingGroups.push(glazing);
        const frameMaterial=dark,bottom=floorLevel+opening.sill,top=bottom+opening.height,panels=opening.panels??1;
        box(glazing,'Glazing upper rail',[width,rail,.065],[center,top-rail/2,0],frameMaterial);
        box(glazing,'Glazing lower rail',[width,rail,.065],[center,bottom+rail/2,0],frameMaterial);
        for(let panel=0;panel<=panels;panel++)box(glazing,'Glazing stile',[rail,opening.height,.065],[opening.from+panel*width/panels,bottom+opening.height/2,0],frameMaterial);
        for(let panel=0;panel<panels;panel++){
          const pane=box(glazing,'Glass pane',[width/panels-rail,opening.height-2*rail,.012],[opening.from+(panel+.5)*width/panels,bottom+opening.height/2,0],glass);
          pane.castShadow=false;pane.userData.glazing=true;
        }
      }else if(opening.type==='door'){
        const bottom=floorLevel+opening.sill;
        for(const x of [opening.from+rail/2,opening.to-rail/2])box(group,'Door jamb',[rail,opening.height,.09],[x,bottom+opening.height/2,0],materials.wood,'wood');
        box(group,'Door head',[width,rail,.09],[center,bottom+opening.height-rail/2,0],materials.wood,'wood');
        const hinge=new T.Group();hinge.name='Door hinge';hinge.position.set(opening.from+rail,bottom,thickness/2+.025);hinge.rotation.y=opening.openAngle??.55;group.add(hinge);
        const leaf=box(hinge,'Door leaf',[width-2*rail,opening.height-rail,.035],[(width-2*rail)/2,(opening.height-rail)/2,0],materials.paint,'paint');leaf.userData.door=true;
        box(hinge,'Door handle',[.085,.013,.025],[width-2*rail-.1,.99,.03],dark);
      }
      cursor=opening.to;
    }
    wallPart(cursor,length,0,house.ceilingHeight);return group;
  }
  house.exteriorWalls.forEach((record,index)=>addWall(record,house.footprint[index],house.footprint[(index+1)%house.footprint.length],true));
  for(const record of house.partitions||[])addWall(record,record.a,record.b);
  const wallById=new Map(wallSchedule.map(wall=>[wall.id,wall]));

  function cabinet(record,{vanity=false,bedside=false}={}){
    const root=groupFor(record),[width,depth,height]=record.size,topThickness=vanity ? .035 : bedside ? .025 : .045;
    const carcassHeight=height-topThickness;
    box(root,'Cabinet body',[width,carcassHeight,depth],[0,carcassHeight/2,0],materials.wood,'wood');
    const doors=Math.max(1,Math.round(width/.56));
    for(let index=0;index<doors;index++){
      const doorWidth=width/doors-.014,x=-width/2+(index+.5)*width/doors;
      box(root,'Cabinet door',[doorWidth,carcassHeight-.05,.025],[x,carcassHeight/2+.013,depth/2+.012],materials.wood,'wood');
      box(root,'Cabinet pull',[.08,.011,.015],[x,carcassHeight-.07,depth/2+.03],dark);
    }
    box(root,'Counter slab',[width+.04,topThickness,depth+.04],[0,height-topThickness/2,0],vanity?materials.stone:bedside?materials.wood:materials.stone,bedside?'wood':'stone');
    if(vanity){
      mesh(root,'Vanity basin',new T.CylinderGeometry(.17,.15,.04,40),porcelain,[0,height+.014,0]);
      box(root,'Basin inset',[.20,.003,.16],[0,height+.036,.015],dark);
      mesh(root,'Tap riser',new T.CylinderGeometry(.012,.012,.16,16),dark,[0,height+.08,-.17]);
      box(root,'Tap spout',[.025,.023,.11],[0,height+.155,-.12],dark);
    }else if(!bedside){
      mesh(root,'Kitchen sink rim',new T.CylinderGeometry(.23,.23,.017,40),porcelain,[-width*.24,height+.008,0]);
      box(root,'Kitchen sink bowl',[.31,.008,.26],[-width*.24,height+.012,0],dark);
      box(root,'Cooktop',[.43,.016,.39],[width*.24,height+.008,0],dark);
      for(const x of [-.115,.115])for(const z of [-.105,.105]){
        const ring=mesh(root,'Cooktop ring',new T.TorusGeometry(.062,.006,6,24),porcelain,[width*.24+x,height+.02,z]);ring.rotation.x=Math.PI/2;
      }
    }
    return root;
  }
  function island(record){
    const root=groupFor(record),[width,depth,height]=record.size;
    box(root,'Island inset base',[width-.10,height-.055,depth-.13],[0,(height-.055)/2,0],materials.wood,'wood');
    box(root,'Island stone top',[width,.045,depth],[0,height-.0225,0],materials.stone,'stone');
    for(const side of [-1,1])box(root,'Island stone return',[.035,height-.04,depth],[side*(width/2-.0175),(height-.04)/2,0],materials.stone,'stone');
    return root;
  }
  function shelf(record){
    const root=groupFor(record),[width,depth,height]=record.size,thickness=.035,rows=record.rows??4,columns=record.columns??2;
    box(root,'Shelf backing',[width,height,thickness],[0,height/2,-depth/2+thickness/2],materials.wood,'wood');
    for(const side of [-1,1])box(root,'Shelf side',[thickness,height,depth],[side*(width/2-thickness/2),height/2,0],materials.wood,'wood');
    for(let row=0;row<=rows;row++)box(root,'Horizontal shelf',[width-2*thickness,thickness,depth],[0,thickness/2+row*(height-thickness)/rows,0],materials.wood,'wood');
    for(let column=1;column<columns;column++)box(root,'Shelf divider',[thickness,height-2*thickness,depth],[-width/2+column*width/columns,height/2,0],materials.wood,'wood');
    const cells=[];
    for(let row=0;row<rows;row++)for(let column=0;column<columns;column++){
      const minX=column===0?-width/2+thickness:-width/2+column*width/columns+thickness/2,maxX=column===columns-1?width/2-thickness:-width/2+(column+1)*width/columns-thickness/2;
      cells.push({min:[minX,thickness+row*(height-thickness)/rows,-depth/2+thickness],max:[maxX,(row+1)*(height-thickness)/rows,depth/2],front:'+Z'});
    }
    root.userData.shelfLighting={cells};root.userData.materialCatalogKey='wood';
    return root;
  }
  function mediaCabinet(record){
    const root=groupFor(record),[width,depth]=record.size,counterHeight=.65;
    for(const side of [-1,1]){
      box(root,'Media side cabinet',[(width-1.30)/2,.60,depth],[side*(.65+(width-1.30)/4),.3,0],materials.wood,'wood');
      box(root,'Media door',[(width-1.30)/2-.022,.55,.018],[side*(.65+(width-1.30)/4),.31,depth/2+.013],materials.wood,'wood');
    }
    box(root,'Media countertop',[width,.05,depth],[0,counterHeight-.025,0],materials.stone,'stone');
    const fireplace=new T.Group();fireplace.name='Demo fireplace';root.add(fireplace);
    box(fireplace,'Hearth',[1.34,.045,depth],[0,.0225,0],materials.stone,'stone');
    for(const side of [-1,1])box(fireplace,'Fireplace side',[.09,.55,depth],[side*.62,.32,0],materials.stone,'stone');
    box(fireplace,'Fireplace lintel',[1.34,.085,depth],[0,.56,0],materials.stone,'stone');
    const firebox=box(fireplace,'recessed black firebox',[1.12,.43,.24],[0,.3,.05],dark);firebox.userData.interaction='fireplace';
    const fire=new T.Group();fire.name='illustrated fireplace fire';fire.userData.enabled=true;fireplace.add(fire);fireplace.userData.fireOn=true;
    const flameMaterial=new T.MeshBasicMaterial({map:fireplaceFireTexture,color:fireplaceFireTexture?'#ffffff':'#f59649',transparent:true,opacity:.95,depthWrite:false,toneMapped:false,side:T.DoubleSide});
    const flames=mesh(fire,'illustrated fireplace flames',new T.PlaneGeometry(.98,.35),flameMaterial,[0,.282,.177]);
    flames.castShadow=flames.receiveShadow=false;flames.userData={interaction:'fireplace',keepBrightAtNight:true,animated:true};
    if(!fireplaceFireTexture){
      for(const [index,x] of [-.24,-.08,.09,.25].entries()){
        const flame=mesh(fire,'Procedural demo flame',new T.ConeGeometry(.06,.23+index*.025,8),new T.MeshBasicMaterial({color:index%2?'#f7c875':'#e77e36',toneMapped:false}),[x,.23,.19]);flame.castShadow=flame.receiveShadow=false;flame.userData.keepBrightAtNight=true;
      }
      flames.visible=false;
    }
    const fireplaceAnimator={name:'illustrated fireplace fire',fps:24,isActive:()=>fire.visible&&!fireplace.userData.arrangeDeleted,needsAnimation:()=>fire.visible,update(time){
      const seconds=Number.isFinite(time)?time:0;flames.scale.y=.965+.035*Math.sin(seconds*4.1);flameMaterial.opacity=.91+.05*Math.sin(seconds*7.3);
      for(const [index,child] of fire.children.entries())if(child!==flames)child.scale.y=.90+.10*Math.sin(seconds*5+index*1.6);
    }};
    animators.push(fireplaceAnimator);animatedRoots.push(root);
    root.updateWorldMatrix(true,true);
    const candidateWalls=record.hostWall?[wallById.get(record.hostWall)]:wallSchedule;
    if(candidateWalls.some(wall=>!wall))throw new Error(`Unknown TV host wall: ${record.hostWall}`);
    for(const wall of candidateWalls)wall.group.updateWorldMatrix(true,true);
    const mountingRay=new T.Raycaster(root.localToWorld(new T.Vector3(0,1.51,depth/2+.15)),new T.Vector3(0,0,-1).transformDirection(root.matrixWorld));
    const mountingHit=mountingRay.intersectObjects(candidateWalls.flatMap(wall=>wall.group.children.filter(object=>object.name==='wall surface')),false)[0];
    if(!mountingHit)throw new Error(`A solid wall is required behind the TV: ${record.id}`);
    const hostWall=wallById.get(mountingHit.object.userData.wallId),normal=mountingHit.face.normal.clone().transformDirection(mountingHit.object.matrixWorld);
    const tvThickness=.045,mountDepth=.008,tvMount=new T.Group();tvMount.name='Wall-mounted TV';tvMount.userData={hostWall:hostWall.id,wallMounted:true};root.add(tvMount);
    tvMount.position.copy(root.worldToLocal(mountingHit.point.clone().addScaledVector(normal,tvThickness/2+mountDepth)));
    const wallFacing=new T.Quaternion().setFromAxisAngle(new T.Vector3(0,1,0),Math.atan2(normal.x,normal.z));
    tvMount.quaternion.copy(root.getWorldQuaternion(new T.Quaternion()).invert().multiply(wallFacing));
    const mountingPlate=box(tvMount,'TV wall mounting plate',[.95,.48,mountDepth],[0,0,-tvThickness/2-mountDepth/2],dark);
    mountingPlate.userData.wallMounted=true;
    const screen=box(tvMount,'media screen',[1.60,.90,tvThickness],[0,0,0],dark);
    const displayMaterial=new T.MeshBasicMaterial({color:tvVideoTexture?'#ffffff':'#547c7b',map:tvVideoTexture,toneMapped:false});
    const display=mesh(tvMount,'media video display',new T.PlaneGeometry(1.51,.81),displayMaterial,[0,0,tvThickness/2+.0015]);display.castShadow=display.receiveShadow=false;
    display.userData={tvDisplay:true,keepBrightAtNight:true};
    bindings.tv={screen,display,mount:tvMount,hostWall:hostWall.group};bindings.fireplace={root:fireplace,firebox,flames};
    return root;
  }
  function bed(record){
    const root=groupFor(record),[width,depth,height]=record.size;
    box(root,'Bed platform',[width,.29,depth],[0,.145,0],materials.wood,'wood');
    box(root,'Bed mattress',[width-.08,height-.29,depth-.08],[0,.29+(height-.29)/2,.02],fabric);
    box(root,'Bed headboard',[width+.08,.73,.06],[0,.365,-depth/2+.025],materials.wood,'wood');
    for(const side of [-1,1]){
      const pillow=mesh(root,'Linen pillow',new T.SphereGeometry(1,24,12),fabric,[side*width*.24,height+.05,-depth*.31]);pillow.scale.set(width*.215,.085,.23);
    }
    return root;
  }
  function toilet(record){
    const root=groupFor(record),[width,depth,height]=record.size;
    const base=mesh(root,'Toilet pedestal',new T.CylinderGeometry(width*.37,width*.28,.29,32),porcelain,[0,.145,.04]);base.scale.z=1.3;
    const bowl=mesh(root,'Toilet bowl',new T.SphereGeometry(1,32,16),porcelain,[0,.34,.09]);bowl.scale.set(width/2,.15,depth*.36);
    const seat=mesh(root,'Toilet seat',new T.TorusGeometry(width*.38,.027,8,40),porcelain,[0,.44,.09]);seat.rotation.x=Math.PI/2;seat.scale.y=1.45;
    box(root,'Toilet cistern',[width*.9,height-.30,.16],[0,.3+(height-.3)/2,-depth*.32],porcelain);
    return root;
  }
  for(const record of house.builtIns||[]){
    if(!Array.isArray(record.size)||record.size.length!==3||record.size.some(value=>!Number.isFinite(value)||value<=0))throw new Error(`Invalid built-in size: ${record.id}`);
    if(!Array.isArray(record.position)||record.position.length!==3||record.position.some(value=>!Number.isFinite(value))||(record.yaw!==undefined&&!Number.isFinite(record.yaw)))throw new Error(`Invalid built-in position: ${record.id}`);
    if(record.type==='counter')cabinet(record);
    else if(record.type==='island')island(record);
    else if(record.type==='shelf')shelf(record);
    else if(record.type==='media')mediaCabinet(record);
    else if(record.type==='bed')bed(record);
    else if(record.type==='bedside')cabinet(record,{bedside:true});
    else if(record.type==='vanity')cabinet(record,{vanity:true});
    else if(record.type==='toilet')toilet(record);
    else throw new Error(`Unsupported built-in type: ${record.type}`);
  }

  function boundsAtFloor(bounds){
    if(!bounds)return undefined;
    const result={...bounds};for(const key of ['minY','maxY','planeY'])if(Number.isFinite(result[key]))result[key]+=floorLevel;
    return result;
  }
  function createLiveMirror(root,placement){
    const face=root.getObjectByName('mirror face'),frame=root.getObjectByName('mirror frame');
    if(!face||!frame)throw new Error('A mirror product requires a face and frame');
    root.updateMatrixWorld(true);face.updateWorldMatrix(true,false);
    const relative=new T.Matrix4().copy(root.matrixWorld).invert().multiply(face.matrixWorld),geometry=face.geometry.clone();
    const mirror=createRoomReflector(geometry,{textureWidth:512,textureHeight:512,clipOffset:.0001,color:'#c5c8be',multisample:0,wallGroups:wallSchedule.map(wall=>wall.group)});mirror.name='live mirror surface';
    relative.decompose(mirror.position,mirror.quaternion,mirror.scale);mirror.position.z+=.0004;
    mirror.userData={...mirror.userData,dynamicReflection:true,productId:placement.product,keepBrightAtNight:true};root.add(mirror);face.visible=false;
    const back=mesh(root,'Mirror reverse face',geometry.clone(),new T.MeshBasicMaterial({color:'#b5b5aa',side:T.BackSide,toneMapped:false}),mirror.position.toArray());
    back.quaternion.copy(mirror.quaternion);back.scale.copy(mirror.scale);back.position.z-=.014;back.castShadow=back.receiveShadow=false;
    root.userData.dynamicReflection=true;root.userData.movableItem.duplicateMode='static-mirror';
    reflectors.push({group:root,mirror,frame,back,hostWall:wallById.get(placement.hostWall)?.group});
  }
  for(const placement of house.placements||[]){
    const spec=(project?.products||productCatalog).find(product=>product.id===placement.product);
    if(!spec)throw new Error(`Unknown placed product: ${placement.product}`);
    const bottom=placement.position[1],suspension=spec.pendant?house.ceilingHeight-bottom-spec.size[2]-.018:.65;
    const root=createProduct(placement.product,{suspension,showSuspension:!!spec.pendant});root.name=placement.label;
    root.position.set(placement.position[0],floorLevel+bottom,placement.position[2]);root.rotation.y=radians(placement.yaw);
    root.userData.movableItem={id:placement.id,label:placement.label,constraint:placement.constraint,duplicable:true,deletable:true,
      ...(placement.hostWall?{hostWall:placement.hostWall}:{}),...(placement.surfaceBounds?{surfaceBounds:boundsAtFloor(placement.surfaceBounds)}:{}),...(placement.wallBounds?{wallBounds:boundsAtFloor(placement.wallBounds)}:{})};
    const parent=spec.lighting?layers.lighting:layers.furniture;parent.add(root);
    if(spec.pendant){root.updateWorldMatrix(true,true);root.position.y+=ceilingLevel-new T.Box3().setFromObject(root).max.y;}
    if(placement.fixtureLight){
      const emitter=[];root.traverse(object=>{if(object.userData.lightEmitter)emitter.push(object);});root.updateWorldMatrix(true,true);
      const anchor=emitter.length?root.worldToLocal(emitter[0].getWorldPosition(new T.Vector3())).toArray():placement.fixtureLight.anchor;
      root.userData.fixtureLight={...placement.fixtureLight,anchor};
    }
    if(placement.role==='audio')bindings.audio={root};
    if(placement.role==='mirror')createLiveMirror(root,placement);
  }

  if(house.gallery){
    const config=house.gallery,{rows,columns,frameSize,rail,photoPadding,frameDepth,gap}=config;
    if(![rows,columns].every(value=>Number.isInteger(value)&&value>0)||![frameSize,rail,photoPadding,frameDepth,gap].every(value=>Number.isFinite(value)&&value>0)||frameSize<=2*(rail+photoPadding))throw new Error('Invalid gallery frame configuration');
    const root=new T.Group();root.name='Wall gallery';root.position.set(config.position[0],floorLevel+config.position[1],config.position[2]);root.rotation.y=radians(config.yaw);
    const width=columns*frameSize+(columns-1)*gap,height=rows*frameSize+(rows-1)*gap;
    root.userData.frameGrid={rows,columns,frameSize,gap,depth:frameDepth,width,height};
    root.userData.movableItem={id:'demo-gallery-1',label:'Wall gallery',constraint:'wall',hostWall:config.hostWall,wallBounds:boundsAtFloor(config.wallBounds),duplicable:true,deletable:true};
    const frames=[];
    for(let row=0;row<rows;row++)for(let column=0;column<columns;column++){
      const frame=new T.Group();frame.name=`Gallery frame ${row*columns+column+1}`;frame.position.set((column-(columns-1)/2)*(frameSize+gap),((rows-1)/2-row)*(frameSize+gap),0);
      frame.userData.galleryFrame={row,column,index:row*columns+column};root.add(frame);frames.push(frame);
      for(const side of [-1,1]){
        box(frame,'Gallery vertical rail',[rail,frameSize,frameDepth],[side*(frameSize-rail)/2,0,0],materials.wood,'wood');
        box(frame,'Gallery horizontal rail',[frameSize-2*rail,rail,frameDepth],[0,side*(frameSize-rail)/2,0],materials.wood,'wood');
      }
      box(frame,'Gallery backing',[frameSize-2*rail,frameSize-2*rail,.008],[0,0,-frameDepth/2+.004],materials.paint,'paint');
    }
    layers.furniture.add(root);bindings.gallery={root,frames,frameSize,rail,photoPadding,frameDepth};
  }

  const trees=[],bases=[];
  for(const record of house.landscape||[]){
    const root=new T.Group();root.name=record.id;root.position.set(record.position[0],floorLevel+record.position[1],record.position[2]);layers.trees.add(root);
    const trunkMaterial=new T.MeshStandardMaterial({color:'#8a7761',roughness:.88}),canopyMaterials=['#728b75','#879a80','#617f6b'].map(color=>new T.MeshStandardMaterial({color,roughness:.96}));
    const trunkHeight=record.height*.54;
    mesh(root,'Demo tree trunk',new T.CylinderGeometry(.075,.13,trunkHeight,12),trunkMaterial,[0,trunkHeight/2,0]);
    const axonCanopy=new T.Group();axonCanopy.name='Tree canopy Axon';root.add(axonCanopy);
    for(const [index,position] of [[-.38,record.height*.73,-.1],[.36,record.height*.72,.10],[0,record.height*.82,0]].entries()){
      const crown=mesh(axonCanopy,'Demo tree crown',new T.IcosahedronGeometry(1,2),canopyMaterials[index],position);
      crown.scale.set(record.canopyRadius*(index===2?.75:.85),record.height*(index===2?.18:.24),record.canopyRadius*(index===2?.78:.85));crown.castShadow=false;
    }
    const planCanopy=mesh(root,'Tree canopy Plan',new T.CircleGeometry(record.canopyRadius*1.08,48),new T.MeshBasicMaterial({color:'#7a947a',side:T.DoubleSide}),[0,record.height,0]);planCanopy.rotation.x=-Math.PI/2;planCanopy.castShadow=planCanopy.receiveShadow=false;planCanopy.visible=false;
    const base=mesh(layers.trees,'Tree ground pad',new T.CylinderGeometry(record.baseRadius,record.baseRadius,.06,48),new T.MeshBasicMaterial({color:'#ddd9cf'}),[root.position.x,root.position.y-.03,root.position.z]);base.castShadow=base.receiveShadow=false;bases.push(base);trees.push({root,axonCanopy,planCanopy});
  }
  bindings.landscape={billboards:trees.map(tree=>tree.root),bases,updateView(mode){for(const tree of trees){tree.axonCanopy.visible=mode!=='plan';tree.planCanopy.visible=mode==='plan';}}};
  for(const layer of Object.values(layers))layer.updateWorldMatrix(true,true);
  return {layers,materials,movementBoundary:house.footprint.map(([x,z])=>({x,z})),wallSchedule,exterior,glazingGroups,animators,animatedRoots,reflectors,bindings,
    measurementBasis:'wall centerlines',floorLevel,ceilingLevel};
}
