const NIGHT_BACKGROUND='#242526';
const NIGHT_LIGHT_COLOR='#ffd39a';
const NIGHT_TV_BRIGHTNESS=2;
const DAY_MATERIAL_KEY='houseNightDayMaterial';

const triplet=value=>Array.isArray(value)&&value.length===3&&value.every(Number.isFinite);
const visibleRoot=(root,layer)=>{
  for(let object=root;object&&object!==layer;object=object.parent)if(object.visible===false||object.userData.arrangeDeleted)return false;
  return true;
};

function createGlowTexture(THREE){
  const size=64,data=new Uint8Array(size*size*4),center=(size-1)/2;
  for(let y=0;y<size;y++)for(let x=0;x<size;x++){
    const radius=Math.hypot(x-center,y-center)/center,alpha=Math.max(0,1-radius);
    const offset=(y*size+x)*4;
    data[offset]=data[offset+1]=data[offset+2]=255;data[offset+3]=Math.round(255*alpha*alpha);
  }
  const texture=new THREE.DataTexture(data,size,size,THREE.RGBAFormat);
  texture.colorSpace=THREE.SRGBColorSpace;texture.minFilter=texture.magFilter=THREE.LinearFilter;
  texture.generateMipmaps=false;texture.needsUpdate=true;return texture;
}

function fixtureConfig(root){
  const metadata=root.userData.fixtureLight;if(!metadata)return null;
  const anchor=metadata.anchor??[0,.05,0],power=metadata.power??10,distance=metadata.distance??2.5,glowSize=metadata.glowSize??.075;
  if(!triplet(anchor))throw new TypeError('fixtureLight.anchor must contain three finite local coordinates');
  if(!Number.isFinite(power)||power<0)throw new RangeError('fixtureLight.power must be nonnegative lumens');
  if(!Number.isFinite(distance)||distance<=0)throw new RangeError('fixtureLight.distance must be positive');
  if(!Number.isFinite(glowSize)||glowSize<=0)throw new RangeError('fixtureLight.glowSize must be positive');
  return {anchor,power,distance,glowSize,color:metadata.color??NIGHT_LIGHT_COLOR,zone:String(metadata.zone??root.userData.productId??'default')};
}

// The small fixed pool keeps one Night shader signature even after a fixture
// is moved, deleted, or duplicated. Every bulb retains its own local glow.
export function addNightLightsToFixtures(THREE,fixtureLayer,{maxLights=4}={}){
  if(!fixtureLayer)throw new TypeError('A fixture layer is required');
  if(!Number.isInteger(maxLights)||maxLights<1||maxLights>8)throw new RangeError('maxLights must be an integer from 1 to 8');
  const glowTexture=createGlowTexture(THREE),glowMaterials=new Map(),glows=new Set();
  const zoneLights=Array.from({length:maxLights},(_,index)=>{
    const light=new THREE.PointLight(NIGHT_LIGHT_COLOR,0,1,2);
    light.name=`Night fixture zone ${index+1}`;light.castShadow=false;light.visible=false;
    light.userData={nightViewEffect:true,nightViewZoneLight:true,fixtureCount:0,fixtureIds:[],zones:[]};
    fixtureLayer.add(light);return light;
  });
  let count=0,disposed=false,lastSignature='';
  const materialFor=color=>{
    const parsed=new THREE.Color(color),key=parsed.getHexString();
    if(!glowMaterials.has(key))glowMaterials.set(key,new THREE.SpriteMaterial({color:parsed,map:glowTexture,transparent:true,opacity:.7,depthWrite:false,toneMapped:false}));
    return glowMaterials.get(key);
  };
  function syncPositions(active=false){
    if(disposed)return false;
    fixtureLayer.updateWorldMatrix(true,true);
    const roots=[];fixtureLayer.traverse(root=>{if(root.userData.fixtureLight&&!root.userData.nightViewEffect)roots.push(root);});
    const fixtures=[];
    for(const root of roots){
      const config=fixtureConfig(root);let glow=root.children.find(child=>child.userData.nightFixtureGlow);
      if(!glow){glow=new THREE.Sprite(materialFor(config.color));glow.name='Night fixture glow';glow.userData={nightViewEffect:true,nightFixtureGlow:true};glow.raycast=()=>{};root.add(glow);}
      glow.material=materialFor(config.color);glow.position.fromArray(config.anchor);glow.scale.setScalar(config.glowSize*2);
      glow.visible=Boolean(active&&visibleRoot(root,fixtureLayer)&&config.power>0);glows.add(glow);
      if(!visibleRoot(root,fixtureLayer)||config.power===0)continue;
      const position=root.localToWorld(new THREE.Vector3().fromArray(config.anchor));
      fixtures.push({root,...config,position,colorValue:new THREE.Color(config.color)});
    }
    count=fixtures.length;
    const zones=new Map();
    for(const fixture of fixtures){
      if(!zones.has(fixture.zone))zones.set(fixture.zone,{key:fixture.zone,fixtures:[],power:0,position:new THREE.Vector3(),color:new THREE.Color(0,0,0)});
      const zone=zones.get(fixture.zone);zone.fixtures.push(fixture);zone.power+=fixture.power;
      zone.position.addScaledVector(fixture.position,fixture.power);zone.color.add(fixture.colorValue.clone().multiplyScalar(fixture.power));
    }
    const groups=[...zones.values()].sort((a,b)=>a.key.localeCompare(b.key));
    for(const group of groups){group.position.multiplyScalar(1/group.power);group.color.multiplyScalar(1/group.power);}
    const slots=groups.slice(0,maxLights).map(group=>({fixtures:[...group.fixtures],zones:[group.key],position:group.position.clone()}));
    for(const group of groups.slice(maxLights)){
      let nearest=slots[0];for(const slot of slots)if(slot.position.distanceToSquared(group.position)<nearest.position.distanceToSquared(group.position))nearest=slot;
      nearest.fixtures.push(...group.fixtures);nearest.zones.push(group.key);
    }
    for(let index=0;index<zoneLights.length;index++){
      const light=zoneLights[index],slot=slots[index];light.visible=Boolean(active);
      if(!slot){light.power=0;light.distance=1;light.userData.fixtureCount=0;light.userData.fixtureIds=[];light.userData.zones=[];continue;}
      const power=slot.fixtures.reduce((sum,fixture)=>sum+fixture.power,0),position=new THREE.Vector3(),color=new THREE.Color(0,0,0);
      for(const fixture of slot.fixtures){position.addScaledVector(fixture.position,fixture.power);color.add(fixture.colorValue.clone().multiplyScalar(fixture.power));}
      position.multiplyScalar(1/power);color.multiplyScalar(1/power);
      light.position.copy(fixtureLayer.worldToLocal(position.clone()));light.power=power;light.color.copy(color);
      light.distance=slot.fixtures.reduce((distance,fixture)=>Math.max(distance,position.distanceTo(fixture.position)+fixture.distance),0);
      light.userData.fixtureCount=slot.fixtures.length;light.userData.fixtureIds=slot.fixtures.map(fixture=>fixture.root.userData.movableItem?.id??fixture.root.uuid);
      light.userData.zones=slot.zones;light.userData.lumens=power;
    }
    const signature=fixtures.map(fixture=>`${fixture.root.uuid}:${fixture.position.toArray()}:${fixture.power}:${fixture.color}:${fixture.distance}`).join('|');
    const changed=signature!==lastSignature;lastSignature=signature;return changed;
  }
  syncPositions(false);
  return {
    get count(){return count;},get lightCount(){return zoneLights.length;},zoneLights,individualLights:[],glowTexture,
    get glowMaterial(){return glowMaterials.values().next().value;},glowMaterials,glows,syncPositions,
    dispose(){if(disposed)return;disposed=true;for(const light of zoneLights)light.removeFromParent();for(const glow of glows)glow.removeFromParent();for(const material of glowMaterials.values())material.dispose();glowTexture.dispose();},
  };
}

function createShelfWashTexture(THREE){
  const size=64,data=new Uint8Array(size*size*4);
  for(let y=0;y<size;y++)for(let x=0;x<size;x++){
    const u=x/(size-1),v=y/(size-1),edge=Math.pow(Math.max(0,Math.sin(Math.PI*u)),.5);
    const wash=.06+.55*Math.pow(v,1.8),emitter=.35*Math.exp(-Math.pow((1-v)/.055,2)),offset=(y*size+x)*4;
    data[offset]=255;data[offset+1]=222;data[offset+2]=178;data[offset+3]=Math.round(255*edge*Math.min(1,wash+emitter));
  }
  const texture=new THREE.DataTexture(data,size,size,THREE.RGBAFormat);texture.name='Night shelf top-down gradient';
  texture.colorSpace=THREE.SRGBColorSpace;texture.minFilter=texture.magFilter=THREE.LinearFilter;texture.generateMipmaps=false;texture.needsUpdate=true;return texture;
}

function shelfFront(value='+Z'){
  if(Array.isArray(value)){
    if(!triplet(value)||Math.abs(value[1])>1e-8||Math.hypot(value[0],value[2])<1e-8)throw new TypeError('Shelf front must be a horizontal direction');
    return Math.abs(value[0])>Math.abs(value[2])?(value[0]>0?'+X':'-X'):(value[2]>0?'+Z':'-Z');
  }
  const front=String(value).toUpperCase();if(!['+X','-X','+Z','-Z'].includes(front))throw new TypeError('Shelf front must be +X, -X, +Z, or -Z');return front;
}

// Three bounded quads per open cell paint its back, shelf, and emitter. These
// receivers add no scene lights and cannot illuminate a neighboring wall.
export function createNightShelfLighting(THREE,cabinetryLayer){
  if(!cabinetryLayer)return null;
  const roots=()=>{const result=[];cabinetryLayer.traverse(root=>{if(root.userData.shelfLighting&&!root.userData.nightViewEffect)result.push(root);});return result;};
  if(!roots().length)return null;
  const texture=createShelfWashTexture(THREE),material=new THREE.MeshBasicMaterial({map:texture,transparent:true,opacity:.35,blending:THREE.AdditiveBlending,depthWrite:false,toneMapped:false,side:THREE.DoubleSide});
  material.name='Night cabinet wash material';
  const mesh=new THREE.Mesh(new THREE.BufferGeometry(),material);mesh.name='Night cabinet top-down wash';mesh.visible=false;mesh.renderOrder=3;
  mesh.castShadow=false;mesh.receiveShadow=false;mesh.raycast=()=>{};mesh.userData={nightViewEffect:true,nightShelfLightEffect:true};cabinetryLayer.add(mesh);
  let count=0,signature='',disposed=false;
  function syncPositions({force=false}={}){
    if(disposed)return false;cabinetryLayer.updateWorldMatrix(true,true);
    const available=roots().filter(root=>visibleRoot(root,cabinetryLayer));
    const next=available.map(root=>`${root.uuid}:${root.matrixWorld.elements}:${JSON.stringify(root.userData.shelfLighting)}`).join('|');
    if(!force&&next===signature)return false;signature=next;
    const positions=[],uvs=[],indices=[],normalMatrix=new THREE.Matrix4().copy(cabinetryLayer.matrixWorld).invert();let cells=0;
    const append=(root,corners,coordinates)=>{
      const base=positions.length/3;
      for(const corner of corners){const point=new THREE.Vector3().fromArray(corner).applyMatrix4(root.matrixWorld).applyMatrix4(normalMatrix);positions.push(...point.toArray());}
      for(const coordinate of coordinates)uvs.push(...coordinate);indices.push(base,base+1,base+2,base,base+2,base+3);
    };
    for(const root of available){
      const metadata=root.userData.shelfLighting;if(!Array.isArray(metadata.cells))throw new TypeError('shelfLighting.cells must be an array');
      for(const cell of metadata.cells){
        if(!triplet(cell.min)||!triplet(cell.max)||cell.min.some((value,index)=>value>=cell.max[index]))throw new RangeError('Shelf cell min/max must define positive finite local bounds');
        const front=shelfFront(cell.front??cell.frontDirection??metadata.front??metadata.frontDirection),widthAxis=front.endsWith('Z')?0:2,depthAxis=front.endsWith('Z')?2:0,positive=front.startsWith('+');
        const width=cell.max[widthAxis]-cell.min[widthAxis],height=cell.max[1]-cell.min[1],depth=cell.max[depthAxis]-cell.min[depthAxis],epsilon=Math.min(.0015,width*.02,height*.02,depth*.02);
        const minU=cell.min[widthAxis]+epsilon,maxU=cell.max[widthAxis]-epsilon,bottom=cell.min[1]+epsilon,top=cell.max[1]-epsilon;
        const back=positive?cell.min[depthAxis]+epsilon:cell.max[depthAxis]-epsilon,opening=positive?cell.max[depthAxis]-epsilon:cell.min[depthAxis]+epsilon,inner=opening+(positive?-1:1)*Math.min(.035,depth*.15);
        const point=(u,y,d)=>{const result=[0,y,0];result[widthAxis]=u;result[depthAxis]=d;return result;};
        const gradient=[[0,0],[1,0],[1,1],[0,1]],strip=[[0,1],[0,1],[1,1],[1,1]];
        append(root,[point(minU,bottom,back),point(maxU,bottom,back),point(maxU,top,back),point(minU,top,back)],gradient);
        append(root,[point(minU,bottom,opening),point(maxU,bottom,opening),point(maxU,bottom,back),point(minU,bottom,back)],gradient);
        append(root,[point(minU,top,opening),point(minU,top,inner),point(maxU,top,inner),point(maxU,top,opening)],strip);cells++;
      }
    }
    const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geometry.setIndex(indices);
    geometry.computeVertexNormals();geometry.computeBoundingBox();geometry.computeBoundingSphere();mesh.geometry.dispose();mesh.geometry=geometry;count=cells;mesh.userData.cellCount=count;return true;
  }
  syncPositions();
  return {mesh,meshes:[mesh],material,texture,get geometry(){return mesh.geometry;},get count(){return count;},syncPositions,setVisible:active=>{mesh.visible=Boolean(active);},dispose(){if(disposed)return;disposed=true;mesh.removeFromParent();mesh.geometry.dispose();material.dispose();texture.dispose();}};
}

export function createNightViewController(THREE,{
  scene,renderer,camera,fixtureLayer,hemisphere,sun,ambient,toggle,rootElement,
  materials={},treeBases=[],reflectors=[],shelfLighting=null,frameLighting=null,themeColorMeta,
  requestRender=()=>{},invalidateReflections=()=>{},deferReflections=()=>false,
  completeDeferredReflections=()=>{invalidateReflections();return true;},onChange=()=>{},maxFixtureLights=4,
  scheduleFrame=callback=>globalThis.requestAnimationFrame?.(callback)??(callback(),0),cancelFrame=handle=>globalThis.cancelAnimationFrame?.(handle),
}){
  const resources=addNightLightsToFixtures(THREE,fixtureLayer,{maxLights:maxFixtureLights});
  const background=scene.background,day={background:background?.isColor?background.clone():background,exposure:renderer.toneMappingExposure,shadowsEnabled:renderer.shadowMap?.enabled,
    hemisphereColor:hemisphere.color.clone(),hemisphereGroundColor:hemisphere.groundColor.clone(),hemisphereIntensity:hemisphere.intensity,
    sunColor:sun.color.clone(),sunIntensity:sun.intensity,sunCastShadow:sun.castShadow,ambientColor:ambient.color.clone(),ambientIntensity:ambient.intensity,
    themeColor:themeColorMeta?.getAttribute('content')??'#ffffff'};
  const treeDay=new Map(),treeNight=new THREE.MeshBasicMaterial({color:'#282828',toneMapped:false});treeNight.name='Night tree base';
  const materialStates=new Map(),prepared=new Set(),preparing=new Set();
  let night=false,disposed=false,preparationGeneration=0,reflectionGeneration=0,reflectionFrame=0;
  const nightCompileScene=new THREE.Scene();
  nightCompileScene.add(new THREE.HemisphereLight('#b8babd','#4a4b4e',.55),new THREE.DirectionalLight('#fff7ed',0),new THREE.AmbientLight('#c4c4c1',.28));
  for(let index=0;index<resources.lightCount;index++)nightCompileScene.add(new THREE.PointLight(NIGHT_LIGHT_COLOR,1,2.5,2));
  const effectsVisible=active=>{shelfLighting?.setVisible?.(active);if(!shelfLighting?.setVisible)for(const mesh of shelfLighting?.meshes??[])mesh.visible=active;frameLighting?.setVisible?.(active);};
  const treeFinish=active=>{for(const base of treeBases){if(!base?.material)continue;if(!treeDay.has(base))treeDay.set(base,base.material);base.material=active?treeNight:treeDay.get(base);}};
  function captureMaterial(material){
    const inherited=material.userData?.[DAY_MATERIAL_KEY];
    const dayFinish=inherited??{color:material.color?.toArray(),emissive:material.emissive?.toArray(),emissiveIntensity:material.emissiveIntensity};
    material.userData??={};material.userData[DAY_MATERIAL_KEY]=dayFinish;return dayFinish;
  }
  const applyMaterial=(material,state,active)=>{
    const baseline=state.day;if(baseline.color&&material.color)material.color.fromArray(baseline.color);if(baseline.emissive&&material.emissive)material.emissive.fromArray(baseline.emissive);if(baseline.emissiveIntensity!==undefined)material.emissiveIntensity=baseline.emissiveIntensity;
    if(!active)return;
    if(state.kind==='video'){material.color?.multiplyScalar(NIGHT_TV_BRIGHTNESS);if(material.emissive)material.emissiveIntensity=(baseline.emissiveIntensity??1)*NIGHT_TV_BRIGHTNESS;}
    else if(state.kind==='emitter'){if(material.emissive){material.emissive.set(state.color);material.emissiveIntensity=state.brightness;}else material.color?.set(state.color);}
    else if(state.kind==='unlit')material.color?.multiplyScalar(.22);
  };
  function syncSceneMaterials(){
    let added=0;const priorities={unlit:0,keep:1,video:2,emitter:3};
    scene.traverse(object=>{
      if(!object.isMesh||object.userData.nightViewEffect||object.userData.nightShelfLightEffect||object.userData.nightWallFrameLightEffect)return;
      let fixture=object;while(fixture&&!fixture.userData.fixtureLight)fixture=fixture.parent;
      const emitter=object.userData.lightEmitter,video=object.userData.nightVideo||object.userData.tvDisplay||object.userData.mediaRole==='tv'||object.name==='media video display',keep=object.userData.nightKeepBright||object.userData.keepBrightAtNight||object.name==='illustrated fireplace flames';
      for(const material of Array.isArray(object.material)?object.material:[object.material]){
        if(!material||material===treeNight||material.visible===false||!material.color)continue;
        const kind=emitter?'emitter':video?'video':keep?'keep':material.isMeshBasicMaterial?'unlit':'keep';
        let state=materialStates.get(material);
        if(!state){state={day:captureMaterial(material),kind};materialStates.set(material,state);added++;}
        else if(priorities[kind]<priorities[state.kind])continue;
        state.kind=kind;
        if(kind==='emitter'){state.color=(typeof emitter==='object'?emitter.color:null)??fixture?.userData.fixtureLight?.color??NIGHT_LIGHT_COLOR;state.brightness=(typeof emitter==='object'?emitter.brightness:null)??.9;}
        applyMaterial(material,state,night);
      }
    });
    return added;
  }
  // Include supplied house materials even if a palette entry is temporarily
  // outside the scene; their authored finish is never replaced by an ID rule.
  for(const material of Object.values(materials))if(material?.color&&!materialStates.has(material))materialStates.set(material,{day:captureMaterial(material),kind:'keep'});
  syncSceneMaterials();
  const materialFinish=active=>{for(const [material,state] of materialStates)applyMaterial(material,state,active);};
  const pendingCameras=cameras=>{
    const result=[],seen=new Set();for(const item of Array.isArray(cameras)?cameras:[cameras??camera]){
      if(!item)continue;const key=`${item.isOrthographicCamera?'orthographic':item.isPerspectiveCamera?'perspective':item.type}:${resources.lightCount}`;
      if(!seen.has(key)&&!prepared.has(key)&&!preparing.has(key)){result.push({camera:item,key});seen.add(key);}
    }return result;
  };
  // Compile a lightweight scene clone that shares geometry/materials. Async
  // compilation can then finish without temporarily hiding the user's lights.
  function compileSource(){
    scene.updateMatrixWorld(true);const source=scene.clone(true),originals=[],copies=[];scene.traverse(object=>originals.push(object));source.traverse(object=>copies.push(object));
    for(let index=0;index<copies.length;index++){
      const original=originals[index],copy=copies[index];if(copy.isLight)copy.visible=false;
      if(copy.userData.nightViewEffect)copy.visible=copy.userData.nightFixtureGlow||copy.userData.nightShelfLightEffect||copy.userData.nightWallFrameLightEffect;
      if(treeDay.has(original))copy.material=treeNight;
    }
    nightCompileScene.environment=scene.environment;nightCompileScene.fog=scene.fog;
    if('environmentIntensity' in scene)nightCompileScene.environmentIntensity=scene.environmentIntensity;
    if(scene.environmentRotation)nightCompileScene.environmentRotation.copy(scene.environmentRotation);
    renderer.initTexture?.(resources.glowTexture);if(shelfLighting?.texture)renderer.initTexture?.(shelfLighting.texture);return source;
  }
  function invokeCompile(method,source,item){
    const shadows=renderer.shadowMap?.enabled;try{if(renderer.shadowMap)renderer.shadowMap.enabled=false;return renderer[method](source,item,nightCompileScene);}finally{if(renderer.shadowMap)renderer.shadowMap.enabled=shadows;}
  }
  function preparePrograms(cameras){
    if(disposed||typeof renderer.compile!=='function')return false;const pending=pendingCameras(cameras);if(!pending.length)return false;
    treeFinish(night);const source=compileSource();for(const item of pending){invokeCompile('compile',source,item.camera);prepared.add(item.key);}return true;
  }
  async function prepareProgramsAsync(cameras,{timeout=6000}={}){
    if(disposed)return false;if(typeof renderer.compileAsync!=='function')return preparePrograms(cameras);
    if(!Number.isFinite(timeout)||timeout<=0)throw new RangeError('Compilation timeout must be positive');
    const pending=pendingCameras(cameras);if(!pending.length)return false;const generation=preparationGeneration;
    for(const item of pending)preparing.add(item.key);treeFinish(night);const source=compileSource();
    try{
      for(const item of pending){let timer;try{await Promise.race([Promise.resolve(invokeCompile('compileAsync',source,item.camera)),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Night shader compilation timed out.')),timeout);})]);}finally{clearTimeout(timer);}
        if(disposed||generation!==preparationGeneration)return false;prepared.add(item.key);
      }return true;
    }finally{for(const item of pending)preparing.delete(item.key);}
  }
  const refreshReflections=deferred=>{
    const generation=++reflectionGeneration;if(reflectionFrame)cancelFrame(reflectionFrame);
    reflectionFrame=scheduleFrame(()=>{reflectionFrame=0;if(disposed||generation!==reflectionGeneration)return;if(completeDeferredReflections(deferred))requestRender();})||0;
  };
  function setNightView(active,{deferReflection=true}={}){
    if(disposed)return false;night=Boolean(active);syncSceneMaterials();
    if(night){scene.background=background?.isColor?background:new THREE.Color(NIGHT_BACKGROUND);scene.background.set(NIGHT_BACKGROUND);renderer.toneMappingExposure=.94;if(renderer.shadowMap)renderer.shadowMap.enabled=false;
      hemisphere.color.set('#b8babd');hemisphere.groundColor.set('#4a4b4e');hemisphere.intensity=.55;sun.intensity=0;sun.castShadow=false;ambient.color.set('#c4c4c1');ambient.intensity=.28;
    }else{scene.background=background;if(background?.isColor)background.copy(day.background);renderer.toneMappingExposure=day.exposure;if(renderer.shadowMap)renderer.shadowMap.enabled=day.shadowsEnabled;
      hemisphere.color.copy(day.hemisphereColor);hemisphere.groundColor.copy(day.hemisphereGroundColor);hemisphere.intensity=day.hemisphereIntensity;sun.color.copy(day.sunColor);sun.intensity=day.sunIntensity;sun.castShadow=day.sunCastShadow;ambient.color.copy(day.ambientColor);ambient.intensity=day.ambientIntensity;
    }
    resources.syncPositions(night);shelfLighting?.syncPositions?.();frameLighting?.syncPositions?.();effectsVisible(night);materialFinish(night);treeFinish(night);
    rootElement?.classList.toggle('night-view',night);themeColorMeta?.setAttribute('content',night?NIGHT_BACKGROUND:day.themeColor);
    if(toggle){toggle.dataset.lightingMode=night?'night':'day';toggle.dataset.tooltip=night?'Day view':'Night view';toggle.setAttribute('aria-pressed',String(night));toggle.setAttribute('aria-label',night?'Switch to day view':'Switch to night view');}
    onChange(night);for(const reflector of reflectors)(reflector.mirror??reflector)?.onLightingChange?.(night);
    const deferred=deferReflection&&deferReflections();if(deferred){requestRender();refreshReflections(deferred);}else{if(reflectionFrame)cancelFrame(reflectionFrame);reflectionFrame=0;reflectionGeneration++;invalidateReflections();requestRender();}return night;
  }
  setNightView(false,{deferReflection:false});
  return {
    get isNight(){return night;},setNightView,toggle:()=>setNightView(!night),preparePrograms,prepareProgramsAsync,
    resetPreparedPrograms(){preparationGeneration++;prepared.clear();preparing.clear();},
    syncFixturePositions(){resources.syncPositions(night);shelfLighting?.syncPositions?.();frameLighting?.syncPositions?.();syncSceneMaterials();return false;},syncSceneMaterials,
    get fixtureCount(){return resources.count;},get lightCount(){return resources.lightCount;},get shelfLightCount(){return shelfLighting?.count??0;},get frameLightCount(){return frameLighting?.count??0;},
    dispose(){if(disposed)return;setNightView(false,{deferReflection:false});disposed=true;preparationGeneration++;reflectionGeneration++;if(reflectionFrame)cancelFrame(reflectionFrame);reflectionFrame=0;treeFinish(false);materialFinish(false);for(const material of materialStates.keys())delete material.userData[DAY_MATERIAL_KEY];resources.dispose();treeNight.dispose();shelfLighting?.dispose?.();frameLighting?.dispose?.();},
  };
}
