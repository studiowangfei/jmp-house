// Virtual ceiling spots project onto the artwork and its own wall. A soft
// downward wall falloff makes the illumination external to the frame.
// Source geometry is retained for reversibility, but only the wash renders by
// default. No extra scene lights or partition-crossing illumination are added.
export function createNightWallFrameLighting(THREE,furnitureLayer,architectureLayer,{
  showSources=false,footprintAreaScale=1.25,projectionAngleDegrees=60,
  aimDepthAt60Degrees=.35,lightStrengthScale=1.625,edgeDiffusion=1,
  upperSpillOffsets=[-.26,0],upperSpillAfterCap=true,wallOnlyUpperSpill=true,
}={}){
  if(!furnitureLayer)return null;
  if(!Number.isFinite(footprintAreaScale)||footprintAreaScale<=0)throw new RangeError('footprintAreaScale must be positive');
  if(!Number.isFinite(projectionAngleDegrees)||projectionAngleDegrees<=0||projectionAngleDegrees>=90)throw new RangeError('projectionAngleDegrees must be between 0 and 90');
  if(!Number.isFinite(aimDepthAt60Degrees)||aimDepthAt60Degrees<0||aimDepthAt60Degrees>.45)throw new RangeError('aimDepthAt60Degrees must be between 0 and 0.45');
  if(!Number.isFinite(lightStrengthScale)||lightStrengthScale<=0)throw new RangeError('lightStrengthScale must be positive');
  if(!Number.isFinite(edgeDiffusion)||edgeDiffusion<0||edgeDiffusion>1)throw new RangeError('edgeDiffusion must be between 0 and 1');
  if(!Array.isArray(upperSpillOffsets)||upperSpillOffsets.length!==2||!Number.isFinite(upperSpillOffsets[0])||!Number.isFinite(upperSpillOffsets[1])||upperSpillOffsets[1]<=upperSpillOffsets[0])throw new RangeError('upperSpillOffsets must be two finite increasing offsets');
  if(typeof upperSpillAfterCap!=='boolean')throw new TypeError('upperSpillAfterCap must be a boolean');
  if(typeof wallOnlyUpperSpill!=='boolean')throw new TypeError('wallOnlyUpperSpill must be a boolean');
  const spillOffsets=[...upperSpillOffsets];
  const projectionAngle=THREE.MathUtils.degToRad(projectionAngleDegrees);
  // aimDepthAt60Degrees:.375 restores the previous lower aim without changing
  // the soft wall-only fade that prevents arcs above the frames.
  // Restore the earlier above-frame beam with aimDepthAt60Degrees:.35,
  // upperSpillOffsets:[0,.18] and wallOnlyUpperSpill:false.
  const steeperAim=Math.max(0,(projectionAngleDegrees-45)/15),aimDepthFraction=Math.min(.45,aimDepthAt60Degrees*steeperAim),upperSpillSuppression=Math.min(1,steeperAim);
  // Scale both dimensions by the square root: the cast area grows by 25%,
  // while the configured source aim and light output stay unchanged.
  const footprintScale=Math.sqrt(footprintAreaScale);
  // Frames follow the scene contract: local X/Y artwork, local +Z front.
  const frameRoots=()=>furnitureLayer.children.filter(root=>root.userData.wallFrame||root.userData.frameGrid);
  if(!frameRoots().length||furnitureLayer.getObjectByName('Night wall-frame exhibition wash'))return null;
  const wallSurfaces=new Map(),wallRoots=new Map();
  const isVisible=object=>{if(!object)return false;for(let parent=object;parent;parent=parent.parent)if(parent.visible===false)return false;return true;};
  const wallVisibility=()=>[...wallRoots.values()].map(wall=>isVisible(wall)?'1':'0').join('');
  const registerWall=root=>{
    const wallName=root.userData.movableItem?.hostWall||root.userData.wallFrame?.wallName;
    if(wallSurfaces.has(wallName))return;
    const wall=architectureLayer?.getObjectByName(wallName),bounds=[];
    wall?.updateWorldMatrix(true,true);
    // Retain the real host triangles before static batching detaches meshes.
    wall?.traverse(object=>{if(object.name==='wall surface'&&object.isMesh)bounds.push({geometry:object.geometry,matrix:object.matrixWorld.clone(),bounds:new THREE.Box3().setFromObject(object)});});
    wallSurfaces.set(wallName,bounds);wallRoots.set(wallName,wall);
  };
  for(const root of frameRoots())registerWall(root);
  const material=new THREE.ShaderMaterial({
    name:'Night wall-frame exhibition wash material',
    // Scale strength and its cap together, including capped hotspots.
    // lightStrengthScale:1.3 restores output before this 25% increase.
    uniforms:{washTint:{value:new THREE.Color('#fff0d8')},washStrength:{value:.55*lightStrengthScale},washGainLimit:{value:.5*lightStrengthScale},upperSpillSuppression:{value:upperSpillSuppression},edgeDiffusion:{value:edgeDiffusion},upperSpillAfterCap:{value:upperSpillAfterCap?1:0},wallOnlyUpperSpill:{value:wallOnlyUpperSpill?1:0}},
    transparent:true,depthTest:true,depthWrite:false,toneMapped:false,
    side:THREE.DoubleSide,forceSinglePass:true,blending:THREE.CustomBlending,
    blendEquation:THREE.AddEquation,blendSrc:THREE.DstColorFactor,blendDst:THREE.OneFactor,
    blendSrcAlpha:THREE.ZeroFactor,blendDstAlpha:THREE.OneFactor,
    vertexShader:`
      attribute vec3 exhibitionProjection;
      attribute vec3 exhibitionLightVector;
      attribute vec2 exhibitionHaloUv;
      attribute float exhibitionSurfaceGain;
      attribute float exhibitionSurfaceKind;
      attribute float exhibitionReferenceDistance;
      attribute vec2 exhibitionTopSpill;
      varying vec3 lightProjection;
      varying vec3 lightVector;
      varying vec3 surfaceNormal;
      varying vec2 haloUv;
      varying float surfaceGain;
      varying float surfaceKind;
      varying float referenceDistance;
      varying vec2 topSpill;
      void main(){
        lightProjection=exhibitionProjection;
        lightVector=exhibitionLightVector;
        surfaceNormal=normal;
        haloUv=exhibitionHaloUv;
        surfaceGain=exhibitionSurfaceGain;
        surfaceKind=exhibitionSurfaceKind;
        referenceDistance=exhibitionReferenceDistance;
        topSpill=exhibitionTopSpill;
        gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);
      }`,
    fragmentShader:`
      uniform vec3 washTint;
      uniform float washStrength;
      uniform float washGainLimit;
      uniform float upperSpillSuppression;
      uniform float edgeDiffusion;
      uniform float upperSpillAfterCap;
      uniform float wallOnlyUpperSpill;
      varying vec3 lightProjection;
      varying vec3 lightVector;
      varying vec3 surfaceNormal;
      varying vec2 haloUv;
      varying float surfaceGain;
      varying float surfaceKind;
      varying float referenceDistance;
      varying vec2 topSpill;
      void main(){
        if(lightProjection.z<=0.0)discard;
        float radius=length(lightProjection.xy/lightProjection.z);
        float beam=1.0-smoothstep(0.2,1.2,radius);
        // Round the footprint's corners and feather its boundary more widely.
        // edgeDiffusion:0 restores the previous square mask and 22% fade.
        float cornerRadius=0.22*edgeDiffusion;
        float feather=mix(0.22,0.32,edgeDiffusion);
        vec2 edgeDelta=abs(haloUv)-vec2(1.0-cornerRadius);
        float edgeDistance=length(max(edgeDelta,vec2(0.0)))+min(max(edgeDelta.x,edgeDelta.y),0.0)-cornerRadius;
        float edge=1.0-smoothstep(-feather,0.0,edgeDistance);
        float incidence=max(0.0,dot(normalize(surfaceNormal),normalize(lightVector)));
        float distanceFalloff=clamp(referenceDistance/max(0.0001,dot(lightVector,lightVector)),0.35,1.5);
        float heightFalloff=mix(0.35,1.0,smoothstep(0.05,0.82,haloUv.y*0.5+0.5));
        // End the soft wall fade at the frame's top, not above it. Artwork
        // has its own receiver triangles, so this never dims its top edge.
        float upperSpill=1.0-smoothstep(topSpill.x,topSpill.y,haloUv.y);
        float spillSuppression=upperSpillSuppression*(1.0-wallOnlyUpperSpill*surfaceKind);
        float spillFalloff=mix(1.0,upperSpill,spillSuppression);
        // Fade after the exposure cap so the brightest upper-wall pixels
        // actually soften instead of remaining pinned to the limit.
        float baseGain=washStrength*beam*edge*incidence*distanceFalloff*heightFalloff;
        float gain=mix(min(washGainLimit,baseGain*spillFalloff),min(washGainLimit,baseGain)*spillFalloff,upperSpillAfterCap)*surfaceGain;
        if(gain<0.00001)discard;
        // This is a relative gain blended with already-rendered pixels, so it
        // deliberately bypasses tone mapping and output-color conversion.
        gl_FragColor=vec4(washTint*gain,0.0);
      }`,
  });
  const mesh=new THREE.Mesh(new THREE.BufferGeometry(),material);
  mesh.name='Night wall-frame exhibition wash';mesh.visible=false;
  mesh.castShadow=false;mesh.receiveShadow=false;mesh.renderOrder=4;
  // The wash is paint, not a physical blocker for gallery or product clicks.
  mesh.raycast=()=>{};
  mesh.userData={nightViewEffect:true,nightWallFrameLightEffect:true,angleDegrees:projectionAngleDegrees};furnitureLayer.add(mesh);
  const sourceMaterial=new THREE.MeshBasicMaterial({name:'Night exhibition spotlight heads',vertexColors:true,toneMapped:false,visible:showSources});
  const sourceMesh=new THREE.Mesh(new THREE.BufferGeometry(),sourceMaterial);
  sourceMesh.name='Night overhead frame spotlights';sourceMesh.visible=false;sourceMesh.renderOrder=3;
  sourceMesh.castShadow=false;sourceMesh.receiveShadow=false;sourceMesh.raycast=()=>{};
  sourceMesh.userData={nightViewEffect:true,nightWallFrameLightEffect:true,angleDegrees:projectionAngleDegrees};furnitureLayer.add(sourceMesh);
  const sourceParts={
    head:new THREE.CylinderGeometry(.027,.022,.082,12),
    aperture:new THREE.CircleGeometry(.0215,12),
    mount:new THREE.BoxGeometry(.055,.009,.045),
    stem:new THREE.CylinderGeometry(.004,.004,1,8),
  };
  const housingColor=new THREE.Color('#414349'),apertureColor=new THREE.Color('#ffe7b5'),housingKey=new THREE.Vector3(.35,1,.2).normalize();
  let sources=[],signature='',visibleWalls='',disposed=false;
  const sourceMeshes=root=>{
    const meshes=[];
    root.traverse(object=>{
      if(!object.isMesh||object.visible===false||object.userData.arrangeHelper||object.userData.arrangePickProxy||!object.geometry?.attributes.position||!object.geometry.attributes.normal)return;
      const materials=Array.isArray(object.material)?object.material:[object.material];
      if(materials.every(candidate=>!candidate||candidate.visible===false))return;
      meshes.push(object);
    });
    return meshes;
  };
  function syncPositions({force=false}={}){
    if(disposed)return false;
    furnitureLayer.updateWorldMatrix(true,false);
    const roots=frameRoots().filter(root=>isVisible(root)&&!root.userData.arrangeDeleted),entries=[];
    for(const root of roots){registerWall(root);root.updateWorldMatrix(true,true);entries.push({root,meshes:sourceMeshes(root)});}
    visibleWalls=wallVisibility();
    const nextSignature=visibleWalls+':'+entries.map(({root,meshes})=>root.uuid+':'+root.matrixWorld.elements.join(',')+':'+meshes.map(object=>object.uuid+':'+object.geometry.uuid).join(',')).join('|');
    if(!force&&nextSignature===signature)return false;
    signature=nextSignature;
    const positions=[],normals=[],projections=[],lightVectors=[],haloUvs=[],surfaceGains=[],surfaceKinds=[],referenceDistances=[],topSpillBounds=[],indices=[],nextSources=[];
    const sourcePositions=[],sourceNormals=[],sourceColors=[],sourceIndices=[];
    const furnitureInverse=new THREE.Matrix4().copy(furnitureLayer.matrixWorld).invert();
    const furnitureNormal=new THREE.Matrix3().getNormalMatrix(furnitureInverse);
    const furnitureDirection=new THREE.Matrix3().setFromMatrix4(furnitureInverse);
    const appendVertex=(point,normal,source,projection,surfaceGain,surfaceKind)=>{
      const relative=point.clone().sub(source),local=point.clone().applyMatrix4(furnitureInverse),localNormal=normal.clone().applyMatrix3(furnitureNormal).normalize();
      positions.push(local.x,local.y,local.z);normals.push(localNormal.x,localNormal.y,localNormal.z);
      projections.push(relative.dot(projection.right)/projection.horizontal,relative.dot(projection.up)/projection.vertical,relative.dot(projection.direction));
      const light=source.clone().sub(point).applyMatrix3(furnitureDirection);
      lightVectors.push(light.x,light.y,light.z);
      const wash=projection.washBounds;
      haloUvs.push(point.clone().sub(projection.target).dot(projection.right)/projection.halfWidth,2*(point.y-wash.minY)/(wash.maxY-wash.minY)-1);
      surfaceGains.push(surfaceGain);surfaceKinds.push(surfaceKind);referenceDistances.push(projection.referenceDistance);
      topSpillBounds.push(...projection.topSpill);
    };
    const appendSourcePart=(geometry,matrix,color,shaded=true)=>{
      const base=sourcePositions.length/3,normalMatrix=new THREE.Matrix3().getNormalMatrix(matrix);
      for(let index=0;index<geometry.attributes.position.count;index++){
        const point=new THREE.Vector3().fromBufferAttribute(geometry.attributes.position,index).applyMatrix4(matrix),normal=new THREE.Vector3().fromBufferAttribute(geometry.attributes.normal,index).applyMatrix3(normalMatrix).normalize();
        const shade=shaded?.6+.4*Math.max(0,normal.dot(housingKey)):1;
        point.applyMatrix4(furnitureInverse);normal.applyMatrix3(furnitureNormal).normalize();
        sourcePositions.push(point.x,point.y,point.z);sourceNormals.push(normal.x,normal.y,normal.z);sourceColors.push(color.r*shade,color.g*shade,color.b*shade);
      }
      const index=geometry.index;
      if(index)for(let i=0;i<index.count;i++)sourceIndices.push(base+index.getX(i));
      else for(let i=0;i<geometry.attributes.position.count;i++)sourceIndices.push(base+i);
      return {start:base,count:geometry.attributes.position.count};
    };
    const plans=entries.filter(entry=>entry.meshes.length).map(({root,meshes})=>{
      const bounds=new THREE.Box3().makeEmpty(),localBounds=new THREE.Box3().makeEmpty(),rootInverse=root.matrixWorld.clone().invert();
      for(const object of meshes){
        bounds.union(new THREE.Box3().setFromObject(object));
        const transform=new THREE.Matrix4().multiplyMatrices(rootInverse,object.matrixWorld);
        for(let index=0;index<object.geometry.attributes.position.count;index++)localBounds.expandByPoint(new THREE.Vector3().fromBufferAttribute(object.geometry.attributes.position,index).applyMatrix4(transform));
      }
      const localSize=localBounds.getSize(new THREE.Vector3()),size=bounds.getSize(new THREE.Vector3());
      const front=new THREE.Vector3(0,0,1).transformDirection(root.matrixWorld),right=new THREE.Vector3(1,0,0).transformDirection(root.matrixWorld);
      const target=localBounds.getCenter(new THREE.Vector3());target.z=localBounds.max.z;
      // Bias the steeper beam toward the lower center of the artwork, not the
      // floor. Selecting the previous 45° angle restores its centered aim.
      target.y-=localSize.y*aimDepthFraction;target.applyMatrix4(root.matrixWorld);
      const wallName=root.userData.movableItem?.hostWall||root.userData.wallFrame?.wallName,surfaces=wallSurfaces.get(wallName)||[];
      const ceiling=surfaces.length?Math.max(...surfaces.map(surface=>surface.bounds.max.y)):bounds.max.y+.30;
      // Leave room for the tilted housing even when Arrange raises a frame to
      // the wall's upper limit. The horizontal stand-off gives the true angle.
      const rise=Math.max(.02,ceiling-.11-target.y),run=rise/Math.tan(projectionAngle),source=target.clone().addScaledVector(front,run);source.y+=rise;
      const direction=target.clone().sub(source).normalize(),up=new THREE.Vector3(0,1,0).addScaledVector(direction,-direction.y).normalize(),distance=source.distanceTo(target);
      const rightScale=new THREE.Vector3().setFromMatrixColumn(root.matrixWorld,0).length();
      const baseHalfWidth=localSize.x*rightScale/2+.28,baseMinY=bounds.min.y-.22,baseMaxY=Math.min(ceiling-.035,Math.max(bounds.max.y+.32,source.y-.035));
      const centerY=(baseMinY+baseMaxY)/2,halfHeight=(baseMaxY-baseMinY)/2*footprintScale,halfWidth=baseHalfWidth*footprintScale,minY=centerY-halfHeight,maxY=centerY+halfHeight;
      const targetU=target.dot(right),washBounds={minY,maxY,minU:targetU-halfWidth,maxU:targetU+halfWidth};
      const horizontal=halfWidth/distance*1.35,vertical=1.15*footprintScale;
      const referenceDistance=target.clone().sub(source).applyMatrix3(furnitureDirection).lengthSq();
      const projection={direction,up,right,horizontal,vertical,target,halfWidth,washBounds,referenceDistance};
      return {root,meshes,bounds,front,wallName,surfaces,ceiling,source,projection};
    });
    for(const {root,meshes,bounds,front,wallName,surfaces,ceiling,source,projection} of plans){
      const {target,direction,washBounds}=projection;
      // An upper frame's broad beam must not recreate an arc above a lower
      // frame in the same column. Share the wall-only limit for overlapping
      // artwork spans; nearby frames in separate columns keep their own.
      const wallSpillTop=wallOnlyUpperSpill?Math.min(...plans.filter(plan=>plan.wallName===wallName&&plan.front.dot(front)>.99&&plan.projection.washBounds.minU<washBounds.maxU&&plan.projection.washBounds.maxU>washBounds.minU).map(plan=>plan.bounds.max.y)):bounds.max.y;
      projection.topSpill=spillOffsets.map(offset=>2*(wallSpillTop+offset-washBounds.minY)/(washBounds.maxY-washBounds.minY)-1);
      // Stacked frames share some wall pixels. Limit compounded exposure
      // smoothly with a fixed source share, not a hard clipped beam boundary.
      const overlapCount=plans.filter(plan=>plan.wallName===wallName&&plan.front.dot(front)>.99&&plan.projection.washBounds.minY<washBounds.maxY&&plan.projection.washBounds.maxY>washBounds.minY&&plan.projection.washBounds.minU<washBounds.maxU&&plan.projection.washBounds.maxU>washBounds.minU).length;
      const wallShare=Math.pow(2,1/Math.max(1,overlapCount))-1;
      const sourceInfo={id:root.userData.movableItem?.id||root.uuid,name:root.name,frameCount:root.userData.frameGrid?root.userData.frameGrid.columns*root.userData.frameGrid.rows:1,angleDegrees:projectionAngleDegrees,position:source.toArray(),target:target.toArray(),front:front.toArray(),washBounds,wallShare,wallSpillTop,projection:{horizontal:projection.horizontal,vertical:projection.vertical,direction:direction.toArray(),up:projection.up.toArray(),right:projection.right.toArray(),referenceDistance:projection.referenceDistance,topSpill:projection.topSpill}};
      nextSources.push(sourceInfo);
      const headCenter=source.clone().addScaledVector(direction,-.041),headRotation=new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),direction);
      appendSourcePart(sourceParts.head,new THREE.Matrix4().compose(headCenter,headRotation,new THREE.Vector3(1,1,1)),housingColor);
      const mountCenter=new THREE.Vector3(headCenter.x,ceiling-.0045,headCenter.z),stemHeight=Math.max(.004,ceiling-.009-headCenter.y);
      appendSourcePart(sourceParts.mount,new THREE.Matrix4().makeTranslation(mountCenter.x,mountCenter.y,mountCenter.z),housingColor);
      appendSourcePart(sourceParts.stem,new THREE.Matrix4().compose(new THREE.Vector3(headCenter.x,headCenter.y+stemHeight/2,headCenter.z),new THREE.Quaternion(),new THREE.Vector3(1,stemHeight,1)),housingColor);
      const apertureCenter=source.clone().addScaledVector(direction,.001),apertureRotation=new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,0,1),direction);
      sourceInfo.apertureVertexRange=appendSourcePart(sourceParts.aperture,new THREE.Matrix4().compose(apertureCenter,apertureRotation,new THREE.Vector3(1,1,1)),apertureColor,false);
      for(const object of meshes){
        const geometry=object.geometry,position=geometry.attributes.position,normal=geometry.attributes.normal,normalMatrix=new THREE.Matrix3().getNormalMatrix(object.matrixWorld),base=positions.length/3;
        const receiverGain=object.name.toLowerCase().includes('rail')?.24:.8;
        for(let index=0;index<position.count;index++){
          const surfaceNormal=new THREE.Vector3().fromBufferAttribute(normal,index).applyMatrix3(normalMatrix).normalize();
          const point=new THREE.Vector3().fromBufferAttribute(position,index).applyMatrix4(object.matrixWorld).addScaledVector(surfaceNormal,.0004);
          appendVertex(point,surfaceNormal,source,projection,receiverGain,1);
        }
        if(geometry.index)for(let index=0;index<geometry.index.count;index++)indices.push(base+geometry.index.getX(index));
        else for(let index=0;index<position.count;index++)indices.push(base+index);
      }
      // Restrict the downward wall wash to real host panels, including window
      // and doorway boundaries captured before architecture batching.
      for(const surface of isVisible(wallRoots.get(wallName))?surfaces:[]){
        const geometry=surface.geometry,position=geometry.attributes.position,normal=geometry.attributes.normal,index=geometry.index,normalMatrix=new THREE.Matrix3().getNormalMatrix(surface.matrix);
        if(!position||!normal)continue;
        const clip=(polygon,value,limit,greater)=>{
          const output=[];for(let corner=0;corner<polygon.length;corner++){
            const a=polygon[corner],b=polygon[(corner+1)%polygon.length],av=value(a),bv=value(b),insideA=greater?av>=limit:av<=limit,insideB=greater?bv>=limit:bv<=limit;
            if(insideA)output.push(a);if(insideA!==insideB)output.push(a.clone().lerp(b,(limit-av)/(bv-av)));
          }return output;
        };
        for(let triangle=0;triangle<(index?.count??position.count);triangle+=3){
          const ids=[0,1,2].map(corner=>index?index.getX(triangle+corner):triangle+corner);
          const surfaceNormal=new THREE.Vector3().fromBufferAttribute(normal,ids[0]).applyMatrix3(normalMatrix).normalize();
          if(surfaceNormal.dot(front)<.9)continue;
          let polygon=ids.map(id=>new THREE.Vector3().fromBufferAttribute(position,id).applyMatrix4(surface.matrix));
          for(const [value,limit,greater] of [[point=>point.y,washBounds.minY,true],[point=>point.y,washBounds.maxY,false],[point=>point.dot(projection.right),washBounds.minU,true],[point=>point.dot(projection.right),washBounds.maxU,false]]){polygon=clip(polygon,value,limit,greater);if(polygon.length<3)break;}
          if(polygon.length<3)continue;const base=positions.length/3;
          for(const point of polygon)appendVertex(point.clone().addScaledVector(surfaceNormal,.0004),surfaceNormal,source,projection,wallShare,0);
          for(let corner=1;corner<polygon.length-1;corner++)indices.push(base,base+corner,base+corner+1);
        }
      }
    }
    const geometry=new THREE.BufferGeometry();
    geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));
    geometry.setAttribute('exhibitionProjection',new THREE.Float32BufferAttribute(projections,3));geometry.setAttribute('exhibitionLightVector',new THREE.Float32BufferAttribute(lightVectors,3));
    geometry.setAttribute('exhibitionHaloUv',new THREE.Float32BufferAttribute(haloUvs,2));geometry.setAttribute('exhibitionSurfaceGain',new THREE.Float32BufferAttribute(surfaceGains,1));geometry.setIndex(indices);
    geometry.setAttribute('exhibitionSurfaceKind',new THREE.Float32BufferAttribute(surfaceKinds,1));geometry.setAttribute('exhibitionReferenceDistance',new THREE.Float32BufferAttribute(referenceDistances,1));
    geometry.setAttribute('exhibitionTopSpill',new THREE.Float32BufferAttribute(topSpillBounds,2));
    geometry.computeBoundingBox();geometry.computeBoundingSphere();mesh.geometry.dispose();mesh.geometry=geometry;sources=nextSources;
    const sourceGeometry=new THREE.BufferGeometry();sourceGeometry.setAttribute('position',new THREE.Float32BufferAttribute(sourcePositions,3));sourceGeometry.setAttribute('normal',new THREE.Float32BufferAttribute(sourceNormals,3));sourceGeometry.setAttribute('color',new THREE.Float32BufferAttribute(sourceColors,3));sourceGeometry.setIndex(sourceIndices);
    sourceGeometry.computeBoundingBox();sourceGeometry.computeBoundingSphere();sourceMesh.geometry.dispose();sourceMesh.geometry=sourceGeometry;sourceMesh.userData.sourceCount=sources.length;
    mesh.userData.sourceCount=sources.length;mesh.userData.frameCount=sources.reduce((total,source)=>total+source.frameCount,0);
    return true;
  }
  syncPositions();
  return {mesh,material,sourceMesh,sourceMaterial,meshes:[mesh,sourceMesh],get geometry(){return mesh.geometry;},get count(){return sources.length;},get sources(){return sources;},syncPositions,syncVisibility:()=>wallVisibility()!==visibleWalls?syncPositions():false,setVisible:visible=>{mesh.visible=Boolean(visible);sourceMesh.visible=Boolean(visible&&showSources);},dispose:()=>{disposed=true;for(const object of [mesh,sourceMesh]){object.removeFromParent();object.geometry.dispose();}material.dispose();sourceMaterial.dispose();for(const geometry of Object.values(sourceParts))geometry.dispose();}};
}
