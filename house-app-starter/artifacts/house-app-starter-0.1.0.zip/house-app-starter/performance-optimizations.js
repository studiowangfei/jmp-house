import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';

function isInsideExcludedRoot(object,root,excludedRoots){
  for(let current=object;current&&current!==root;current=current.parent){
    if(excludedRoots.has(current))return true;
  }
  return false;
}

function geometrySignature(object){
  const geometry=object.geometry;
  const attributes=Object.entries(geometry.attributes)
    .map(([name,attribute])=>`${name}:${attribute.itemSize}:${attribute.normalized}:${attribute.array.constructor.name}`)
    .sort().join(',');
  return `${object.isLineSegments?'lines':'mesh'}|${object.material.uuid}|${object.castShadow}|${object.receiveShadow}|${object.visible}|${object.layers.mask}|${object.frustumCulled}|${object.renderOrder}|${geometry.index?'indexed':'plain'}|${attributes}`;
}

function isBatchableObject(object,root,excludedRoots,preserveObject){
  if(object===root||isInsideExcludedRoot(object,root,excludedRoots)||preserveObject(object))return false;
  if((!object.isMesh&&!object.isLineSegments)||object.isInstancedMesh||Array.isArray(object.material))return false;
  if(object.isSkinnedMesh||Object.keys(object.geometry.morphAttributes||{}).length||object.renderOrder!==0||object.customDepthMaterial||object.customDistanceMaterial)return false;
  const drawCount=object.geometry.index?.count??object.geometry.attributes.position?.count??0,drawRange=object.geometry.drawRange;
  if(drawRange&&(drawRange.start!==0||drawRange.count!==Infinity&&drawRange.count<drawCount))return false;
  if(object.isMesh&&object.material.transparent)return false;
  return true;
}

function batchableObjects(root,excludedRoots=new Set(),preserveObject=()=>false){
  const objects=[];root.traverse(object=>{if(isBatchableObject(object,root,excludedRoots,preserveObject))objects.push(object);});return objects;
}

function batchStaticGroup(THREE,root,{excludedRoots=new Set(),label=root.name||'static',minimumCount=2,preserveObject=()=>false}={}){
  root.updateWorldMatrix(true,true);
  const rootInverse=new THREE.Matrix4().copy(root.matrixWorld).invert();
  const groups=new Map();
  root.traverse(object=>{
    if(!isBatchableObject(object,root,excludedRoots,preserveObject))return;
    const key=geometrySignature(object),entries=groups.get(key)||[];
    entries.push(object);groups.set(key,entries);
  });
  const batches=[];
  for(const entries of groups.values()){
    if(entries.length<minimumCount)continue;
    const geometries=entries.map(object=>{
      const matrix=new THREE.Matrix4().multiplyMatrices(rootInverse,object.matrixWorld);
      return object.geometry.clone().applyMatrix4(matrix);
    });
    const merged=mergeGeometries(geometries,false);
    geometries.forEach(geometry=>geometry.dispose());
    if(!merged)continue;
    const source=entries[0];
    const batch=source.isLineSegments
      ?new THREE.LineSegments(merged,source.material)
      :new THREE.Mesh(merged,source.material);
    batch.name=`Performance batch · ${label}`;
    batch.castShadow=source.castShadow;batch.receiveShadow=source.receiveShadow;
    batch.visible=source.visible;batch.layers.mask=source.layers.mask;batch.frustumCulled=source.frustumCulled;
    batch.userData={performanceBatch:true,sourceCount:entries.length,sourceNames:[...new Set(entries.map(object=>object.name))]};
    merged.computeBoundingBox();merged.computeBoundingSphere();
    entries.forEach(object=>object.removeFromParent());root.add(batch);batches.push(batch);
  }
  return batches;
}

function materialDrawCalls(material){return material?.visible===false?0:material?.transparent&&material.side===2&&!material.forceSinglePass?2:1;}

function drawCallCount(root){
  let calls=0;root.traverse(object=>{
    if((!object.isMesh&&!object.isLineSegments)||!object.material)return;
    if(Array.isArray(object.material))calls+=object.geometry.groups.reduce((sum,group)=>sum+materialDrawCalls(object.material[group.materialIndex]),0);
    else calls+=materialDrawCalls(object.material);
  });return calls;
}


// Semantic metadata and animated roots remain intact through batching.
const preserveSemantic=object=>Object.keys(object.userData||{}).length>0;
export function optimizeStaticScene(THREE,{layers,exterior=[],glazingGroups=[],animatedRoots=[],preserveMovableFurniture=true}){
 const exteriorRoots=new Set(exterior.map(entry=>entry.group)),glazingRoots=new Set(glazingGroups);let batches=0,sourceObjects=0;
 const apply=(root,options={})=>{if(!root)return;const created=batchStaticGroup(THREE,root,{preserveObject:preserveSemantic,...options});batches+=created.length;sourceObjects+=created.reduce((n,batch)=>n+batch.userData.sourceCount,0);};
 apply(layers.architecture,{excludedRoots:new Set([...exteriorRoots,...glazingRoots]),label:'architecture'});
 for(const root of exteriorRoots)apply(root,{excludedRoots:glazingRoots,label:'exterior wall'});
 for(const root of glazingRoots)apply(root,{label:'glazing frame'});
 apply(layers.cabinetry,{excludedRoots:new Set(animatedRoots),label:'cabinetry'});
 // Batch within movable logical roots, retaining independent root transforms.
 if(preserveMovableFurniture)for(const root of layers.furniture.children){
  if(!root.userData.movableItem||root.userData.audioPlayerTrigger||root.userData.frameGrid||root.children.some(child=>child.isReflector))continue;
  apply(root,{label:root.name});
 }
 return{batches,sourceObjects};
}
export function optimizeGalleryFrameRails(THREE,galleryRoot){
 if(!galleryRoot)return{beforeDrawCalls:0,afterDrawCalls:0,batches:0};
 const beforeDrawCalls=drawCallCount(galleryRoot),batches=batchStaticGroup(THREE,galleryRoot,{label:'gallery rails',preserveObject:preserveSemantic});
 const report={beforeDrawCalls,afterDrawCalls:drawCallCount(galleryRoot),batches:batches.length,sourceObjects:batches.reduce((sum,batch)=>sum+batch.userData.sourceCount,0),movable:true};
 galleryRoot.userData.performanceOptimization=report;return report;
}
