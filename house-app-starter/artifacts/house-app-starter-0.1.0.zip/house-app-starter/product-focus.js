const shortestAngle=(from,to)=>Math.atan2(Math.sin(to-from),Math.cos(to-from));

export function productFocusBounds(THREE,roots,maxSampleMeshes=16){
 const bounds=new THREE.Box3().makeEmpty(),samples=[],meshes=[];
 for(const root of roots){root.updateWorldMatrix(true,true);bounds.expandByObject(root);}
 if(bounds.isEmpty())return{bounds,samples};
 for(const root of roots)root.traverse(object=>{if(object.isMesh&&!object.userData.arrangePickProxy)meshes.push(object);});
 const sampledMeshes=meshes.length<=maxSampleMeshes?meshes:Array.from({length:maxSampleMeshes},(_,index)=>meshes[Math.round(index*(meshes.length-1)/(maxSampleMeshes-1))]);
 for(const mesh of sampledMeshes){
  const meshBounds=new THREE.Box3().setFromObject(mesh);if(meshBounds.isEmpty())continue;
  const center=meshBounds.getCenter(new THREE.Vector3());samples.push(center,new THREE.Vector3(center.x,meshBounds.max.y-.01,center.z));
 }
 if(!samples.length)samples.push(bounds.getCenter(new THREE.Vector3()));
 return{bounds,samples};
}

export function productFocusMinimumVerticalRatio(THREE,bounds,houseBounds){
 if(!bounds||bounds.isEmpty()||!houseBounds||houseBounds.isEmpty())return.65;
 const center=bounds.getCenter(new THREE.Vector3()),size=bounds.getSize(new THREE.Vector3()),edgeDistance=Math.min(center.x-houseBounds.min.x,houseBounds.max.x-center.x,center.z-houseBounds.min.z,houseBounds.max.z-center.z);
 return edgeDistance<1.25&&size.y>Math.max(size.x,size.z)*1.5?1.8:.65;
}

export function chooseProductFocusOffset(THREE,{target,currentOffset,distance=currentOffset.length(),samples=[],bounds=null,isVisible=()=>true,defaultYaw=Math.PI/4,minVerticalRatio=.65,preferredYaw=null,compact=false}={}){
 const horizontalLength=Math.hypot(currentOffset.x,currentOffset.z),currentYaw=horizontalLength>1e-8?Math.atan2(currentOffset.x,currentOffset.z):defaultYaw,rawCurrentRatio=horizontalLength>1e-8?Math.max(.55,currentOffset.y/horizontalLength):1,currentRatio=THREE.MathUtils.clamp(rawCurrentRatio,.65,1.5);
 const offsets=[],angleStep=compact?30:15;for(let degrees=-135;degrees<=135;degrees+=angleStep)offsets.push(degrees*Math.PI/180);
 const yaws=[];
 for(const base of [currentYaw,defaultYaw,...(Number.isFinite(preferredYaw)?[preferredYaw]:[])])for(const offset of offsets){const yaw=base+offset;if(!yaws.some(value=>Math.abs(shortestAngle(value,yaw))<1e-4))yaws.push(yaw);}
 const ratioCandidates=compact?[Math.max(currentRatio,minVerticalRatio),Math.max(1.35,minVerticalRatio),Math.max(2.2,minVerticalRatio)]:[Math.max(currentRatio,minVerticalRatio),Math.max(1.1,minVerticalRatio),Math.max(1.35,minVerticalRatio),Math.max(1.8,minVerticalRatio),Math.max(2.2,minVerticalRatio)];
 const ratios=ratioCandidates.filter((ratio,index,list)=>list.indexOf(ratio)===index),samplePoints=(samples.length?samples:[target]).map(sample=>sample?.point?sample:{point:sample,object:null,weight:1}),sampleWeight=samplePoints.reduce((sum,sample)=>sum+(sample.weight||1),0),halfSize=bounds&&!bounds.isEmpty()?bounds.getSize(new THREE.Vector3()).multiplyScalar(.5):null,candidates=[];
 for(const yaw of yaws)for(const ratio of ratios){
  const direction=new THREE.Vector3(Math.sin(yaw),ratio,Math.cos(yaw)).normalize(),position=target.clone().addScaledVector(direction,distance),visibleWeight=samplePoints.reduce((sum,sample)=>sum+(isVisible(position,sample.point,direction,distance,sample)?sample.weight||1:0),0),visibility=visibleWeight/sampleWeight;
  const forward=direction.clone().negate(),right=forward.clone().cross(new THREE.Vector3(0,1,0)).normalize(),projectedWidth=halfSize?2*(Math.abs(right.x)*halfSize.x+Math.abs(right.y)*halfSize.y+Math.abs(right.z)*halfSize.z):1;
  candidates.push({direction,visibility,yawDelta:shortestAngle(currentYaw,yaw),verticalRatio:ratio,projectedWidth});
 }
 const maxWidth=Math.max(...candidates.map(candidate=>candidate.projectedWidth),1e-6);let best=null;
 for(const candidate of candidates){
  const presentation=candidate.projectedWidth/maxWidth,yawCost=Math.abs(candidate.yawDelta)/Math.PI,pitchCost=Math.abs(Math.atan(candidate.verticalRatio)-Math.atan(currentRatio))/(Math.PI/2),hintCost=Number.isFinite(preferredYaw)?Math.abs(shortestAngle(preferredYaw,currentYaw+candidate.yawDelta))/Math.PI:0,score=candidate.visibility*10+presentation*.9-yawCost*.25-pitchCost*.55-hintCost*3;
  if(!best||score>best.score)best={offset:candidate.direction.multiplyScalar(distance),visibility:candidate.visibility,presentation,score,yawDelta:candidate.yawDelta,verticalRatio:candidate.verticalRatio};
 }
 return best;
}

export function productFocusZoom(THREE,camera,radius,{fill=.34,minZoom=1.05,maxZoom=4.5}={}){
 const baseHalf=Math.min((camera.right-camera.left)/2,(camera.top-camera.bottom)/2);
 return THREE.MathUtils.clamp(baseHalf*fill/Math.max(.18,radius),minZoom,maxZoom);
}
