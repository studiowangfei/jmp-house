import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {productCatalog} from './catalog-data.js';

export {productCatalog};

function fabricTexture(){
  const size=48,data=new Uint8Array(size*size*4);
  for(let y=0;y<size;y++)for(let x=0;x<size;x++){
    const i=(y*size+x)*4,v=196+((x*17+y*29)%13)+(x%3===0?18:0)+(y%3===0?12:0);
    data[i]=data[i+1]=data[i+2]=Math.min(255,v);data[i+3]=255;
  }
  const texture=new THREE.DataTexture(data,size,size,THREE.RGBAFormat);
  texture.name='Original procedural woven fabric';texture.colorSpace=THREE.SRGBColorSpace;
  texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.repeat.set(5,5);texture.needsUpdate=true;return texture;
}

function finishes(){
  const fabric=fabricTexture();
  return {
    wood:new THREE.MeshStandardMaterial({color:'#af8558',roughness:.64}),
    woodLight:new THREE.MeshStandardMaterial({color:'#c9a77c',roughness:.68}),
    moss:new THREE.MeshStandardMaterial({color:'#778574',roughness:.94,map:fabric}),
    linen:new THREE.MeshStandardMaterial({color:'#e9e1ce',roughness:.95,map:fabric}),
    metal:new THREE.MeshStandardMaterial({color:'#817d73',metalness:.7,roughness:.32}),
    dark:new THREE.MeshStandardMaterial({color:'#343b3b',roughness:.78}),
    cream:new THREE.MeshStandardMaterial({color:'#e5e0d2',roughness:.56}),
    terra:new THREE.MeshStandardMaterial({color:'#b36e50',roughness:.48}),
    diffuser:new THREE.MeshStandardMaterial({color:'#fff0d2',emissive:'#e9be7d',emissiveIntensity:.12,roughness:.6}),
    mirror:new THREE.MeshPhysicalMaterial({color:'#cddbd6',metalness:.92,roughness:.055}),
    leaf:new THREE.MeshStandardMaterial({color:'#46654f',roughness:.72,side:THREE.DoubleSide}),
    stem:new THREE.MeshStandardMaterial({color:'#776344',roughness:.85}),
  };
}

function mesh(parent,name,geometry,material,position=[0,0,0]){
  const object=new THREE.Mesh(geometry,material);object.name=name;object.position.set(...position);
  object.castShadow=true;object.receiveShadow=true;parent.add(object);return object;
}
function rounded(parent,name,size,position,material,radius=.035){
  return mesh(parent,name,new RoundedBoxGeometry(...size,3,Math.min(radius,...size.map(n=>n/2))),material,position);
}
function cylinder(parent,name,radiusTop,radiusBottom,height,position,material,segments=24){
  return mesh(parent,name,new THREE.CylinderGeometry(radiusTop,radiusBottom,height,segments),material,position);
}
function rod(parent,name,start,end,radius,material){
  const a=new THREE.Vector3(...start),b=new THREE.Vector3(...end),delta=b.clone().sub(a);
  const object=cylinder(parent,name,radius,radius,delta.length(),a.clone().add(b).multiplyScalar(.5).toArray(),material,12);
  object.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize());return object;
}
function roundedShape(width,height,radius){
  const x=-width/2,y=-height/2,r=Math.min(radius,width/2,height/2),shape=new THREE.Shape();
  shape.moveTo(x+r,y);shape.lineTo(x+width-r,y);shape.quadraticCurveTo(x+width,y,x+width,y+r);
  shape.lineTo(x+width,y+height-r);shape.quadraticCurveTo(x+width,y+height,x+width-r,y+height);
  shape.lineTo(x+r,y+height);shape.quadraticCurveTo(x,y+height,x,y+height-r);
  shape.lineTo(x,y+r);shape.quadraticCurveTo(x,y,x+r,y);return shape;
}
function shapedPanel(parent,name,width,height,depth,position,material,radius=.08){
  const geometry=new THREE.ExtrudeGeometry(roundedShape(width,height,radius),{depth,bevelEnabled:true,bevelSegments:3,steps:1,bevelSize:.004,bevelThickness:.003,curveSegments:12});
  geometry.translate(0,0,-depth/2);return mesh(parent,name,geometry,material,position);
}

function table(body,m){
  const top=shapedPanel(body,'Rounded dining top',1.6,.85,.055,[0,.708,0],m.woodLight,.12);top.rotation.x=-Math.PI/2;
  for(const x of [-.64,.64])for(const z of [-.29,.29]){
    const leg=cylinder(body,'Tapered table leg',.039,.025,.67,[x,.335,z],m.wood);
    leg.rotation.z=-Math.sign(x)*.045;leg.rotation.x=Math.sign(z)*.045;
  }
  for(const z of [-.29,.29])rounded(body,'Long apron',[1.31,.075,.035],[0,.63,z],m.wood,.008);
  for(const x of [-.64,.64])rounded(body,'End apron',[.035,.075,.6],[x,.63,0],m.wood,.008);
}

function chair(body,m){
  const seat=shapedPanel(body,'Curved chair seat',.47,.46,.045,[0,.43,.025],m.woodLight,.12);seat.rotation.x=-Math.PI/2;
  rounded(body,'Woven seat inset',[.395,.022,.37],[0,.47,.04],m.linen,.06);
  for(const x of [-.2,.2])for(const z of [-.18,.19]){
    const leg=cylinder(body,'Tapered chair leg',.024,.016,.43,[x,.215,z],m.wood,16);
    leg.rotation.z=-Math.sign(x)*.045;leg.rotation.x=Math.sign(z)*.035;
  }
  for(const x of [-.205,.205])rod(body,'Back upright',[x,.41,-.175],[x,.78,-.23],.017,m.wood);
  const back=shapedPanel(body,'Arched chair back',.51,.225,.035,[0,.718,-.225],m.woodLight,.105);back.rotation.x=-.08;
  rod(body,'Chair stretcher',[-.2,.2,.19],[.2,.2,.19],.012,m.wood);
}

function sofa(body,m){
  rounded(body,'Sofa upholstered base',[2.1,.24,.83],[0,.25,.025],m.moss,.095);
  rounded(body,'Sofa back frame',[2.09,.51,.19],[0,.52,-.34],m.moss,.08);
  for(const x of [-.7,0,.7]){
    const seat=rounded(body,'Separate seat cushion',[.645,.17,.69],[x,.455,.08],m.moss,.075);
    seat.rotation.z=x===0?.005:Math.sign(x)*-.008;
    const back=rounded(body,'Separate back cushion',[.65,.39,.18],[x,.615,-.245],m.moss,.085);back.rotation.x=-.12;
    rounded(body,'Cushion seam piping',[.595,.008,.012],[x,.527,.36],m.linen,.004);
  }
  for(const x of [-.982,.982])rounded(body,'Rounded sofa arm',[.19,.45,.85],[x,.405,.025],m.moss,.09);
  for(const x of [-.83,.83])for(const z of [-.29,.3])cylinder(body,'Short wood foot',.035,.03,.145,[x,.0725,z],m.wood,14);
}

function pendant(body,m){
  const profile=[[.012,.24],[.055,.235],[.083,.205],[.125,.18],[.174,.132],[.211,.07],[.23,.029],[.229,.015],[.21,.012]];
  mesh(body,'Spun pendant shade',new THREE.LatheGeometry(profile.map(([x,y])=>new THREE.Vector2(x,y)),48),m.terra);
  cylinder(body,'Warm pendant diffuser',.204,.204,.014,[0,.026,0],m.diffuser,48);
  cylinder(body,'Pendant neck',.029,.033,.035,[0,.22,0],m.metal);
  const emitter=mesh(body,'Pendant light emitter',new THREE.SphereGeometry(.022,16,10),m.diffuser,[0,.055,0]);emitter.userData.lightEmitter=true;
}

function floorLamp(body,m){
  cylinder(body,'Weighted floor-lamp base',.168,.19,.04,[0,.02,0],m.metal,40);
  cylinder(body,'Slender floor-lamp stem',.013,.017,1.34,[0,.71,0],m.metal,20);
  const shade=mesh(body,'Tapered fabric lampshade',new THREE.CylinderGeometry(.127,.185,.3,40,1,true),m.linen,[0,1.4,0]);shade.material.side=THREE.DoubleSide;
  for(const y of [1.25,1.55]){
    const rim=mesh(body,'Lampshade bound edge',new THREE.TorusGeometry(y<1.4?.184:.127,.003,6,40),m.cream,[0,y,0]);rim.rotation.x=Math.PI/2;
  }
  const emitter=mesh(body,'Floor lamp light emitter',new THREE.SphereGeometry(.027,16,10),m.diffuser,[0,1.31,0]);emitter.userData.lightEmitter=true;
  rod(body,'Floor-lamp shade support',[-.12,1.39,0],[.12,1.39,0],.002,m.metal);
}

function mirror(body,m){
  const face=mesh(body,'mirror face',new THREE.CircleGeometry(.341,64),m.mirror,[0,.375,.012]);face.castShadow=false;face.userData.mirrorSurface=true;
  mesh(body,'mirror frame',new THREE.TorusGeometry(.3535,.0215,12,64),m.woodLight,[0,.375,0]).userData.mirrorFrame=true;
  const backing=cylinder(body,'Mirror backing',.354,.354,.019,[0,.375,-.012],m.dark,64);backing.rotation.x=Math.PI/2;
}

function speaker(body,m){
  rounded(body,'Rounded speaker enclosure',[.32,.205,.15],[0,.108,0],m.cream,.025);
  for(const x of [-.084,.084]){
    const grille=mesh(body,'Speaker driver grille',new THREE.CircleGeometry(.062,32),m.dark,[x,.112,.077]);
    const rim=mesh(body,'Driver circular trim',new THREE.TorusGeometry(.063,.003,6,32),m.metal,[x,.112,.079]);
    grille.userData.audioReactive={kind:'driver',restZ:grille.position.z,travel:.00025,phase:x*20};
    for(let row=-5;row<=5;row++)for(let col=-5;col<=5;col++)if(row*row+col*col<28){
      const dot=mesh(body,'Grille perforation',new THREE.CircleGeometry(.00135,5),m.metal,[x+col*.01,.112+row*.01,.0775]);dot.castShadow=false;
    }
  }
  const dial=cylinder(body,'Top volume dial',.017,.017,.012,[.105,.214,-.014],m.dark,20);dial.userData.audioReactive={kind:'dial',restRotationY:0,speed:.8};
  rounded(dial,'Dial pointer',[.004,.002,.014],[0,.007,.004],m.cream,.0005);
  const indicator=rounded(body,'Playback indicator',[.039,.007,.003],[0,.168,.079],m.diffuser,.0015);indicator.userData.keepBrightAtNight=true;indicator.userData.audioReactive={kind:'indicator',onColor:'#83b88c',onIntensity:.65,offColor:m.diffuser.color.getHex(),offEmissive:m.diffuser.emissive.getHex(),offIntensity:m.diffuser.emissiveIntensity};
  for(const x of [-.115,.115])for(const z of [-.048,.048])cylinder(body,'Speaker rubber foot',.009,.01,.007,[x,.0035,z],m.dark,12);
}

function leafGeometry(length,width){
  const vertices=[],uvs=[],indices=[],rows=12;
  for(let i=0;i<=rows;i++){
    const t=i/rows,half=Math.sin(Math.PI*t)*width/2;
    for(let side=-1;side<=1;side++){
      vertices.push(side*half,t*length,Math.sin(Math.PI*t)*length*.13+(side===0?-.006:0));uvs.push((side+1)/2,t);
    }
  }
  for(let i=0;i<rows;i++)for(let j=0;j<2;j++){
    const a=i*3+j,b=a+1,c=a+3,d=c+1;indices.push(a,c,b,b,c,d);
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geometry.setIndex(indices);geometry.computeVertexNormals();return geometry;
}

function plant(body,m){
  const profile=[[.09,0],[.108,.012],[.128,.23],[.135,.245],[.137,.253],[.122,.26],[.117,.245]];
  mesh(body,'Rounded ceramic planter',new THREE.LatheGeometry(profile.map(([x,y])=>new THREE.Vector2(x,y)),40),m.cream);
  cylinder(body,'Dark pot soil',.117,.117,.012,[0,.245,0],m.stem,32);
  for(const [index,x] of [-.018,.019].entries()){
    const top=index===0?1.19:1.06;
    rod(body,'Branching plant trunk',[x,.245,0],[x+.024,top,-.012],.009,m.stem);
    for(let i=0;i<8;i++){
      const y=.43+i*.095,angle=i*2.399+index*1.1,length=.22+(i%3)*.015;
      const end=[x+Math.cos(angle)*.18,y+.065,Math.sin(angle)*.18];
      rod(body,'Plant leaf stem',[x,y,0],end,.003,m.stem);
      const leaf=mesh(body,'Curved plant leaf',leafGeometry(length,.115),m.leaf,end);
      leaf.rotation.set(.5+Math.sin(angle)*.3,angle,Math.cos(angle)*-.7);
      const vein=rod(leaf,'Leaf center vein',[0,0,0],[0,length*.88,Math.sin(Math.PI*.88)*length*.13-.004],.0009,m.stem);
      vein.castShadow=false;
    }
  }
}

const builders={'demo-table':table,'demo-chair':chair,'demo-sofa':sofa,'demo-pendant':pendant,'demo-floor-lamp':floorLamp,'demo-mirror':mirror,'demo-speaker':speaker,'demo-plant':plant};

export function createProduct(id,{suspension=.65,showSuspension=true,variant=0}={}){
  const spec=productCatalog.find(product=>product.id===id);
  if(!spec||!builders[id])throw new Error(`Unknown product: ${id}`);
  if(!Number.isFinite(suspension)||suspension<0)throw new Error('Suspension must be a nonnegative meter value');
  if(!Number.isInteger(variant)||variant<0)throw new Error('Variant must be a nonnegative integer');
  const root=new THREE.Group();root.name=spec.name;root.userData={productId:id,size:[...spec.size],finish:spec.finish};
  if(spec.wallMounted)root.userData.wallFrame={width:spec.size[0],height:spec.size[2],depth:spec.size[1]};
  const body=new THREE.Group();body.name='product body';root.add(body);const m=finishes();builders[id](body,m,{variant});
  body.updateMatrixWorld(true);const bounds=new THREE.Box3().setFromObject(body),size=bounds.getSize(new THREE.Vector3());
  if(![size.x,size.y,size.z].every(value=>Number.isFinite(value)&&value>0))throw new Error(`Invalid authored envelope: ${id}`);
  body.scale.set(spec.size[0]/size.x,spec.size[2]/size.y,spec.size[1]/size.z);
  body.position.set(-(bounds.min.x+bounds.max.x)/2*body.scale.x,-bounds.min.y*body.scale.y,-(bounds.min.z+bounds.max.z)/2*body.scale.z);
  if(spec.pendant){
    const hanging=new THREE.Group();hanging.name='adjustable suspension';hanging.visible=showSuspension;root.add(hanging);
    const top=spec.size[2];
    if(suspension>0)rod(hanging,'Pendant cord',[0,top,0],[0,top+suspension,0],.0025,m.dark);
    cylinder(hanging,'Pendant ceiling canopy',.04,.045,.018,[0,top+suspension+.009,0],m.terra,32);
  }
  const used=new Set();root.traverse(object=>{for(const material of Array.isArray(object.material)?object.material:object.material?[object.material]:[])used.add(material);});
  for(const material of Object.values(m))if(!used.has(material))material.dispose();
  if(![...used].some(material=>material.map))m.moss.map.dispose();
  root.updateMatrixWorld(true);return root;
}

export function disposeProduct(root){
  const geometries=new Set(),materials=new Set(),textures=new Set();
  root?.traverse(object=>{
    if(object.geometry)geometries.add(object.geometry);
    for(const material of Array.isArray(object.material)?object.material:object.material?[object.material]:[]){materials.add(material);for(const value of Object.values(material))if(value?.isTexture)textures.add(value);}
  });
  for(const geometry of geometries)geometry.dispose();for(const texture of textures)texture.dispose();for(const material of materials)material.dispose();
}
