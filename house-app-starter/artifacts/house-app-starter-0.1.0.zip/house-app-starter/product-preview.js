import * as T from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { productCatalog,createProduct,disposeProduct } from './product-library.js';
import {projectConfig} from './project-config.js';

document.title=`Furniture & lighting · ${projectConfig.title}`;
document.querySelector('.intro').textContent=`${productCatalog.length} pieces`;
const viewport=document.querySelector('#viewport');
const scene=new T.Scene();scene.background=null;
const renderer=new T.WebGLRenderer({antialias:true,alpha:true});renderer.setClearColor(0xffffff,0);renderer.setPixelRatio(Math.min(devicePixelRatio,2));
renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=.85;
renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFShadowMap;
renderer.domElement.setAttribute('aria-label','Interactive product model');viewport.appendChild(renderer.domElement);
const pmrem=new T.PMREMGenerator(renderer),room=new RoomEnvironment();scene.environment=pmrem.fromScene(room,.04).texture;scene.environmentIntensity=.55;room.dispose();pmrem.dispose();
const camera=new T.OrthographicCamera(-2,2,2,-2,.001,100);
const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.minZoom=.35;controls.maxZoom=7;
scene.add(new T.HemisphereLight('#fff9ef','#c0c4bf',.7));
const light=new T.DirectionalLight('#fff9f0',1.8);light.position.set(-3,6,4);light.castShadow=true;
light.shadow.mapSize.set(2048,2048);light.shadow.camera.left=-4;light.shadow.camera.right=4;light.shadow.camera.top=4;light.shadow.camera.bottom=-4;light.shadow.normalBias=.004;scene.add(light);
const floor=new T.Mesh(new T.PlaneGeometry(200,200),new T.ShadowMaterial({opacity:.12}));floor.rotation.x=-Math.PI/2;floor.position.y=-.002;floor.receiveShadow=true;scene.add(floor);
let current,selected,mode='perspective',halfHeight=1.5;
const catalog=document.querySelector('#catalog');
for(const p of productCatalog){const b=document.createElement('button');b.dataset.product=p.id;
  const label=document.createElement('strong');label.textContent=p.name;const brand=document.createElement('small');brand.textContent=p.brand+' · '+(p.pendant||p.lighting?'Lighting':'Furniture');b.append(label,brand);b.onclick=()=>select(p.id);catalog.appendChild(b);}
function rebuild(){
  if(current){scene.remove(current);disposeProduct(current);}
  current=createProduct(selected.id,{suspension:Number(document.querySelector('#drop').value),showSuspension:document.querySelector('#suspension').checked});scene.add(current);
  floor.visible=!selected.pendant&&!selected.wallMounted;frame();
}
function select(id){
  selected=productCatalog.find(p=>p.id===id);if(!selected)return;
  for(const key of ['brand','name','finish','notes'])document.getElementById(key).textContent=selected[key];
  const [w,d,h]=selected.size;document.querySelector('#dimensions').textContent=`${(w*100).toFixed(1)} W × ${(d*100).toFixed(1)} D × ${(h*100).toFixed(1)} H cm${selected.pendant?' · fixture only':''}`;
  const source=document.querySelector('#source');source.hidden=!selected.source;if(selected.source)source.href=selected.source;else source.removeAttribute('href');
  let selectedButton=null;document.querySelectorAll('[data-product]').forEach(b=>{const current=b.dataset.product===id;b.setAttribute('aria-current',String(current));if(current)selectedButton=b;});
  document.querySelector('#suspension').parentElement.hidden=!selected.pendant;document.querySelector('#drop-label').hidden=!selected.pendant;
  history.replaceState(null,'','#'+id);rebuild();requestAnimationFrame(()=>selectedButton?.scrollIntoView({block:'nearest',inline:'nearest'}));
}
function frame(){
  controls.enableDamping=false;camera.zoom=1;
  const b=new T.Box3().setFromObject(current.getObjectByName('product body'));
  if(selected.pendant&&document.querySelector('#suspension').checked)b.expandByObject(current.getObjectByName('adjustable suspension'));
  const center=b.getCenter(new T.Vector3()),size=b.getSize(new T.Vector3());
  const offsets={perspective:[-1.2,.8,1.5],front:[0,0,2],side:[2,0,0],top:[0,2,.0001]};
  camera.position.copy(center).add(new T.Vector3(...offsets[mode]).multiplyScalar(5));camera.up.set(0,1,0);controls.target.copy(center);
  // Reserve space above the object for the reference details, below for controls.
  const compactTouchLayout=window.matchMedia('(max-width: 760px), (max-height: 520px)').matches;
  const pendantScale=window.matchMedia('(max-height: 520px)').matches?1.32:1.28;
  halfHeight=Math.max(size.length()*.78,size.y*.85,.18)*(selected.pendant&&compactTouchLayout?pendantScale:1);controls.update();controls.enableDamping=true;
  document.querySelectorAll('[data-view]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.view===mode)));resize();
}
function resize(){const w=viewport.clientWidth,h=viewport.clientHeight,a=w/h,hh=halfHeight*Math.max(1,1/a),verticalShift=window.matchMedia('(max-width: 760px)').matches?0:window.matchMedia('(max-height: 520px)').matches?.06:.16;camera.left=-hh*a;camera.right=hh*a;camera.top=hh*(1+verticalShift);camera.bottom=-hh*(1-verticalShift);camera.updateProjectionMatrix();renderer.setSize(w,h,false);}
document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>{mode=b.dataset.view;frame();});
document.querySelector('#suspension').onchange=rebuild;
document.querySelector('#drop').oninput=e=>{document.querySelector('#drop-value').textContent=Math.round(e.target.value*100)+' cm';rebuild();};
new ResizeObserver(resize).observe(viewport);
select(productCatalog.some(p=>p.id===location.hash.slice(1))?location.hash.slice(1):productCatalog[0]?.id);
renderer.setAnimationLoop(()=>{controls.update();renderer.render(scene,camera);});

if(new URLSearchParams(location.search).has('inspect'))window.houseProductPreview={renderer,scene,camera,select,frame,get model(){return current;}};
