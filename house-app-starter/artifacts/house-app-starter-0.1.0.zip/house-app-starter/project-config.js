import demoBrief from './project/demo-brief.json' with {type:'json'};

// Display units are separate from scene units. Every size below is in meters.
export const projectConfig={
  schemaVersion:1,
  id:'courtyard-demo',
  title:'House Demo',
  description:'An example house with simple floor plan and interior design. Explore its layout, materials and furnishings. Send the starter pack and build prompt to your agent to create a visualization for your own house.',
  shareUrl:null,
  units:'cm',
  house:demoBrief.house,
  products:[
    {id:'demo-table',name:'Bridge Dining Table',brand:'Demo Studio',finish:'Warm wood',size:[1.6,.85,.74],source:'',notes:'Original fictional example: rounded top, tapered legs and an open apron.'},
    {id:'demo-chair',name:'Arc Dining Chair',brand:'Demo Studio',finish:'Warm wood · Woven seat',size:[.54,.57,.84],source:'',notes:'Original fictional example: curved back, shaped seat and tapered legs.'},
    {id:'demo-sofa',name:'Cloud Three-Seat Sofa',brand:'Demo Studio',finish:'Moss woven fabric',size:[2.15,.9,.8],source:'',notes:'Original fictional example: three separate seat/back cushions and rounded arms.'},
    {id:'demo-pendant',name:'Halo Pendant',brand:'Demo Studio',finish:'Terracotta · Warm diffuser',size:[.46,.46,.24],source:'',pendant:true,lighting:true,notes:'Original fictional example. Dimensions describe the fixture body; cord drop is separate.'},
    {id:'demo-floor-lamp',name:'Column Floor Lamp',brand:'Demo Studio',finish:'Satin metal · Cream shade',size:[.38,.38,1.55],source:'',floorLamp:true,lighting:true,notes:'Original fictional example: weighted base, slender stem and tapered linen shade.'},
    {id:'demo-mirror',name:'Round Wall Mirror',brand:'Demo Studio',finish:'Honey wood frame',size:[.75,.045,.75],source:'',wallMounted:true,notes:'Original fictional example: circular reflective face and rounded wood frame.'},
    {id:'demo-speaker',name:'Wave Table Speaker',brand:'Demo Studio',finish:'Cream · Charcoal grille',size:[.32,.16,.22],source:'',notes:'Original fictional example: twin driver grilles, top dial and playback indicator.'},
    {id:'demo-plant',name:'Leaf Indoor Plant',brand:'Demo Studio',finish:'Green foliage · Ceramic pot',size:[.65,.65,1.25],source:'',notes:'Original fictional example: branching stems, curved leaves and a rounded planter.'},
  ],
  materials:[
    {id:'demo-tile',name:'Sand Tile',usage:'Living · Kitchen flooring',assetKey:'tile',file:'materials/demo-tile.png',repeat:[.6,.6],color:'#ded6c6',roughness:.82},
    {id:'demo-stone',name:'Warm Stone',usage:'Island · Counter · Fireplace',assetKey:'stone',file:'materials/demo-stone.png',repeat:[1.1,.8],color:'#c7beac',roughness:.56},
    {id:'demo-wood',name:'Honey Wood',usage:'Cabinetry · Bedroom floor',assetKey:'wood',file:'materials/demo-wood.png',repeat:[.28,1.4],color:'#b28b5b',roughness:.64},
    {id:'demo-paint',name:'Chalk Paint',usage:'Interior walls',assetKey:'paint',file:'materials/demo-paint.png',repeat:[1,1],color:'#eeeae1',roughness:.9},
  ],
  media:{
    audio:[{title:'Quiet Shapes',artist:'Generated demo',file:'audio/demo-ambient.wav'}],
    tv:{day:'video/demo-day.mp4',night:'video/demo-night.mp4'},
    gallery:[
      {alt:'Original abstract study of a terracotta circle and sand arches'},
      {alt:'Original abstract study of pale green hills and a yellow sun'},
      {alt:'Original abstract study of blue columns and warm circles'},
      {alt:'Original abstract study of a dark green leaf and cream lines'},
      {alt:'Original abstract study of plum squares and a pink circle'},
      {alt:'Original abstract study of overlapping ochre and indigo arches'},
    ],
  },
};
