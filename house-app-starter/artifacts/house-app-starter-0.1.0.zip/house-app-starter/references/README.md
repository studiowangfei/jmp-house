# Neutral demo geometry references

- [Dimensioned plan](demo-plan.svg): six-corner outline, room names, furnishings,
  built-ins and feature targets; 10 × 8 m at wall centerlines, with 2.7 m ceilings.
- [Axon geometry image](demo-axon.png): offline CPU rendering of the actual
  `buildHouse` meshes, using approximate lighting and an open-ceiling cutaway.
- [Render evidence](render-evidence.json): source hashes, dimensions and methods.

These are geometry references. They do not depict the app UI or establish that
its browser interactions work. The CPU image uses material colors and procedural
texture data; media surfaces, image textures and real-time mirror reflections are
not evaluated. A supported browser is needed for the app's visual smoke checks.

Regenerate both references from the starter root:

```sh
node references/render-reference.mjs
```

The source is the fictional neutral demo brief and its authored scene. All
dimensions are meters. Furniture plan symbols show stated envelopes.
