// Portable geometry references. This renderer does not launch a browser or run the UI.
import * as T from 'three';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {deflateSync} from 'node:zlib';
import {buildHouse} from '../model.js';
import {projectConfig} from '../project-config.js';

const out=name=>new URL(name,import.meta.url),brief=JSON.parse(await readFile(new URL('../project/demo-brief.json',import.meta.url),'utf8'));
const sceneData=buildHouse(T,{project:projectConfig}),house=brief.house;
const xml=value=>String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const fixed=value=>Number(value).toFixed(2),scale=85,px=x=>180+(x+5)*scale,py=z=>280+(z+4)*scale;
const fragments=[];
const add=value=>fragments.push(value);
const text=(x,y,label,className='small',extra='')=>add(`<text x="${fixed(x)}" y="${fixed(y)}" class="${className}" ${extra}>${xml(label)}</text>`);
const polygon=points=>points.map(([x,z])=>`${fixed(px(x))},${fixed(py(z))}`).join(' ');
const localRect=(width,depth,color,rx=3,stroke='#8a877d')=>`<rect x="${fixed(-width*scale/2)}" y="${fixed(-depth*scale/2)}" width="${fixed(width*scale)}" height="${fixed(depth*scale)}" rx="${rx}" fill="${color}" stroke="${stroke}" stroke-width="1.3"/>`;
const at=(position,yaw,content)=>add(`<g transform="translate(${fixed(px(position[0]))} ${fixed(py(position[2]))}) rotate(${-(yaw||0)})">${content}</g>`);

add(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1450 1200" width="1450" height="1200" role="img" aria-labelledby="title description">
<title id="title">Neutral demo house dimensioned plan</title>
<desc id="description">A six-corner single-level demonstration house, 10 by 8 meters at wall centerlines with 2.7 meter ceilings, including living and kitchen, bedroom, bathroom, hall, furniture, cabinetry, gallery, speaker, mirror, pendant, floor lamp and outdoor tree.</desc>
<defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="4" refY="4" orient="auto-start-reverse"><path d="M0 0 L8 4 L0 8" fill="none" stroke="#636a63" stroke-width="1.2"/></marker></defs>
<style>text{font-family:Arial,Helvetica,sans-serif;fill:#354039}.title{font-size:38px;font-weight:600;letter-spacing:-.6px}.subtitle{font-size:19px;fill:#6f776d}.room{font-size:20px;font-weight:600;letter-spacing:.3px}.small{font-size:15px;fill:#6f776d}.label{font-size:13px;fill:#605f57}.measure{font-size:21px;font-weight:600;fill:#536057}.legend{font-size:16px}.number{font-size:12px;font-weight:700;fill:#fff;text-anchor:middle;dominant-baseline:central}.section{font-size:15px;font-weight:600;letter-spacing:1px;fill:#788176}</style>
<rect width="1450" height="1200" fill="#fbfaf6"/>`);
text(66,75,'Neutral demo house','title');
text(67,111,'Geometry reference · dimensioned plan','subtitle');
text(67,143,'Independently authored example · all scene dimensions in meters','small');
add('<line x1="66" y1="172" x2="1384" y2="172" stroke="#dedfd7"/>');

const floorColors={tile:'#f2eee3',wood:'#e7dcc6',stone:'#e4e3d5',paint:'#f7f3e9'};
for(const room of house.rooms)add(`<polygon points="${polygon(room.polygon)}" fill="${floorColors[room.material]||'#eeeade'}" stroke="#d3d1c6" stroke-width="1"/>`);
add(`<polygon points="${polygon(sceneData.layers.architecture.getObjectByName('Foundation').userData.perimeter)}" fill="none" stroke="#d2d3ca" stroke-width="1.5"/>`);
for(const wall of sceneData.wallSchedule)for(const object of wall.group.children.filter(child=>child.name==='wall surface')){
  const bounds=new T.Box3().setFromObject(object);
  add(`<rect x="${fixed(px(bounds.min.x))}" y="${fixed(py(bounds.min.z))}" width="${fixed((bounds.max.x-bounds.min.x)*scale)}" height="${fixed((bounds.max.z-bounds.min.z)*scale)}" fill="#585e55"/>`);
}
for(const glazing of sceneData.glazingGroups)for(const object of glazing.children.filter(child=>child.userData.glazing)){
  const bounds=new T.Box3().setFromObject(object);
  add(`<rect x="${fixed(px(bounds.min.x))}" y="${fixed(py(bounds.min.z))}" width="${fixed(Math.max(.025,bounds.max.x-bounds.min.x)*scale)}" height="${fixed(Math.max(.025,bounds.max.z-bounds.min.z)*scale)}" fill="#bdd2cf" stroke="#82a6a1" stroke-width="1.1"/>`);
}
for(const wall of sceneData.wallSchedule)for(const leaf of wall.group.children.flatMap(group=>group.children||[]).filter(child=>child.name==='Door leaf')){
  leaf.geometry.computeBoundingBox();const b=leaf.geometry.boundingBox;
  const points=[[b.min.x,b.min.z],[b.max.x,b.min.z],[b.max.x,b.max.z],[b.min.x,b.max.z]].map(([x,z])=>{
    const p=new T.Vector3(x,0,z).applyMatrix4(leaf.matrixWorld);return [p.x,p.z];
  });add(`<polygon points="${polygon(points)}" fill="#e5dac5" stroke="#9c9687" stroke-width="1"/>`);
}
for(const record of house.builtIns){
  const [width,depth]=record.size;let contents=localRect(width,depth,record.type==='bed'?'#f6f2e7':'#d5c5aa');
  if(record.type==='bed'){
    contents+=`<rect x="${fixed(-width*scale/2)}" y="${fixed(-depth*scale/2)}" width="${fixed(width*scale)}" height="8" fill="#bda47e"/>`;
    for(const side of [-1,1])contents+=`<rect x="${fixed((side*width*.24-width*.18)*scale)}" y="${fixed(-depth*.42*scale)}" width="${fixed(width*.36*scale)}" height="${fixed(.34*scale)}" rx="7" fill="#e9e3d3" stroke="#d3cdbd"/>`;
  }else if(['counter','vanity'].includes(record.type)){
    contents+=`<ellipse cx="${record.type==='counter'?fixed(-width*.24*scale):0}" cy="0" rx="${fixed(.20*scale)}" ry="${fixed(.15*scale)}" fill="#f4f1e9" stroke="#a8a89b"/>`;
    if(record.type==='counter')contents+=`<rect x="${fixed((width*.24-.215)*scale)}" y="${fixed(-.195*scale)}" width="${fixed(.43*scale)}" height="${fixed(.39*scale)}" rx="2" fill="#636c65"/>`;
  }else if(record.type==='shelf'){
    contents+=`<line x1="0" y1="${fixed(-depth*scale/2)}" x2="0" y2="${fixed(depth*scale/2)}" stroke="#a49070" stroke-width="2"/>`;
  }else if(record.type==='media'){
    contents+=`<rect x="${fixed(-.76*scale)}" y="${fixed(depth*scale/2-3)}" width="${fixed(1.52*scale)}" height="4" fill="#455c58"/>`;
  }else if(record.type==='toilet'){
    contents=localRect(width,depth,'#f1eee3',10)+`<ellipse cx="0" cy="${fixed(.06*scale)}" rx="${fixed(width*.38*scale)}" ry="${fixed(depth*.33*scale)}" fill="#fffdf7" stroke="#c3c6bb"/>`;
  }
  at(record.position,record.yaw,contents);
  if(record.type==='island')text(px(record.position[0]),py(record.position[2])+5,'Island','label','text-anchor="middle"');
}
for(const placement of house.placements){
  const spec=projectConfig.products.find(product=>product.id===placement.product),[width,depth]=spec.size;
  let contents='';
  if(placement.role==='mirror')contents=`<rect x="${fixed(-width*scale/2)}" y="${fixed(-depth*scale/2)}" width="${fixed(width*scale)}" height="${fixed(Math.max(depth,.035)*scale)}" fill="#b8cec4" stroke="#ad956f" stroke-width="2"/>`;
  else if(spec.id==='demo-pendant')contents=`<circle r="${fixed(width*scale/2)}" fill="none" stroke="#ae795b" stroke-width="1.8" stroke-dasharray="5 4"/><circle r="3" fill="#ae795b"/>`;
  else if(spec.id==='demo-floor-lamp')contents=`<circle r="${fixed(width*scale/2)}" fill="#ece2cc" stroke="#9b9687" stroke-width="1.4"/><circle r="3" fill="#8c9188"/>`;
  else if(spec.id==='demo-plant'){
    contents=`<circle r="${fixed(width*scale/2)}" fill="#d7e1cf" stroke="#8fa586"/>`;
    for(let index=0;index<5;index++)contents+=`<ellipse cy="${fixed(-width*.14*scale)}" rx="${fixed(width*.10*scale)}" ry="${fixed(width*.28*scale)}" fill="#8ba385" transform="rotate(${index*72})"/>`;
  }else{
    contents=localRect(width,depth,spec.id==='demo-sofa'?'#b2bda7':spec.id==='demo-speaker'?'#dce2d5':'#d9c8a9',spec.id==='demo-chair'?8:5);
    if(spec.id==='demo-sofa'){
      for(const x of [-width/6,width/6])contents+=`<line x1="${fixed(x*scale)}" x2="${fixed(x*scale)}" y1="${fixed(-depth*scale/2+10)}" y2="${fixed(depth*scale/2-8)}" stroke="#8f9e89"/>`;
      contents+=`<rect x="${fixed(-width*scale/2+5)}" y="${fixed(-depth*scale/2+4)}" width="${fixed(width*scale-10)}" height="11" rx="3" fill="#91a18b"/>`;
    }
    if(spec.id==='demo-chair')contents+=`<rect x="${fixed(-width*scale/2+5)}" y="${fixed(-depth*scale/2+2)}" width="${fixed(width*scale-10)}" height="5" rx="2" fill="#aa9471"/>`;
  }
  at(placement.position,placement.yaw,contents);
}
const gallery=sceneData.bindings.gallery;
for(const frame of gallery.frames){const bounds=new T.Box3().setFromObject(frame);add(`<rect x="${fixed(px(bounds.min.x))}" y="${fixed(py(bounds.min.z))}" width="${fixed((bounds.max.x-bounds.min.x)*scale)}" height="${fixed(Math.max(.035,bounds.max.z-bounds.min.z)*scale)}" fill="#c2a57b" stroke="#8a795f"/>`);}
for(const tree of house.landscape){
  const radius=tree.canopyRadius*scale;add(`<circle cx="${fixed(px(tree.position[0]))}" cy="${fixed(py(tree.position[2]))}" r="${fixed(radius)}" fill="#dfe7d4" stroke="#b8c9a8" stroke-width="1.5"/>`);
  for(const [dx,dz,r] of [[-.32,-.08,.65],[.30,.1,.68],[0,.28,.67]])add(`<circle cx="${fixed(px(tree.position[0]+dx))}" cy="${fixed(py(tree.position[2]+dz))}" r="${fixed(radius*r)}" fill="#bfceb3" opacity=".62"/>`);
  text(px(tree.position[0]),py(tree.position[2])+6,'Outdoor tree','label','text-anchor="middle"');
}
const markers=[
  {id:1,label:'Gallery · six wall frames',x:house.gallery.position[0],z:house.gallery.position[2]-.22},
  {id:2,label:'TV + fireplace cabinet',x:-3.45,z:.75},
  {id:3,label:'Speaker on cabinet',x:-4.28,z:1.04},
  {id:4,label:'Live wall mirror',x:-1.14,z:2.82},
  {id:5,label:'Open shelf · eight cells',x:.54,z:-2.32},
  {id:6,label:'Pendant above table',x:.33,z:.10},
  {id:7,label:'Bedroom floor lamp',x:4.08,z:-3.25},
  {id:8,label:'Indoor potted plant',x:-2.03,z:.30},
];
for(const marker of markers){add(`<circle cx="${fixed(px(marker.x))}" cy="${fixed(py(marker.z))}" r="11" fill="#667662" stroke="#fbfaf6" stroke-width="2"/>`);text(px(marker.x),py(marker.z),marker.id,'number');}
text(px(-3.4),py(-1.35),'Living','room','text-anchor="middle"');
text(px(-1.5),py(-2.88),'Kitchen','label','text-anchor="middle"');
text(px(-.1),py(1.42),'Dining','label','text-anchor="middle"');
text(px(3.4),py(-.10),'Bedroom','room','text-anchor="middle"');
text(px(4.16),py(2.7),'Bathroom','room','text-anchor="middle"');
text(px(2.16),py(3.1),'Hall','room','text-anchor="middle"');
text(px(-.05),py(3.37),'Entry','room','text-anchor="middle"');
add(`<g stroke="#879080" fill="none" stroke-width="1.2"><path d="M${px(-5)} ${py(-4)-14} V213 M${px(5)} ${py(-4)-14} V213"/><line x1="${px(-5)}" y1="222" x2="${px(5)}" y2="222" marker-start="url(#arrow)" marker-end="url(#arrow)"/><path d="M${px(5)+14} ${py(-4)} H1110 M${px(5)+14} ${py(4)} H1110"/><line x1="1100" y1="${py(-4)}" x2="1100" y2="${py(4)}" marker-start="url(#arrow)" marker-end="url(#arrow)"/></g>`);
text((px(-5)+px(5))/2,206,`${fixed(house.dimensions.width)} m`,'measure','text-anchor="middle"');
text(1126,(py(-4)+py(4))/2,`${fixed(house.dimensions.depth)} m`,'measure',`text-anchor="middle" transform="rotate(90 1126 ${(py(-4)+py(4))/2})"`);
text(1190,295,'SCENE TARGETS','section');
for(const [index,marker] of markers.entries()){
  const y=337+index*40;add(`<circle cx="1201" cy="${y-5}" r="11" fill="#667662"/>`);text(1201,y-5,marker.id,'number');text(1223,y,marker.label,'legend');
}
text(1190,702,'HOUSE INPUTS','section');
text(1190,739,`Ceiling ${fixed(house.ceilingHeight)} m`,'legend');
text(1190,770,`Walls ${fixed(house.wallThickness)} m`,'legend');
text(1190,801,'Single level · six corners','legend');
text(1190,832,'Dimension basis: centerlines','small');
text(1190,890,'PLAN SYMBOLS','section');
add('<rect x="1190" y="916" width="19" height="9" fill="#585e55"/>');text(1220,928,'Walls','small');
add('<rect x="1190" y="949" width="19" height="5" fill="#bdd2cf" stroke="#82a6a1"/>');text(1220,960,'Glazing','small');
add('<circle cx="1199" cy="986" r="10" fill="none" stroke="#ae795b" stroke-dasharray="4 3"/>');text(1220,992,'Overhead pendant','small');
add('<line x1="66" y1="1050" x2="1384" y2="1050" stroke="#dedfd7"/>');
text(67,1090,'Vector diagram from the neutral brief and buildHouse wall geometry. Furniture symbols show stated envelopes.','small');
text(67,1122,'This reference documents geometry; it does not depict the viewer UI or demonstrate browser interactions.','small');
text(67,1154,'Sources: project/demo-brief.json · model.js · project-config.js','small');
add('</svg>');await writeFile(out('demo-plan.svg'),fragments.join('\n'));

// Orthographic CPU rasterization of the actual authored triangle geometry.
// Materials use a simple light model. Browser shaders/reflections are not evaluated.
const FINAL_W=1280,FINAL_H=980,SUPER=2,W=FINAL_W*SUPER,H=FINAL_H*SUPER;
const scene=new T.Group();for(const layer of Object.values(sceneData.layers))scene.add(layer);
const direction=new T.Vector3(11,18,14).normalize(),sun=new T.Vector3(-.55,1.1,1.8).normalize(),half=direction.clone().add(sun).normalize();
const hiddenWalls=[];
for(const entry of sceneData.exterior)if(entry.normal.dot(direction)>.1){entry.group.visible=false;hiddenWalls.push(entry.group.name);}
const visible=object=>{for(let current=object;current;current=current.parent)if(current.visible===false)return false;return true;};
scene.updateMatrixWorld(true);
const bounds=new T.Box3().setFromObject(scene),center=bounds.getCenter(new T.Vector3()),camera=new T.OrthographicCamera(-1,1,1,-1,.01,100);
camera.position.copy(center).addScaledVector(direction,35);camera.lookAt(center);camera.updateMatrixWorld();
let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
scene.traverse(object=>{
  if(!object.isMesh||!visible(object)||object.material?.visible===false)return;
  const position=object.geometry.attributes.position;
  for(let index=0;index<position.count;index++){
    const point=new T.Vector3().fromBufferAttribute(position,index).applyMatrix4(object.matrixWorld).project(camera);
    minX=Math.min(minX,point.x);maxX=Math.max(maxX,point.x);minY=Math.min(minY,point.y);maxY=Math.max(maxY,point.y);
  }
});
const aspect=W/H,midX=(minX+maxX)/2,midY=(minY+maxY)/2,halfHeight=Math.max((maxY-minY)/2,(maxX-minX)/2/aspect)*1.11;
camera.left=midX-halfHeight*aspect;camera.right=midX+halfHeight*aspect;camera.bottom=midY-halfHeight;camera.top=midY+halfHeight;camera.updateProjectionMatrix();
const pixels=new Float32Array(W*H*3).fill(1),depth=new Float32Array(W*H).fill(Infinity),transparent=[];
const srgbToLinear=value=>value<=.04045?value/12.92:((value+.055)/1.055)**2.4;
const linearToSrgb=value=>255*(value<=.0031308?value*12.92:1.055*value**(1/2.4)-.055);
let meshCount=0,triangleCount=0;
function paint(a,b,c,material,base,source,alpha=1){
  const determinant=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);if(Math.abs(determinant)<1e-8)return;
  const minX=Math.max(0,Math.floor(Math.min(a.x,b.x,c.x))),maxX=Math.min(W-1,Math.ceil(Math.max(a.x,b.x,c.x))),minY=Math.max(0,Math.floor(Math.min(a.y,b.y,c.y))),maxY=Math.min(H-1,Math.ceil(Math.max(a.y,b.y,c.y)));
  for(let y=minY;y<=maxY;y++)for(let x=minX;x<=maxX;x++){
    const wa=((b.y-c.y)*(x+.5-c.x)+(c.x-b.x)*(y+.5-c.y))/determinant,wb=((c.y-a.y)*(x+.5-c.x)+(a.x-c.x)*(y+.5-c.y))/determinant,wc=1-wa-wb;
    if(Math.min(wa,wb,wc)<-1e-7)continue;
    const z=wa*a.z+wb*b.z+wc*c.z,pixel=y*W+x;if(z>=depth[pixel])continue;if(alpha>=.99)depth[pixel]=z;
    let nx=a.n.x*wa+b.n.x*wb+c.n.x*wc,ny=a.n.y*wa+b.n.y*wb+c.n.y*wc,nz=a.n.z*wa+b.n.z*wb+c.n.z*wc;
    const length=Math.hypot(nx,ny,nz)||1;nx/=length;ny/=length;nz/=length;
    if(material.side===T.DoubleSide&&nx*direction.x+ny*direction.y+nz*direction.z<0){nx=-nx;ny=-ny;nz=-nz;}
    const lighting=.38+.57*Math.max(0,nx*sun.x+ny*sun.y+nz*sun.z)+.09*Math.max(0,ny),specular=.025*Math.max(0,nx*half.x+ny*half.y+nz*half.z)**16,offset=pixel*3;
    let texture=[1,1,1];
    if(source?.data){
      const repeat=material.map?.repeat||{x:1,y:1},u=(a.uv[0]*wa+b.uv[0]*wb+c.uv[0]*wc)*repeat.x,v=(a.uv[1]*wa+b.uv[1]*wb+c.uv[1]*wc)*repeat.y;
      const tx=Math.floor(((u%1+1)%1)*(source.width-1)),ty=Math.floor(((v%1+1)%1)*(source.height-1)),at=(ty*source.width+tx)*4;
      texture=[0,1,2].map(channel=>srgbToLinear(source.data[at+channel]/255));
    }
    for(let channel=0;channel<3;channel++)pixels[offset+channel]=Math.min(1,base[channel]*lighting*texture[channel]+specular)*alpha+pixels[offset+channel]*(1-alpha);
  }
}
scene.traverse(object=>{
  if(!object.isMesh||!visible(object))return;
  const geometry=object.geometry,{position,normal,uv}=geometry.attributes,index=geometry.index,material=Array.isArray(object.material)?object.material[0]:object.material;
  if(!material||material.visible===false)return;meshCount++;
  const normalMatrix=new T.Matrix3().getNormalMatrix(object.matrixWorld),points=[];
  for(let vertex=0;vertex<position.count;vertex++){
    const world=new T.Vector3().fromBufferAttribute(position,vertex).applyMatrix4(object.matrixWorld),point=world.project(camera),n=normal?new T.Vector3().fromBufferAttribute(normal,vertex).applyNormalMatrix(normalMatrix):new T.Vector3(0,1,0);
    points.push({x:(point.x+1)*W/2,y:(1-point.y)*H/2,z:point.z,n,uv:uv?[uv.getX(vertex),uv.getY(vertex)]:[0,0]});
  }
  const color=object.isReflector?new T.Color('#d7dfd8'):material.color||new T.Color('#f3eee4'),base=[color.r,color.g,color.b],source=material.map?.image,count=index?index.count:position.count;
  for(let vertex=0;vertex<count;vertex+=3){
    const a=points[index?index.getX(vertex):vertex],b=points[index?index.getX(vertex+1):vertex+1],c=points[index?index.getX(vertex+2):vertex+2],facing=a.n.clone().add(b.n).add(c.n).dot(direction);
    if(material.side===T.FrontSide&&facing<=0||material.side===T.BackSide&&facing>=0)continue;triangleCount++;
    if(material.transparent&&material.opacity<.99)transparent.push({a,b,c,material,base,source,alpha:material.opacity,depth:(a.z+b.z+c.z)/3});
    else paint(a,b,c,material,base,source);
  }
});
transparent.sort((a,b)=>b.depth-a.depth);for(const triangle of transparent)paint(triangle.a,triangle.b,triangle.c,triangle.material,triangle.base,triangle.source,triangle.alpha);
const image=Buffer.alloc(FINAL_W*FINAL_H*3);
for(let y=0;y<FINAL_H;y++)for(let x=0;x<FINAL_W;x++)for(let channel=0;channel<3;channel++){
  let total=0;for(let sy=0;sy<SUPER;sy++)for(let sx=0;sx<SUPER;sx++)total+=pixels[(((y*SUPER+sy)*W)+x*SUPER+sx)*3+channel];
  image[(y*FINAL_W+x)*3+channel]=Math.round(Math.max(0,Math.min(255,linearToSrgb(total/(SUPER*SUPER)))));
}
const crcTable=Uint32Array.from({length:256},(_,value)=>{let c=value;for(let bit=0;bit<8;bit++)c=c&1?0xedb88320^(c>>>1):c>>>1;return c>>>0;});
const crc=data=>{let c=0xffffffff;for(const byte of data)c=crcTable[(c^byte)&255]^(c>>>8);return (c^0xffffffff)>>>0;};
function chunk(name,data){const type=Buffer.from(name),joined=Buffer.concat([type,data]),length=Buffer.alloc(4),checksum=Buffer.alloc(4);length.writeUInt32BE(data.length);checksum.writeUInt32BE(crc(joined));return Buffer.concat([length,joined,checksum]);}
const header=Buffer.alloc(13);header.writeUInt32BE(FINAL_W,0);header.writeUInt32BE(FINAL_H,4);header[8]=8;header[9]=2;
const scan=Buffer.alloc((FINAL_W*3+1)*FINAL_H);for(let y=0;y<FINAL_H;y++)image.copy(scan,y*(FINAL_W*3+1)+1,y*FINAL_W*3,(y+1)*FINAL_W*3);
await writeFile(out('demo-axon.png'),Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',header),chunk('IDAT',deflateSync(scan,{level:9})),chunk('IEND',Buffer.alloc(0))]));
const inputs=[];for(const file of ['project/demo-brief.json','model.js','project-config.js'])inputs.push({file,sha256:createHash('sha256').update(await readFile(new URL('../'+file,import.meta.url))).digest('hex')});
await writeFile(out('render-evidence.json'),JSON.stringify({schemaVersion:1,inputs,plan:{file:'demo-plan.svg',method:'SVG diagram using the neutral input brief and actual buildHouse wall surfaces',width:1450,height:1200},axon:{file:'demo-axon.png',method:'Offline CPU rasterization of actual buildHouse triangle geometry with approximate lighting',width:FINAL_W,height:FINAL_H,meshes:meshCount,triangles:triangleCount,hiddenExteriorWalls:hiddenWalls,limitations:['Viewer UI was not executed','Image textures/media and real-time mirror reflections are not evaluated','This image does not verify browser interactions or WebGL output']}},null,2)+'\n');
console.log(JSON.stringify({plan:'references/demo-plan.svg',axon:'references/demo-axon.png',evidence:'references/render-evidence.json',meshes:meshCount,triangles:triangleCount},null,2));
