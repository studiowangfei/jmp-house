export function collectInteractionTargets(root){
  const meshes=[],photos=[];
  root.traverse(object=>{
    if(!object.isMesh)return;
    if(['gallery','audio','fireplace'].includes(object.userData.interaction))meshes.push(object);
    if(object.userData.galleryPhoto)photos.push(object);
  });
  return{meshes,photos};
}

export function galleryPhotoForHit(hitTarget){
  return hitTarget?.parent?.children.find(object=>object.userData.galleryPhoto)||null;
}
