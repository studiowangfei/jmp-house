const EPSILON=1e-8;

export function polygonArea(points){
  return points.reduce((sum,point,index)=>{
    const next=points[(index+1)%points.length];
    return sum+point[0]*next[1]-next[0]*point[1];
  },0)/2;
}

export function pointInPolygon(x,z,points,includeBoundary=false){
  let inside=false;
  for(let index=0,previous=points.length-1;index<points.length;previous=index++){
    const a=points[previous],b=points[index];
    if(includeBoundary){
      const cross=(x-a[0])*(b[1]-a[1])-(z-a[1])*(b[0]-a[0]);
      if(Math.abs(cross)<EPSILON&&x>=Math.min(a[0],b[0])-EPSILON&&x<=Math.max(a[0],b[0])+EPSILON&&z>=Math.min(a[1],b[1])-EPSILON&&z<=Math.max(a[1],b[1])+EPSILON)return true;
    }
    if((a[1]>z)!==(b[1]>z)&&x<(b[0]-a[0])*(z-a[1])/(b[1]-a[1])+a[0])inside=!inside;
  }
  return inside;
}

function validPoint(point){return Array.isArray(point)&&point.length===2&&point.every(Number.isFinite);}
function fail(message){throw new Error(`Invalid house input: ${message}`);}

function segmentsIntersect(a,b,c,d){
  const horizontalA=Math.abs(a[1]-b[1])<EPSILON,horizontalB=Math.abs(c[1]-d[1])<EPSILON;
  if(horizontalA===horizontalB){
    const fixedAxis=horizontalA?1:0,axis=1-fixedAxis;
    return Math.abs(a[fixedAxis]-c[fixedAxis])<EPSILON&&Math.max(Math.min(a[axis],b[axis]),Math.min(c[axis],d[axis]))<=Math.min(Math.max(a[axis],b[axis]),Math.max(c[axis],d[axis]))+EPSILON;
  }
  const [h1,h2,v1,v2]=horizontalA?[a,b,c,d]:[c,d,a,b];
  return v1[0]>=Math.min(h1[0],h2[0])-EPSILON&&v1[0]<=Math.max(h1[0],h2[0])+EPSILON&&h1[1]>=Math.min(v1[1],v2[1])-EPSILON&&h1[1]<=Math.max(v1[1],v2[1])+EPSILON;
}

function validatePolygon(points,label){
  if(!Array.isArray(points)||points.length<4||points.some(point=>!validPoint(point)))fail(`${label} must contain at least four finite X/Z points`);
  if(Math.abs(polygonArea(points))<EPSILON)fail(`${label} has zero area`);
  for(let index=0;index<points.length;index++){
    const a=points[index],b=points[(index+1)%points.length],dx=b[0]-a[0],dz=b[1]-a[1];
    if(Math.hypot(dx,dz)<EPSILON||(Math.abs(dx)>EPSILON&&Math.abs(dz)>EPSILON))fail(`${label} must have nonzero orthogonal edges`);
    for(let other=index+2;other<points.length;other++){
      if(index===0&&other===points.length-1)continue;
      if(segmentsIntersect(a,b,points[other],points[(other+1)%points.length]))fail(`${label} intersects itself`);
    }
  }
}

export function validateHouseInput(house){
  if(!house||typeof house!=='object')fail('house records are required');
  if(!Number.isFinite(house.floorLevel??0))fail('floorLevel must be finite');
  if(!Number.isFinite(house.ceilingHeight)||house.ceilingHeight<=0)fail('ceilingHeight must be positive');
  if(!Number.isFinite(house.wallThickness)||house.wallThickness<=0)fail('wallThickness must be positive');
  validatePolygon(house.footprint,'footprint');
  if(polygonArea(house.footprint)<0)fail('footprint vertices must run counterclockwise in X/Z');
  if(house.dimensions){
    for(const [name,axis] of [['width',0],['depth',1]]){
      const value=house.dimensions[name];if(value===undefined)continue;
      const span=Math.max(...house.footprint.map(point=>point[axis]))-Math.min(...house.footprint.map(point=>point[axis]));
      if(!Number.isFinite(value)||value<=0||Math.abs(value-span)>1e-5)fail(`${name} conflicts with the footprint's wall-centerline span`);
    }
  }
  if(!Array.isArray(house.exteriorWalls)||house.exteriorWalls.length!==house.footprint.length)fail('each perimeter edge requires an exteriorWalls record');
  const ids=new Set(),walls=new Map();
  const validateWall=(record,a,b)=>{
    if(!record?.id||ids.has(record.id))fail('wall IDs must be present and unique');
    ids.add(record.id);
    if(!validPoint(a)||!validPoint(b)||(Math.abs(a[0]-b[0])>EPSILON&&Math.abs(a[1]-b[1])>EPSILON))fail(`${record.id} must have orthogonal finite endpoints`);
    const length=Math.hypot(b[0]-a[0],b[1]-a[1]);
    if(length<EPSILON)fail(`${record.id} has no length`);
    const thickness=record.thickness??house.wallThickness;
    if(!Number.isFinite(thickness)||thickness<=0)fail(`${record.id} must have a positive wall thickness`);
    walls.set(record.id,{a,b,thickness});
    const openings=[...(record.openings||[])].sort((left,right)=>left.from-right.from);
    let end=0;
    for(const opening of openings){
      const sill=opening.sill??0;
      if(![opening.from,opening.to,sill,opening.height].every(Number.isFinite)||opening.from<end-EPSILON||opening.to<=opening.from||opening.to>length+EPSILON||sill<0||opening.height<=0||sill+opening.height>house.ceilingHeight+EPSILON)fail(`${record.id} has an invalid or overlapping opening`);
      if(!['window','door','passage'].includes(opening.type))fail(`${record.id} has an unsupported opening type`);
      end=opening.to;
    }
  };
  house.exteriorWalls.forEach((record,index)=>validateWall(record,house.footprint[index],house.footprint[(index+1)%house.footprint.length]));
  for(const record of house.partitions||[])validateWall(record,record.a,record.b);
  const validateWallMount=(bounds,hostWall,label)=>{
    const wall=walls.get(hostWall);if(!wall)fail(`${label} refers to an unknown host wall`);
    if(!bounds||!['x','z'].includes(bounds.axis))fail(`${label} needs wallBounds with a fixed normal axis`);
    const normalAxis=Math.abs(wall.b[0]-wall.a[0])<EPSILON?'x':'z';
    if(bounds.axis!==normalAxis)fail(`${label} wallBounds.axis must match its host wall's fixed normal axis ${normalAxis}`);
    const normalIndex=normalAxis==='x'?0:1,tangentIndex=1-normalIndex,normalLetter=normalAxis.toUpperCase(),tangentLetter=normalAxis==='x'?'Z':'X',plane=bounds[`plane${normalLetter}`];
    // Mounting planes sit just in front of a wall surface. The allowance covers
    // shallow product frames; an unrelated plane cannot be used as a wall host.
    if(!Number.isFinite(plane)||Math.abs(plane-wall.a[normalIndex])>wall.thickness/2+.15)fail(`${label} mounting plane is not near its host wall`);
    for(const letter of ['X','Y','Z'])if(!Number.isFinite(bounds[`min${letter}`])||!Number.isFinite(bounds[`max${letter}`])||bounds[`min${letter}`]>bounds[`max${letter}`])fail(`${label} wall bounds must be finite and ordered`);
    if(plane<bounds[`min${normalLetter}`]-EPSILON||plane>bounds[`max${normalLetter}`]+EPSILON)fail(`${label} mounting plane lies outside its normal bounds`);
    if(bounds[`min${tangentLetter}`]<Math.min(wall.a[tangentIndex],wall.b[tangentIndex])-EPSILON||bounds[`max${tangentLetter}`]>Math.max(wall.a[tangentIndex],wall.b[tangentIndex])+EPSILON)fail(`${label} tangent bounds lie outside its host wall`);
    if(bounds.minY<0||bounds.maxY>house.ceilingHeight+EPSILON)fail(`${label} vertical bounds lie outside its host wall`);
  };
  if(!Array.isArray(house.rooms)||!house.rooms.length)fail('room floor regions are required');
  for(const room of house.rooms)validatePolygon(room.polygon,`room ${room.id||''}`);
  // Every orthogonal intersection boundary occurs at a supplied X or Z value.
  // Checking each resulting cell establishes exact coverage without raster tolerance.
  const polygons=[house.footprint,...house.rooms.map(room=>room.polygon)],xs=[...new Set(polygons.flatMap(polygon=>polygon.map(point=>point[0])))].sort((a,b)=>a-b),zs=[...new Set(polygons.flatMap(polygon=>polygon.map(point=>point[1])))].sort((a,b)=>a-b);
  for(let xi=0;xi<xs.length-1;xi++)for(let zi=0;zi<zs.length-1;zi++){
    const x=(xs[xi]+xs[xi+1])/2,z=(zs[zi]+zs[zi+1])/2,inside=pointInPolygon(x,z,house.footprint),cover=house.rooms.filter(room=>pointInPolygon(x,z,room.polygon)).length;
    if(inside&&cover!==1)fail(cover?'room floor regions overlap':'room floor regions leave a gap');
    if(!inside&&cover)fail('room floor regions extend outside the footprint');
  }
  const movableIds=new Set();
  for(const placement of house.placements||[]){
    if(!placement.id||movableIds.has(placement.id))fail('placed items require unique IDs');
    movableIds.add(placement.id);
    if(!Array.isArray(placement.position)||placement.position.length!==3||placement.position.some(value=>!Number.isFinite(value)))fail(`${placement.id} needs a finite meter position`);
    if(placement.yaw!==undefined&&!Number.isFinite(placement.yaw))fail(`${placement.id} needs a finite angle in degrees`);
    if(!['floor','surface','wall'].includes(placement.constraint))fail(`${placement.id} has an unsupported movement constraint`);
    if(placement.hostWall&&!ids.has(placement.hostWall))fail(`${placement.id} refers to an unknown wall`);
    if(placement.constraint==='wall')validateWallMount(placement.wallBounds,placement.hostWall,placement.id);
  }
  if(house.gallery)validateWallMount(house.gallery.wallBounds,house.gallery.hostWall,'gallery');
  return house;
}

export function offsetOrthogonalFootprint(points,distance){
  const outward=points.map((point,index)=>{
    const next=points[(index+1)%points.length],dx=next[0]-point[0],dz=next[1]-point[1],length=Math.hypot(dx,dz);
    return [dz/length,-dx/length];
  });
  return points.map((point,index)=>{
    const previous=outward[(index+points.length-1)%points.length],next=outward[index];
    return [point[0]+distance*(previous[0]+next[0]),point[1]+distance*(previous[1]+next[1])];
  });
}
