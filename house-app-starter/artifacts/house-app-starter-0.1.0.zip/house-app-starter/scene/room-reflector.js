import {Matrix4,Plane,Vector3,Vector4} from 'three';
import {Reflector} from 'three/addons/objects/Reflector.js';

// Replace the near row using the actual projection, including orthographic
// zoom/view offsets. Tolerance is a physical distance from the mirror plane.
export function clipReflectionCamera(camera,sourceProjection,worldPlane,clipOffset=.0001){
  if(!Number.isFinite(clipOffset)||clipOffset<0||clipOffset>.005)throw new RangeError('Mirror clip offset must be between zero and .005 meters');
  camera.projectionMatrix.copy(sourceProjection);
  const plane=worldPlane.clone().normalize();plane.constant+=clipOffset;
  plane.applyMatrix4(camera.matrixWorldInverse);
  const coefficients=new Vector4(plane.normal.x,plane.normal.y,plane.normal.z,plane.constant);
  const inverse=new Matrix4().copy(sourceProjection).invert();
  const farCorner=new Vector4(Math.sign(coefficients.x),Math.sign(coefficients.y),1,1).applyMatrix4(inverse);
  const denominator=coefficients.dot(farCorner);
  if(!Number.isFinite(denominator)||denominator<=1e-10)return false;
  coefficients.multiplyScalar(2/denominator);
  const projection=camera.projectionMatrix.elements;
  projection[2]=coefficients.x-projection[3];
  projection[6]=coefficients.y-projection[7];
  projection[10]=coefficients.z-projection[11];
  projection[14]=coefficients.w-projection[15];
  camera.projectionMatrixInverse.copy(camera.projectionMatrix).invert();
  return true;
}

export function createRoomReflector(geometry,{wallGroups=[],clipOffset=.0001,...options}={}){
  if(!Number.isFinite(clipOffset)||clipOffset<0||clipOffset>.005)throw new RangeError('Mirror clip offset must be between zero and .005 meters');
  // Retain Three's camera reflection, shader and target; replace its biased
  // near-plane calculation immediately before the reflected scene is drawn.
  const mirror=new Reflector(geometry,{...options,clipBias:0});
  const renderMirror=mirror.onBeforeRender;
  mirror.userData={reflectionClipping:'world-plane',clipOffsetMeters:clipOffset};
  mirror.onBeforeRender=function(renderer,scene,camera){
    const saved={target:renderer.getRenderTarget(),xr:renderer.xr.enabled,autoShadow:renderer.shadowMap.autoUpdate,shadowUpdate:renderer.shadowMap.needsUpdate,visible:this.visible};
    const point=new Vector3().setFromMatrixPosition(this.matrixWorld),normal=new Vector3(0,0,1).transformDirection(this.matrixWorld);
    const plane=new Plane().setFromNormalAndCoplanarPoint(normal,point);
    const drawReflection=(reflectedScene,reflectedCamera)=>{
      if(!clipReflectionCamera(reflectedCamera,camera.projectionMatrix,plane,clipOffset))return;
      const walls=wallGroups.map(group=>({group,visible:group.visible}));
      const shadowUpdate=renderer.shadowMap.needsUpdate;
      try{
        // Cutaway affects the primary view. Physical walls still occlude the
        // reflected scene; their real window/door openings remain intact.
        for(const {group} of walls)group.visible=true;
        renderer.shadowMap.needsUpdate=false;
        renderer.render(reflectedScene,reflectedCamera);
      }finally{
        for(const {group,visible} of walls)group.visible=visible;
        renderer.shadowMap.needsUpdate=shadowUpdate;
      }
    };
    // An adapter avoids modifying renderer.render during nested reflections.
    const reflectionRenderer=new Proxy(renderer,{get(target,key){
      if(key==='render')return drawReflection;
      const value=Reflect.get(target,key,target);return typeof value==='function'?value.bind(target):value;
    }});
    try{return renderMirror.call(this,reflectionRenderer,scene,camera);}
    finally{
      this.visible=saved.visible;
      renderer.xr.enabled=saved.xr;renderer.shadowMap.autoUpdate=saved.autoShadow;renderer.shadowMap.needsUpdate=saved.shadowUpdate;
      renderer.setRenderTarget(saved.target);
      if(camera.viewport!==undefined)renderer.state.viewport(camera.viewport);
    }
  };
  return mirror;
}
