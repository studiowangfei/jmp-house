#!/usr/bin/env python3
"""Create a verified deployment, optionally including a shareable starter pack."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import stat
import tempfile
import uuid
import zipfile
from verify_deployment_support import verify, MANIFEST_PATH

ROOT = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, default=ROOT / 'dist')
downloads = parser.add_mutually_exclusive_group()
downloads.add_argument('--with-starter-pack', action='store_true', help='Package this prepared neutral starter and include it with its build prompt')
downloads.add_argument('--starter-pack', type=Path, help='Include a supplied frozen starter ZIP and its embedded prompt; leaves personal project source out of the public download')
args = parser.parse_args()
requested = args.output if args.output.is_absolute() else ROOT / args.output
if requested.is_symlink():
    raise SystemExit('Refusing to replace symlink output')
output = requested.resolve()
if output == ROOT or output in ROOT.parents:
    raise SystemExit('Refusing to replace source, parent or symlink output')
if output.exists() and not any((output / name).is_file() for name in (MANIFEST_PATH, 'build-manifest.json')):
    raise SystemExit('Output exists without a recognized deployment manifest')
verify(ROOT)
manifest = json.loads((ROOT / MANIFEST_PATH).read_text())
output.parent.mkdir(parents=True, exist_ok=True)
stage = Path(tempfile.mkdtemp(prefix='.house-deploy-', dir=output.parent))
backup = output.parent / ('.house-backup-' + uuid.uuid4().hex)
try:
    for relative in [*manifest['files'], MANIFEST_PATH]:
        target = stage / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / relative, target)
    if args.with_starter_pack or args.starter_pack:
        download_dir = stage / 'downloads'
        download_dir.mkdir()
        spec = importlib.util.spec_from_file_location('house_source_packager', ROOT / 'scripts' / 'package-starter.py')
        packager = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(packager)
        if args.with_starter_pack:
            source_archive = download_dir / f'house-app-starter-{packager.VERSION}.zip'
            # The outgoing deployment may be stale while its replacement is built.
            # Source freshness and staged verification remain mandatory.
            packager.package_starter(ROOT, source_archive, check_deployment=False)
        else:
            source_archive = args.starter_pack if args.starter_pack.is_absolute() else ROOT / args.starter_pack
        with zipfile.ZipFile(source_archive) as archive:
            prefix = 'house-app-starter/'
            if len(archive.namelist()) != len(set(archive.namelist())) or any(stat.S_ISLNK(entry.external_attr >> 16) for entry in archive.infolist()):
                raise ValueError('Starter archive contains duplicate or linked files')
            starter = json.loads(archive.read(prefix + 'starter-manifest.json'))
            version = starter.get('version')
            if starter.get('schemaVersion') != 1 or starter.get('name') != 'house-app-starter' or not isinstance(version, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*', version):
                raise ValueError('Invalid starter archive/version')
            if any('node_modules' in Path(name).parts or 'downloads' in Path(name).parts for name in archive.namelist()):
                raise ValueError('Starter archive contains dependencies or nested release downloads')
            files = starter.get('files')
            if not isinstance(files, dict) or not files:
                raise ValueError('Invalid starter archive source inventory')
            legacy = 'build-manifest.json' in files and MANIFEST_PATH not in files
            prompt_path = 'BUILD_PROMPT.txt'
            if legacy and prompt_path not in files and 'BUILD_PROMPT.md' in files:
                prompt_path = 'BUILD_PROMPT.md'
            expected_entries = {prefix + 'starter-manifest.json'} | {prefix + relative for relative in files}
            if set(archive.namelist()) != expected_entries or prompt_path not in files:
                raise ValueError('Starter archive contains unexpected or missing source files')
            # The old flat layout remains valid only for a supplied frozen
            # archive; newly generated source packs always use src/runtime.
            allowed_path = packager.allowed_legacy_path if legacy else packager.allowed_path
            for relative, expected in files.items():
                if not allowed_path(Path(relative)):
                    raise ValueError(f'Starter archive contains an excluded source file: {relative}')
                data = archive.read(prefix + relative)
                if len(data) != expected['bytes'] or hashlib.sha256(data).hexdigest() != expected['sha256']:
                    raise ValueError(f'Changed starter archive file: {relative}')
            prompt = archive.read(prefix + prompt_path)
            if prompt_path == 'BUILD_PROMPT.md':
                # Early frozen starters stored the copyable prompt in a fenced
                # text block. Preserve that block without its Markdown wrapper.
                block = re.search(r'(?m)^```text[ \t]*\r?\n(.*?)\r?\n```[ \t]*(?:\r?\n|$)', prompt.decode('utf-8'), re.S)
                if not block:
                    raise ValueError('Legacy starter Markdown lacks its fenced build prompt')
                prompt = (block.group(1).rstrip('\r\n') + '\n').encode('utf-8')
        deployed_archive = download_dir / f'house-app-starter-{version}.zip'
        if source_archive.resolve() != deployed_archive.resolve():
            shutil.copy2(source_archive, deployed_archive)
        (download_dir / 'BUILD_PROMPT.txt').write_bytes(prompt)
        download_files = {}
        for file in [deployed_archive, download_dir / 'BUILD_PROMPT.txt']:
            data = file.read_bytes()
            download_files[file.relative_to(stage).as_posix()] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        (stage / 'downloads-manifest.json').write_text(json.dumps({
            'schemaVersion': 1,
            'starterVersion': version,
            'buildManifestSha256': hashlib.sha256((stage / MANIFEST_PATH).read_bytes()).hexdigest(),
            'files': download_files,
        }, indent=2, sort_keys=True) + '\n')
    verify(stage, deployed=True)
    if output.exists():
        output.rename(backup)
    try:
        stage.rename(output)
    except BaseException:
        if backup.exists():
            backup.rename(output)
        raise
    if backup.exists():
        shutil.rmtree(backup)
finally:
    if stage.exists():
        shutil.rmtree(stage)
print(f'Created verified deployment: {output}')
if args.with_starter_pack or args.starter_pack:
    print(f'Starter download: downloads/house-app-starter-{version}.zip')
    print('Build prompt: downloads/BUILD_PROMPT.txt')
