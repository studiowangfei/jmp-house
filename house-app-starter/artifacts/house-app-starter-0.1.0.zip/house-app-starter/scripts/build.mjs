import {build} from 'esbuild';
import {readFile,writeFile,stat,mkdir,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {projectConfig} from '../src/project-config.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const manifestPath='runtime/build-manifest.json',productsOnly=process.argv.includes('--products');
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
const packageInfo=JSON.parse(await readFile(path.join(root,'package.json'),'utf8'));
const fingerprint=async name=>{
  if(typeof name!=='string'||path.isAbsolute(name)||name.includes('\\')||name.includes(':')||name.split('/').some(part=>!part||part==='..'))throw new Error('Asset must be relative to this project: '+name);
  const bytes=await readFile(path.join(root,name));return{bytes:bytes.length,sha256:digest(bytes)};
};
let priorInputs={};
if(productsOnly){
  try{await stat(path.join(root,'runtime/app.bundle.js'));priorInputs=JSON.parse(await readFile(path.join(root,manifestPath),'utf8')).inputs||{};}
  catch{throw new Error('Build the complete demo once with npm run build before rebuilding only products.');}
}
await mkdir(path.join(root,'runtime'),{recursive:true});
const entries=productsOnly?['src/product-preview.js']:['src/app.js','src/product-preview.js'];
const inputs=new Set(['scripts/build.mjs','src/project-config.js','package.json','package-lock.json','src/styles.css','src/products.css','src/products.html']);
for(const entry of entries){
  const outfile=entry==='src/app.js'?'runtime/app.bundle.js':'runtime/products.bundle.js';
  const result=await build({absWorkingDir:root,entryPoints:[entry],outfile,bundle:true,minify:true,format:'iife',target:'es2020',loader:{'.jpg':'dataurl','.jpeg':'dataurl','.png':'dataurl','.webp':'dataurl','.svg':'dataurl'},metafile:true,logLevel:'warning'});
  Object.keys(result.metafile.inputs).filter(name=>!name.startsWith('node_modules/')).forEach(name=>inputs.add(name));
}
for(const name of ['runtime/app.bundle.js','runtime/products.bundle.js'])await stat(path.join(root,name));
await copyFile(path.join(root,'src/styles.css'),path.join(root,'runtime/styles.css'));
await copyFile(path.join(root,'src/products.css'),path.join(root,'runtime/products.css'));

async function stampHtml(text,html,assets){
  const replacements=new Map();
  for(const asset of assets){
    const relative=path.posix.relative(path.posix.dirname(html),asset),url=relative.startsWith('.')?relative:'./'+relative,hash=(await fingerprint(asset)).sha256.slice(0,16);
    replacements.set(asset,{relative,url,hash,seen:false});
  }
  text=text.replace(/((?:src|href)\s*=\s*)(["'])([^"']+)\2/g,(match,attribute,quote,value)=>{
    const unversioned=value.split('?')[0].replace(/^\.\//,'');
    for(const [asset,replacement] of replacements){
      if(unversioned!==replacement.relative&&unversioned!==asset&&unversioned!==path.posix.basename(asset))continue;
      replacement.seen=true;return attribute+quote+replacement.url+'?v=sha256-'+replacement.hash+quote;
    }return match;
  });
  for(const [asset,replacement] of replacements)if(!replacement.seen)throw new Error('Missing runtime link in '+html+': '+asset);
  return text;
}
const index=await stampHtml(await readFile(path.join(root,'index.html'),'utf8'),'index.html',['runtime/styles.css','runtime/app.bundle.js']);
await writeFile(path.join(root,'index.html'),index);
const products=await stampHtml(await readFile(path.join(root,'src/products.html'),'utf8'),'runtime/products.html',['runtime/products.css','runtime/products.bundle.js']);
await writeFile(path.join(root,'runtime/products.html'),products);

const media=[...(projectConfig.media?.audio||[]).map(track=>track.file),...Object.values(projectConfig.media?.tv||{}).filter(value=>typeof value==='string'&&value)];
const runtime=['index.html','runtime/styles.css','runtime/app.bundle.js','runtime/products.html','runtime/products.css','runtime/products.bundle.js',...media.map(file=>'assets/'+file)];
const sourceInputs={...priorInputs};
for(const name of [...inputs].sort()){
  const current=await fingerprint(name);
  // A preview-only build does not rebuild the house. Retaining previous
  // shared input hashes makes the full verifier reject an outdated house.
  if(!productsOnly||!sourceInputs[name])sourceInputs[name]=current;
}
const files={};for(const name of [...new Set(runtime)].sort())files[name]=await fingerprint(name);
await writeFile(path.join(root,manifestPath),JSON.stringify({schemaVersion:1,layoutVersion:2,version:packageInfo.version,projectId:projectConfig.id,inputs:sourceInputs,files},null,2)+'\n');
console.log('Built '+(productsOnly?'product preview':'house and product viewers')+' in runtime/; recorded '+Object.keys(files).length+' runtime files.');
