import {build} from 'esbuild';
import {readFile,writeFile,stat} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {projectConfig} from '../project-config.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
const entries=process.argv.includes('--products')?['product-preview.js']:['app.js','product-preview.js'];
const inputs=new Set(['project-config.js','package.json','styles.css','products.css']);
for(const entry of entries){
  const result=await build({absWorkingDir:root,entryPoints:[entry],outfile:entry==='app.js'?'app.bundle.js':'products.bundle.js',bundle:true,minify:true,format:'iife',target:'es2020',loader:{'.jpg':'dataurl','.jpeg':'dataurl','.png':'dataurl','.webp':'dataurl','.svg':'dataurl'},metafile:true,logLevel:'warning'});
  Object.keys(result.metafile.inputs).filter(name=>!name.startsWith('node_modules/')).forEach(name=>inputs.add(name));
}
// Always hash the installed source graph, including when rebuilding one viewer.
for(const name of ['app.bundle.js','products.bundle.js'])await stat(path.join(root,name));
for(const [html,css,bundle] of [['index.html','styles.css','app.bundle.js'],['products.html','products.css','products.bundle.js']]){
  let text=await readFile(path.join(root,html),'utf8');
  for(const asset of [css,bundle]){
    const hash=digest(await readFile(path.join(root,asset))).slice(0,16);
    const escaped=asset.replaceAll('.','\\.');
    text=text.replace(new RegExp(`((?:src|href)=["'](?:\\./)?${escaped})(?:\\?[^"']*)?(["'])`,'g'),`$1?v=sha256-${hash}$2`);
  }
  await writeFile(path.join(root,html),text);
}
const media=[...(projectConfig.media?.audio||[]).map(track=>track.file),...Object.values(projectConfig.media?.tv||{}).filter(Boolean)];
const runtime=['index.html','styles.css','app.bundle.js','products.html','products.css','products.bundle.js',...media.map(file=>`assets/${file}`)];
const fingerprint=async name=>{
  if(path.isAbsolute(name)||name.split(/[\\/]/).includes('..'))throw new Error(`Asset must be relative to this project: ${name}`);
  const bytes=await readFile(path.join(root,name));return{bytes:bytes.length,sha256:digest(bytes)};
};
let priorInputs={};
if(entries.length===1){try{priorInputs=JSON.parse(await readFile(path.join(root,'build-manifest.json'),'utf8')).inputs||{};}catch{}}
const sourceInputs={...priorInputs};
for(const name of [...inputs].sort())sourceInputs[name]=await fingerprint(name);
const files={};for(const name of [...new Set(runtime)].sort())files[name]=await fingerprint(name);
await writeFile(path.join(root,'build-manifest.json'),JSON.stringify({schemaVersion:1,version:'0.1.0',projectId:projectConfig.id,inputs:sourceInputs,files},null,2)+'\n');
console.log(`Built ${entries.length===1?'product preview':'house and product viewers'}; recorded ${Object.keys(files).length} runtime files.`);
