import {chromium,webkit} from 'playwright';
import {writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {projectConfig} from '../src/project-config.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
let url='http://127.0.0.1:4175/runtime/products.html',cdp=process.env.HOUSE_STARTER_CDP_URL||'',browserName='chromium';
for(let i=2;i<process.argv.length;i++){
  const flag=process.argv[i],value=process.argv[++i];
  if(flag==='--url')url=value;else if(flag==='--cdp-url')cdp=value;else if(flag==='--browser')browserName=value;else throw new Error(`Unknown option: ${flag}`);
}
let browser;
try{
  browser=cdp?await chromium.connectOverCDP(cdp):await ({chromium,webkit}[browserName]).launch({headless:true});
  const page=await browser.newPage({viewport:{width:1000,height:800},deviceScaleFactor:1});
  const target=new URL(url);target.searchParams.set('inspect','1');
  await page.goto(target.href,{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>window.houseProductPreview?.model);
  for(const product of projectConfig.products){
    const data=await page.evaluate(id=>{
      const view=window.houseProductPreview;view.select(id);const model=view.model,body=model.getObjectByName('product body');
      model.updateMatrixWorld(true);const points=[];
      body.traverse(object=>{if(!object.geometry?.attributes.position)return;object.geometry.computeBoundingBox();const b=object.geometry.boundingBox;for(const x of [b.min.x,b.max.x])for(const y of [b.min.y,b.max.y])for(const z of [b.min.z,b.max.z]){const point=view.camera.position.clone().set(x,y,z).applyMatrix4(object.matrixWorld);points.push(point);}});
      const center=view.camera.position.clone().set(0,0,0);for(const point of points)center.add(point);center.divideScalar(points.length);
      let radius=0;for(const point of points)radius=Math.max(radius,point.distanceTo(center));
      const half=Math.max(.1,radius*1.18);view.camera.left=-half;view.camera.right=half;view.camera.top=half;view.camera.bottom=-half;view.camera.zoom=1;view.camera.up.set(0,1,0);view.camera.updateProjectionMatrix();
      view.camera.position.copy(center).add(view.camera.position.clone().set(-1.2,.8,1.5).normalize().multiplyScalar(Math.max(3,radius*5)));view.camera.lookAt(center);
      view.scene.traverse(object=>{if(object.material?.isShadowMaterial)object.visible=false;});const suspension=model.getObjectByName('adjustable suspension');if(suspension)suspension.visible=false;
      view.renderer.setPixelRatio(1);view.renderer.setSize(400,400,false);view.renderer.render(view.scene,view.camera);return view.renderer.domElement.toDataURL('image/png');
    },product.id);
    const filename=path.join(root,'assets','product-thumbnails',`${product.id}.png`);await writeFile(filename,Buffer.from(data.split(',')[1],'base64'));console.log(`Rendered ${product.id}`);
  }
  await page.close();
}finally{if(browser)await browser.close();}
