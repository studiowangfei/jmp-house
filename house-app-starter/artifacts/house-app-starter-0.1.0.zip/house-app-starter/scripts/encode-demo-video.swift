// Optional macOS regeneration path. Bundled demo MP4s run on any supported host.
import Foundation
import AVFoundation
import CoreGraphics
import CoreVideo

guard CommandLine.arguments.count == 3 else {
    fputs("Usage: swift encode-demo-video.swift OUTPUT.mp4 day|night\n", stderr)
    exit(2)
}
let output = URL(fileURLWithPath: CommandLine.arguments[1])
let night = CommandLine.arguments[2] == "night"
try FileManager.default.createDirectory(at: output.deletingLastPathComponent(), withIntermediateDirectories: true)
if FileManager.default.fileExists(atPath: output.path) { try FileManager.default.removeItem(at: output) }
let width = 480, height = 270, fps: Int32 = 18, frameCount = 72
let writer = try AVAssetWriter(outputURL: output, fileType: .mp4)
let input = AVAssetWriterInput(mediaType: .video, outputSettings: [
    AVVideoCodecKey: AVVideoCodecType.h264,
    AVVideoWidthKey: width, AVVideoHeightKey: height,
    AVVideoCompressionPropertiesKey: [AVVideoAverageBitRateKey: 200_000, AVVideoProfileLevelKey: AVVideoProfileLevelH264BaselineAutoLevel]
])
input.expectsMediaDataInRealTime = false
let adapter = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: [
    kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32ARGB,
    kCVPixelBufferWidthKey as String: width, kCVPixelBufferHeightKey as String: height,
    kCVPixelBufferCGImageCompatibilityKey as String: true,
    kCVPixelBufferCGBitmapContextCompatibilityKey as String: true,
])
guard writer.canAdd(input) else { fatalError("Video writer cannot add H.264 input") }
writer.add(input)
guard writer.startWriting() else { fatalError("Unable to start video writer: \(String(describing: writer.error))") }
writer.startSession(atSourceTime: .zero)
let space = CGColorSpaceCreateDeviceRGB()
func color(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat, _ a: CGFloat = 1) -> CGColor {
    CGColor(colorSpace: space, components: [r,g,b,a])!
}
for index in 0..<frameCount {
    let readinessDeadline = Date().addingTimeInterval(15)
    while !input.isReadyForMoreMediaData {
        if writer.status == .failed || Date() > readinessDeadline { fatalError("Video writer stalled: \(String(describing: writer.error))") }
        Thread.sleep(forTimeInterval: 0.005)
    }
    var buffer: CVPixelBuffer?
    let status = CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32ARGB, nil, &buffer)
    guard status == kCVReturnSuccess, let pixel = buffer else { fatalError("Unable to allocate video frame") }
    CVPixelBufferLockBaseAddress(pixel, [])
    guard let context = CGContext(data: CVPixelBufferGetBaseAddress(pixel), width: width, height: height, bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(pixel), space: space, bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue) else { fatalError("Unable to draw video frame") }
    let phase = CGFloat(index) / CGFloat(frameCount) * CGFloat.pi * 2
    context.setFillColor(night ? color(0.08,0.11,0.16) : color(0.89,0.86,0.78))
    context.fill(CGRect(x:0,y:0,width:width,height:height))
    context.setFillColor(night ? color(0.82,0.48,0.24) : color(0.73,0.34,0.22))
    context.fillEllipse(in: CGRect(x:285+35*cos(phase),y:135+15*sin(phase),width:100,height:100))
    for layer in 0..<4 {
        let y = CGFloat(30+layer*26)+12*sin(phase+CGFloat(layer)*0.5)
        let path = CGMutablePath();path.move(to:CGPoint(x:0,y:y));path.addCurve(to:CGPoint(x:480,y:y+20),control1:CGPoint(x:140,y:y+100),control2:CGPoint(x:310,y:y-30));path.addLine(to:CGPoint(x:480,y:0));path.addLine(to:.zero);path.closeSubpath()
        context.setFillColor(night ? color(0.15+CGFloat(layer)*0.04,0.22+CGFloat(layer)*0.03,0.25+CGFloat(layer)*0.025) : color(0.26+CGFloat(layer)*0.07,0.39+CGFloat(layer)*0.055,0.31+CGFloat(layer)*0.04))
        context.addPath(path);context.fillPath()
    }
    CVPixelBufferUnlockBaseAddress(pixel, [])
    guard adapter.append(pixel, withPresentationTime: CMTime(value:Int64(index),timescale:fps)) else { fatalError("Unable to append video frame: \(String(describing: writer.error))") }
}
input.markAsFinished()
let completion = DispatchSemaphore(value:0)
writer.finishWriting { completion.signal() }
guard completion.wait(timeout:.now()+30) == .success, writer.status == .completed else { fatalError("Unable to finalize video: \(String(describing: writer.error))") }
print("Generated \(output.lastPathComponent): H.264, \(width)x\(height), 4 seconds")
