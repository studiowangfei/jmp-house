#!/usr/bin/env python3
"""Generate original demo imagery, audio and short abstract videos.

PNG and WAV generation uses only Python's standard library. MP4 generation
requires an ffmpeg executable with libx264. No downloaded media is used.
"""

import argparse
import binascii
import math
import os
from pathlib import Path
import random
import shutil
import struct
import subprocess
import wave
import zlib

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'assets'


def rgb(value):
    if isinstance(value, str):
        return tuple(int(value.lstrip('#')[i:i + 2], 16) for i in (0, 2, 4))
    return tuple(value)


class Canvas:
    def __init__(self, width, height, color='#f4f0e8'):
        self.width, self.height = width, height
        self.pixels = bytearray(bytes(rgb(color)) * (width * height))

    def pixel(self, x, y, color):
        if 0 <= x < self.width and 0 <= y < self.height:
            offset = (y * self.width + x) * 3
            self.pixels[offset:offset + 3] = bytes(rgb(color))

    def rect(self, x0, y0, x1, y1, color):
        left, right = max(0, int(x0)), min(self.width, int(x1))
        line = bytes(rgb(color)) * max(0, right - left)
        for y in range(max(0, int(y0)), min(self.height, int(y1))):
            offset = (y * self.width + left) * 3
            self.pixels[offset:offset + len(line)] = line

    def ellipse(self, cx, cy, rx, ry, color):
        if rx <= 0 or ry <= 0:
            return
        for y in range(max(0, int(cy - ry)), min(self.height, int(cy + ry + 1))):
            half = rx * math.sqrt(max(0, 1 - ((y - cy) / ry) ** 2))
            self.rect(cx - half, y, cx + half + 1, y + 1, color)

    def polygon(self, points, color):
        if not points:
            return
        for y in range(max(0, int(min(p[1] for p in points))), min(self.height, int(max(p[1] for p in points)) + 1)):
            crossings = []
            for i, (x0, y0) in enumerate(points):
                x1, y1 = points[(i + 1) % len(points)]
                if (y0 <= y < y1) or (y1 <= y < y0):
                    crossings.append(x0 + (y - y0) * (x1 - x0) / (y1 - y0))
            crossings.sort()
            for i in range(0, len(crossings) - 1, 2):
                self.rect(crossings[i], y, crossings[i + 1] + 1, y + 1, color)

    def line(self, a, b, color, width=2):
        distance = max(1, int(math.hypot(b[0] - a[0], b[1] - a[1]) * 1.5))
        for i in range(distance + 1):
            t = i / distance
            self.ellipse(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, width / 2, width / 2, color)

    def png(self, path, alpha=None):
        path.parent.mkdir(parents=True, exist_ok=True)
        channels = 4 if alpha is not None else 3
        rows = bytearray()
        for y in range(self.height):
            rows.append(0)
            for x in range(self.width):
                i = (y * self.width + x) * 3
                rows.extend(self.pixels[i:i + 3])
                if alpha is not None:
                    rows.append(alpha[y * self.width + x])
        def chunk(kind, data):
            return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', binascii.crc32(kind + data) & 0xffffffff)
        header = struct.pack('>IIBBBBB', self.width, self.height, 8, 6 if channels == 4 else 2, 0, 0, 0)
        path.write_bytes(b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', header) + chunk(b'IDAT', zlib.compress(bytes(rows), 9)) + chunk(b'IEND', b''))


def materials():
    size = 256
    rng = random.Random(83612)
    for name in ('tile', 'stone', 'wood', 'paint'):
        canvas = Canvas(size, size)
        for y in range(size):
            for x in range(size):
                noise = rng.uniform(-2.4, 2.4)
                if name == 'tile':
                    grain = math.sin(x * .031) * 1.8 + math.cos(y * .022) * 2
                    grout = min(x, y, size - 1 - x, size - 1 - y) < 2
                    color = (191, 185, 173) if grout else tuple(int(v + grain + noise) for v in (224, 218, 205))
                elif name == 'stone':
                    vein = math.sin(x * .055 + y * .018 + math.sin(y * .035) * 1.4)
                    dark = 17 * max(0, 1 - abs(vein) * 8)
                    color = tuple(int(v - dark + noise) for v in (211, 203, 184))
                elif name == 'wood':
                    grain = math.sin(x * .23 + math.sin(y * .015) * 1.7) * 8 + math.sin(x * .051) * 6
                    color = tuple(int(v + grain + noise) for v in (182, 148, 104))
                else:
                    color = tuple(int(v + noise * .35) for v in (239, 235, 226))
                canvas.pixel(x, y, tuple(max(0, min(255, v)) for v in color))
        canvas.png(ASSETS / 'materials' / f'demo-{name}.png')


def artwork(index, size):
    canvas = Canvas(size, size)
    s = size / 512
    def rect(a, b, c, d, color): canvas.rect(a * s, b * s, c * s, d * s, color)
    def ellipse(x, y, rx, ry, color): canvas.ellipse(x * s, y * s, rx * s, ry * s, color)
    def polygon(points, color): canvas.polygon([(x * s, y * s) for x, y in points], color)
    if index == 1:
        ellipse(352, 162, 90, 90, '#b66c4f');rect(76, 252, 212, 440, '#c8b992');ellipse(144, 252, 68, 68, '#c8b992')
        rect(270, 298, 438, 444, '#3f5550');ellipse(354, 298, 84, 84, '#3f5550');rect(302, 301, 406, 444, '#f4f0e8');ellipse(354, 301, 52, 52, '#f4f0e8')
    elif index == 2:
        ellipse(364, 130, 52, 52, '#d3ac57');ellipse(150, 478, 245, 236, '#8da694');ellipse(430, 520, 240, 234, '#526e5d')
        rect(0, 418, 512, 512, '#526e5d')
    elif index == 3:
        rect(72, 122, 145, 438, '#738894');rect(183, 70, 248, 438, '#b9c7c4');rect(286, 170, 350, 438, '#3e5a6c');ellipse(377, 120, 48, 48, '#c88361');ellipse(116, 355, 68, 68, '#d6b781')
    elif index == 4:
        polygon([(257, 78), (394, 217), (301, 370), (171, 432), (113, 298), (161, 151)], '#4a6354')
        canvas.line((257*s, 96*s), (202*s, 421*s), '#d9d3bd', 5*s)
        for i in range(5): canvas.line(((241-i*7)*s, (176+i*42)*s), ((310-i*10)*s, (155+i*45)*s), '#d9d3bd', 3*s)
    elif index == 5:
        rect(76, 87, 316, 327, '#795667');rect(195, 239, 423, 443, '#c7b4ab');ellipse(343, 176, 91, 91, '#d69c9c');rect(114, 366, 175, 442, '#3a474a')
    else:
        ellipse(179, 223, 104, 127, '#cb9d55');rect(75, 223, 283, 442, '#cb9d55');ellipse(337, 305, 104, 127, '#4d657e');rect(233, 305, 441, 442, '#4d657e');ellipse(255, 175, 35, 35, '#e5c3a6')
    return canvas


def gallery():
    for index in range(1, 7):
        artwork(index, 512).png(ASSETS / 'gallery' / f'{index}.png')
        artwork(index, 160).png(ASSETS / 'gallery' / f'{index}-preview.png')


def flame():
    canvas = Canvas(256, 256, '#1b1b18')
    canvas.ellipse(128, 221, 97, 18, '#bb542b')
    for center, height, spread in ((72, 142, 30), (126, 192, 45), (184, 129, 27)):
        points = [(center-spread, 225), (center-spread*.8, 197), (center-spread*.3, 170), (center+spread*.2, 225-height), (center+spread*.6, 152), (center+spread, 188), (center+spread, 225)]
        canvas.polygon(points, '#cf7138')
        canvas.polygon([(center-spread*.5, 225), (center-spread*.3, 192), (center+spread*.15, 225-height*.63), (center+spread*.5, 203), (center+spread*.5, 225)], '#e9b85a')
    canvas.ellipse(127, 224, 70, 12, '#f3d886')
    alpha = bytearray(256*256)
    for y in range(256):
        for x in range(256):
            offset = (y*256+x)*3
            alpha[y*256+x] = 0 if tuple(canvas.pixels[offset:offset+3]) == rgb('#1b1b18') else 255
    canvas.png(ASSETS / 'fireplace-fire.png', alpha)


def thumbnails():
    for name in ('table', 'chair', 'sofa', 'pendant', 'floor-lamp', 'mirror', 'speaker', 'plant'):
        c = Canvas(256, 256, '#ffffff')
        c.ellipse(128, 215, 78, 9, '#eeece7')
        wood, light, dark = '#a88359', '#c5a47c', '#414744'
        if name == 'table':
            for x,y in ((51,139),(149,178),(197,127),(100,91)): c.line((x,y),(x-2,y+53),wood,9)
            c.polygon([(39,120),(143,160),(218,118),(115,80)],light);c.polygon([(39,120),(143,160),(143,169),(39,129)],wood);c.polygon([(143,160),(218,118),(218,126),(143,169)],wood)
        elif name == 'chair':
            for a,b in (((91,146),(87,211)),((159,151),(163,211)),((130,130),(130,181)),((72,128),(70,181))):c.line(a,b,wood,7)
            c.polygon([(69,132),(126,156),(170,131),(111,108)],light);c.ellipse(125,137,30,12,'#ddd5bf')
            c.line((80,126),(82,83),wood,7);c.line((146,105),(147,67),wood,7);c.polygon([(79,64),(146,48),(156,86),(88,103)],light)
        elif name == 'sofa':
            c.rect(34,107,223,183,'#71826e');c.ellipse(128,111,95,20,'#85947e');c.rect(39,136,218,193,'#6d7e68')
            for x in (64,121,178):c.rect(x-21,116,x+21,153,'#8b9b84');c.ellipse(x,146,25,15,'#82947a')
            for x in (35,215):c.ellipse(x,148,13,24,'#71826e');c.rect(x-13,148,x+13,185,'#71826e')
            for x in (52,201):c.line((x,184),(x,210),wood,8)
        elif name == 'pendant':
            c.line((128,38),(128,90),dark,3);c.ellipse(128,37,15,5,'#b36e50');c.polygon([(101,88),(155,88),(191,153),(65,153)],'#b36e50');c.ellipse(128,154,63,13,'#eee0bc');c.ellipse(128,91,27,8,'#b36e50')
        elif name == 'floor-lamp':
            c.ellipse(128,212,39,8,'#817d73');c.line((128,202),(128,85),'#817d73',6);c.polygon([(100,47),(155,47),(170,101),(85,101)],'#e1d7c1');c.ellipse(128,101,43,9,'#efe4cb');c.ellipse(128,48,28,7,'#e1d7c1')
        elif name == 'mirror':
            c.ellipse(128,123,74,81,wood);c.ellipse(128,123,65,72,'#c9d7d2');c.polygon([(87,69),(153,65),(173,146),(123,177)],'#dee6df')
        elif name == 'speaker':
            c.rect(37,96,220,186,'#ddd6c8');c.ellipse(129,99,92,13,'#e8e2d5');c.rect(37,107,220,176,'#e8e2d5')
            for x in (84,171):c.ellipse(x,136,31,31,dark);c.ellipse(x,136,23,23,'#525957')
            c.ellipse(184,91,10,5,dark);c.rect(121,155,137,159,'#e5ba78')
        else:
            for a,b in (((126,177),(115,48)),((130,177),(147,74))):c.line(a,b,'#776344',4)
            for i in range(9):
                y=58+i*13;x=118+(i%2)*25;left=i%2==0;c.line((129,y+20),(x-18 if left else x+13,y),'#776344',2);c.ellipse(x-21 if left else x+17,y,21,10,'#49694f')
            c.polygon([(96,170),(160,170),(153,219),(103,219)],'#ded8ca');c.ellipse(128,171,33,8,'#eae4d8');c.ellipse(128,171,27,5,'#776344')
        c.png(ASSETS / 'product-thumbnails' / f'demo-{name}.png')


def audio():
    rate, seconds = 22050, 8
    data = bytearray()
    frequencies = (130.8128, 196.0, 261.6256, 329.6276)
    for i in range(rate*seconds):
        t = i/rate
        envelope = min(1, t/.8, (seconds-t)/.8)*(.7+.3*math.sin(math.pi*t/seconds)**2)
        sample = sum(math.sin(2*math.pi*f*t+math.sin(t*.65)*.06)/(index+2) for index,f in enumerate(frequencies))
        data.extend(struct.pack('<h', int(max(-1,min(1,sample*.11*envelope))*32767)))
    destination = ASSETS/'audio'/'demo-ambient.wav';destination.parent.mkdir(parents=True,exist_ok=True)
    with wave.open(str(destination),'wb') as output:
        output.setnchannels(1);output.setsampwidth(2);output.setframerate(rate);output.writeframes(data)


def video_frame(index, night=False):
    c = Canvas(320,180,'#26302e' if night else '#e9e3d5')
    phase = index/12
    palette = ('#d29b64','#657e72','#e9c88b') if night else ('#b46f53','#7f9a8b','#bfb087')
    for i in range(5):
        x = 22+i*65+math.sin(phase*.8+i)*14
        c.rect(x, 44, x+29, 164, palette[i%3]);c.ellipse(x+14.5,44,14.5,14.5,palette[i%3])
    c.ellipse(260+math.sin(phase)*12,40,18,18,palette[0]);return c


def videos(ffmpeg):
    destination = ASSETS/'video';destination.mkdir(parents=True,exist_ok=True)
    for name,night in (('day',False),('night',True)):
        command = [str(ffmpeg),'-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','320x180','-r','12','-i','pipe:0','-an','-c:v','libx264','-preset','medium','-crf','24','-pix_fmt','yuv420p','-movflags','+faststart',str(destination/f'demo-{name}.mp4')]
        process = subprocess.Popen(command,stdin=subprocess.PIPE)
        try:
            for index in range(60):process.stdin.write(video_frame(index,night).pixels)
            process.stdin.close()
        except BrokenPipeError:
            pass
        if process.wait()!=0:raise RuntimeError('ffmpeg could not encode the generated video; ensure libx264 is available.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ffmpeg',default=os.environ.get('HOUSE_STARTER_FFMPEG') or shutil.which('ffmpeg'),help='Path to ffmpeg with libx264; also reads HOUSE_STARTER_FFMPEG.')
    parser.add_argument('--skip-video',action='store_true',help='Regenerate PNG/WAV files and leave bundled MP4 files unchanged.')
    args=parser.parse_args()
    materials();gallery();flame();audio()
    if not (ASSETS/'product-thumbnails'/'demo-table.png').exists():thumbnails()
    if not args.skip_video and args.ffmpeg:videos(args.ffmpeg)
    elif not args.skip_video:print('No ffmpeg supplied: PNG/WAV assets regenerated; bundled MP4 files are unchanged. Use --ffmpeg PATH to regenerate video.')
    print('Generated original demo assets in '+str(ASSETS))


if __name__=='__main__':main()
