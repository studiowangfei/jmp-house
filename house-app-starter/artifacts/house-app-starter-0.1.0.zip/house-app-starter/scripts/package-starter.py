#!/usr/bin/env python3
"""Package the verified starter source with an explicit, portable file inventory."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import tempfile
import zipfile


ROOT = Path(__file__).resolve().parent.parent
VERSION = '0.1.0'
ARCHIVE_ROOT = 'house-app-starter'
ARCHIVE_MANIFEST = 'starter-manifest.json'
ZIP_TIME = (1980, 1, 1, 0, 0, 0)

# Unknown files beside the app are deliberately excluded. Adding a new source
# module requires adding it here, so imported code cannot disappear silently.
TOP_LEVEL_FILES = frozenset({
    '.gitignore', 'AGENTS.md', 'README.md', 'BUILD_PROMPT.md', 'INPUTS.md',
    'APP_SPEC.md', 'WORKFLOW.md', 'VALIDATION.md', 'SCENE_CONTRACT.md', 'BUILD_PROMPT.txt', 'GUIDE.md',
    'THIRD_PARTY_NOTICES.md', 'RELEASE.json', 'release-manifest.json',
    'index.html', 'products.html', 'styles.css', 'products.css',
    'package.json', 'package-lock.json', 'build-manifest.json',
    'app.js', 'app.bundle.js', 'product-preview.js', 'products.bundle.js',
    'model.js', 'project-config.js', 'catalog-data.js', 'product-library.js',
    'product-thumbnails.js', 'media-assets.js', 'dimensions.js',
    'default-view.js', 'arrangement-constraints.js', 'arrange-grid.js',
    'embedded-host-bridge.js', 'fireplace-control.js', 'gallery-genie.js',
    'material-focus.js', 'material-focus-presets.js', 'night-view.js',
    'night-wall-frame-lighting.js', 'performance-optimizations.js',
    'product-focus.js', 'snapshot-camera.js', 'snapshot-capture.js',
    'speaker-playback.js', 'tv-video-transition.js', 'scene-interactions.js',
    'serve.py', 'verify-deployment.py', 'verify_deployment_support.py',
    'build-deployment.py',
})

DIRECTORY_EXTENSIONS = {
    'assets': {'.png', '.webp', '.jpg', '.jpeg', '.svg', '.wav', '.mp3', '.mp4', '.webm', '.ogg'},
    'project': {'.json', '.md'},
    'scene': {'.js', '.mjs', '.json', '.md'},
    'references': {'.md', '.mjs', '.json', '.txt', '.png', '.webp', '.jpg', '.jpeg', '.svg', '.mp4', '.webm'},
    'tests': {'.js', '.mjs', '.json', '.md'},
    'skills': {'.md', '.json', '.txt', '.py', '.js', '.mjs', '.sh'},
    'scripts': {'.py', '.js', '.mjs', '.swift', '.sh', '.json', '.md'},
}

EXCLUDED_PARTS = frozenset({
    'node_modules', 'dist', 'artifacts', '.git', '.cache', '__pycache__',
    'archive', 'private', 'private-notes', 'personal', 'secrets',
})
PRIVATE_NAME = re.compile(r'(?:^|[._-])(?:private|personal|secret|credentials?|history|original-plan|owner-notes|session)(?:[._-]|$)', re.IGNORECASE)
REQUIRED_FILES = frozenset({
    'README.md', 'BUILD_PROMPT.md', 'BUILD_PROMPT.txt', 'GUIDE.md', 'INPUTS.md', 'APP_SPEC.md', 'WORKFLOW.md',
    'VALIDATION.md', 'SCENE_CONTRACT.md', 'package.json', 'package-lock.json',
    'build-manifest.json', 'app.js', 'app.bundle.js', 'index.html', 'styles.css',
    'product-preview.js', 'products.bundle.js', 'products.html', 'products.css',
    'model.js', 'project-config.js', 'scripts/build.mjs',
    'scripts/package-starter.py', 'skills/house-app-builder/SKILL.md',
})


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def allowed_path(relative: Path) -> bool:
    name = relative.as_posix()
    if '\\' in name or ':' in name or any(ord(character) < 32 for character in name):
        return False
    if len(relative.parts) == 1:
        return name in TOP_LEVEL_FILES
    if relative.parts[0] not in DIRECTORY_EXTENSIONS:
        return False
    if any(part.startswith('.') or part in EXCLUDED_PARTS or PRIVATE_NAME.search(part) for part in relative.parts):
        return False
    return relative.suffix.lower() in DIRECTORY_EXTENSIONS[relative.parts[0]]


def collect_source(root: Path) -> dict[str, bytes]:
    selected: dict[str, bytes] = {}
    candidates = [root / name for name in TOP_LEVEL_FILES]
    for directory in DIRECTORY_EXTENSIONS:
        base = root / directory
        if base.is_symlink():
            raise ValueError(f'Refusing a symlinked package directory: {directory}')
        if base.is_dir():
            for parent, directories, files in os.walk(base, followlinks=False):
                directories[:] = [name for name in directories if not name.startswith('.') and name not in EXCLUDED_PARTS and not PRIVATE_NAME.search(name) and not (Path(parent) / name).is_symlink()]
                candidates.extend(Path(parent) / name for name in files)
    for file in sorted(candidates, key=lambda candidate: candidate.as_posix()):
        relative = file.relative_to(root)
        if not allowed_path(relative) or not file.is_file():
            continue
        if file.is_symlink() or root not in file.resolve().parents:
            raise ValueError(f'Refusing a linked source file: {relative.as_posix()}')
        selected[relative.as_posix()] = file.read_bytes()
    missing = REQUIRED_FILES - selected.keys()
    if missing:
        raise ValueError('Starter package is incomplete; missing: ' + ', '.join(sorted(missing)))
    return selected


def check_snapshot(selected: dict[str, bytes]) -> dict:
    package = json.loads(selected['package.json'])
    if package.get('version') != VERSION:
        raise ValueError(f'Package version must be {VERSION}; update the release packager when changing versions')
    manifest = json.loads(selected['build-manifest.json'])
    for section in ('inputs', 'files'):
        entries = manifest.get(section)
        if not isinstance(entries, dict) or not entries:
            raise ValueError(f'Build manifest lacks {section}; run npm run build')
        for relative, expected in entries.items():
            if relative not in selected:
                raise ValueError(f'Build depends on a file excluded from the source package: {relative}')
            data = selected[relative]
            if len(data) != expected.get('bytes') or sha256(data) != expected.get('sha256'):
                raise ValueError(f'Source package contains a stale built input or runtime file: {relative}')
    return manifest


def write_zip(output: Path, selected: dict[str, bytes]) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(prefix='.house-app-package-', suffix='.zip', dir=output.parent, delete=False) as handle:
            temporary = Path(handle.name)
        with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            archive.comment = f'{ARCHIVE_ROOT} {VERSION}'.encode('ascii')
            for relative, data in sorted(selected.items()):
                entry = zipfile.ZipInfo(f'{ARCHIVE_ROOT}/{relative}', ZIP_TIME)
                entry.create_system = 3
                entry.external_attr = (stat.S_IFREG | 0o644) << 16
                entry.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(entry, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        os.replace(temporary, output)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def package_starter(root: Path, output: Path) -> dict:
    # Import the same verifier used by the build/deployment commands.
    sys.path.insert(0, str(root))
    from verify_deployment_support import verify

    verify(root)
    deployment = root / 'dist'
    if deployment.exists():
        if deployment.is_symlink():
            raise ValueError('Refusing a symlinked deployment directory')
        verify(deployment, deployed=True)
        if (deployment / 'build-manifest.json').read_bytes() != (root / 'build-manifest.json').read_bytes():
            raise ValueError('Deployment is stale; run npm run build:deployment before packaging')
    selected = collect_source(root)
    build_manifest = check_snapshot(selected)
    package_manifest = {
        'schemaVersion': 1,
        'name': ARCHIVE_ROOT,
        'version': VERSION,
        'projectId': build_manifest.get('projectId'),
        'buildManifestSha256': sha256(selected['build-manifest.json']),
        'files': {relative: {'bytes': len(data), 'sha256': sha256(data)} for relative, data in sorted(selected.items())},
    }
    selected[ARCHIVE_MANIFEST] = (json.dumps(package_manifest, indent=2, sort_keys=True) + '\n').encode('utf-8')
    # A source edit concurrent with packaging must fail rather than create a
    # release that appears fresh only because it was checked earlier.
    verify(root)
    write_zip(output, selected)
    return package_manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'artifacts' / f'{ARCHIVE_ROOT}-{VERSION}.zip', help='ZIP path; relative paths are resolved from the starter directory')
    args = parser.parse_args()
    requested = args.output if args.output.is_absolute() else ROOT / args.output
    if requested.is_symlink():
        raise SystemExit('Refusing to replace a symlinked ZIP output')
    output = requested.resolve()
    if output.suffix.lower() != '.zip' or output == ROOT or output in ROOT.parents:
        raise SystemExit('Output must be a ZIP file outside the source file inventory')
    if ROOT in output.parents and output.relative_to(ROOT).parts[0] != 'artifacts':
        raise SystemExit('ZIP output inside the starter must be under artifacts/')
    try:
        manifest = package_starter(ROOT, output)
    except (ValueError, OSError, KeyError, TypeError, json.JSONDecodeError, ImportError) as error:
        raise SystemExit(str(error))
    print(f'Packaged {len(manifest["files"])} verified source files: {output}')


if __name__ == '__main__':
    main()
