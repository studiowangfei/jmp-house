// Offline previews of actual authored meshes. This does not execute browser UI.
import * as THREE from 'three';
import {productCatalog,createProduct,disposeProduct} from '../src/product-library.js';
import {mkdir,writeFile} from 'node:fs/promises';
import {deflateSync} from 'node:zlib';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const OUT=path.resolve(process.argv[2]||path.join(ROOT,'assets','product-thumbnails'));
const W=768,H=768,FINAL=384;
const crcTable=Uint32Array.from({length:256},(_,n)=>{let c=n;for(let k=0;k<8;k++)c=c&1?0xedb88320^(c>>>1):c>>>1;return c>>>0;});
function crc(bytes){let c=0xffffffff;for(const byte of bytes)c=crcTable[(c^byte)&255]^(c>>>8);return (c^0xffffffff)>>>0;}
function chunk(name,data){const type=Buffer.from(name),joined=Buffer.concat([type,data]),length=Buffer.alloc(4),checksum=Buffer.alloc(4);length.writeUInt32BE(data.length);checksum.writeUInt32BE(crc(joined));return Buffer.concat([length,joined,checksum]);}
function png(data){const header=Buffer.alloc(13);header.writeUInt32BE(FINAL,0);header.writeUInt32BE(FINAL,4);header[8]=8;header[9]=2;const scan=Buffer.alloc((FINAL*3+1)*FINAL);for(let y=0;y<FINAL;y++)data.copy(scan,y*(FINAL*3+1)+1,y*FINAL*3,(y+1)*FINAL*3);return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',header),chunk('IDAT',deflateSync(scan,{level:9})),chunk('IEND',Buffer.alloc(0))]);}
const linearToSrgb=value=>255*(value<=.0031308?value*12.92:1.055*Math.pow(value,1/2.4)-.055);
const srgbToLinear=value=>value<=.04045?value/12.92:Math.pow((value+.055)/1.055,2.4);
const sun=new THREE.Vector3(-.55,1.1,1.8).normalize();
await mkdir(OUT,{recursive:true});
const records=[];
for(const spec of productCatalog){
  const product=createProduct(spec.id,{showSuspension:false});product.updateMatrixWorld(true);
  const body=product.getObjectByName('product body'),bounds=new THREE.Box3().setFromObject(body),center=bounds.getCenter(new THREE.Vector3());
  const direction=new THREE.Vector3(2.8,1.8,4).normalize(),camera=new THREE.OrthographicCamera(-1,1,1,-1,.01,50);
  camera.position.copy(center).addScaledVector(direction,10);camera.lookAt(center);camera.updateMatrixWorld();
  let extent=0;for(const x of [bounds.min.x,bounds.max.x])for(const y of [bounds.min.y,bounds.max.y])for(const z of [bounds.min.z,bounds.max.z]){const p=new THREE.Vector3(x,y,z).project(camera);extent=Math.max(extent,Math.abs(p.x),Math.abs(p.y));}
  camera.left=camera.bottom=-extent*1.15;camera.right=camera.top=extent*1.15;camera.updateProjectionMatrix();
  const pixels=new Float32Array(W*H*3).fill(1),depth=new Float32Array(W*H).fill(Infinity);
  const foot=new THREE.Vector3(center.x,bounds.min.y,center.z).project(camera),shadowX=(foot.x+1)*W/2,shadowY=(1-foot.y)*H/2;
  for(let y=Math.max(0,Math.floor(shadowY-12));y<Math.min(H,shadowY+12);y++)for(let x=Math.max(0,Math.floor(shadowX-130));x<Math.min(W,shadowX+130);x++){
    const radius=((x-shadowX)/130)**2+((y-shadowY)/12)**2;if(radius>1)continue;const i=(y*W+x)*3,v=1-.065*(1-radius);pixels[i]=pixels[i+1]=pixels[i+2]=v;
  }
  let triangles=0;
  body.traverse(object=>{
    if(!object.isMesh||object.visible===false)return;
    const geometry=object.geometry,position=geometry.attributes.position,normal=geometry.attributes.normal,uv=geometry.attributes.uv,index=geometry.index,material=Array.isArray(object.material)?object.material[0]:object.material;
    if(!material||material.visible===false)return;
    const normalMatrix=new THREE.Matrix3().getNormalMatrix(object.matrixWorld),points=[];
    for(let i=0;i<position.count;i++){
      const world=new THREE.Vector3().fromBufferAttribute(position,i).applyMatrix4(object.matrixWorld),p=world.clone().project(camera),n=normal?new THREE.Vector3().fromBufferAttribute(normal,i).applyNormalMatrix(normalMatrix):new THREE.Vector3(0,1,0);
      points.push({x:(p.x+1)*W/2,y:(1-p.y)*H/2,z:p.z,n,uv:uv?[uv.getX(i),uv.getY(i)]:[0,0]});
    }
    const base=material.color||new THREE.Color('white'),map=material.map,source=map?.image,half=direction.clone().add(sun).normalize();
    const count=index?index.count:position.count;
    for(let i=0;i<count;i+=3){
      const a=points[index?index.getX(i):i],b=points[index?index.getX(i+1):i+1],c=points[index?index.getX(i+2):i+2];
      if(material.side!==THREE.DoubleSide&&a.n.clone().add(b.n).add(c.n).dot(direction)<=0)continue;
      const determinant=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);if(Math.abs(determinant)<1e-8)continue;triangles++;
      const minX=Math.max(0,Math.floor(Math.min(a.x,b.x,c.x))),maxX=Math.min(W-1,Math.ceil(Math.max(a.x,b.x,c.x))),minY=Math.max(0,Math.floor(Math.min(a.y,b.y,c.y))),maxY=Math.min(H-1,Math.ceil(Math.max(a.y,b.y,c.y)));
      for(let y=minY;y<=maxY;y++)for(let x=minX;x<=maxX;x++){
        const wa=((b.y-c.y)*(x+.5-c.x)+(c.x-b.x)*(y+.5-c.y))/determinant,wb=((c.y-a.y)*(x+.5-c.x)+(a.x-c.x)*(y+.5-c.y))/determinant,wc=1-wa-wb;if(Math.min(wa,wb,wc)<-1e-7)continue;
        const z=wa*a.z+wb*b.z+wc*c.z,pixel=y*W+x;if(z>=depth[pixel])continue;depth[pixel]=z;
        let nx=a.n.x*wa+b.n.x*wb+c.n.x*wc,ny=a.n.y*wa+b.n.y*wb+c.n.y*wc,nz=a.n.z*wa+b.n.z*wb+c.n.z*wc,normalLength=Math.hypot(nx,ny,nz)||1;nx/=normalLength;ny/=normalLength;nz/=normalLength;
        if(material.side===THREE.DoubleSide&&nx*direction.x+ny*direction.y+nz*direction.z<0){nx=-nx;ny=-ny;nz=-nz;}
        const lighting=.34+.6*Math.max(0,nx*sun.x+ny*sun.y+nz*sun.z)+.08*Math.max(0,ny),specular=.035*Math.pow(Math.max(0,nx*half.x+ny*half.y+nz*half.z),16),offset=pixel*3;
        let texture=[1,1,1];
        if(source?.data){const repeat=map.repeat||{x:1,y:1},u=(a.uv[0]*wa+b.uv[0]*wb+c.uv[0]*wc)*repeat.x,v=(a.uv[1]*wa+b.uv[1]*wb+c.uv[1]*wc)*repeat.y,tx=Math.floor(((u%1+1)%1)*(source.width-1)),ty=Math.floor(((v%1+1)%1)*(source.height-1)),ti=(ty*source.width+tx)*4;texture=[0,1,2].map(channel=>srgbToLinear(source.data[ti+channel]/255));}
        pixels[offset]=Math.min(1,base.r*lighting*texture[0]+specular);pixels[offset+1]=Math.min(1,base.g*lighting*texture[1]+specular);pixels[offset+2]=Math.min(1,base.b*lighting*texture[2]+specular);
      }
    }
  });
  const output=Buffer.alloc(FINAL*FINAL*3);for(let y=0;y<FINAL;y++)for(let x=0;x<FINAL;x++)for(let channel=0;channel<3;channel++){
    const value=(pixels[((2*y)*W+2*x)*3+channel]+pixels[((2*y)*W+2*x+1)*3+channel]+pixels[((2*y+1)*W+2*x)*3+channel]+pixels[((2*y+1)*W+2*x+1)*3+channel])/4;
    output[(y*FINAL+x)*3+channel]=Math.round(Math.min(255,Math.max(0,linearToSrgb(value))));
  }
  const file=OUT+'/'+spec.id+'.png';await writeFile(file,png(output));records.push({id:spec.id,file:spec.id+'.png',triangles,width:FINAL,height:FINAL,method:'Offline CPU rasterization of createProduct geometry; approximate lighting, not browser UI'});disposeProduct(product);
}
await writeFile(OUT+'/manifest.json',JSON.stringify(records,null,2)+'\n');console.log(`Rendered ${records.length} actual product geometries to ${OUT}`);
