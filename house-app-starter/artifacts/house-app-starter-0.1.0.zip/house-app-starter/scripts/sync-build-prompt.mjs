import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const text=(await readFile(path.join(root,'BUILD_PROMPT.txt'),'utf8')).trimEnd();
const packageInfo=JSON.parse(await readFile(path.join(root,'package.json'),'utf8'));
if(!text.includes(`version ${packageInfo.version}`))throw new Error('Build prompt and starter version differ');
if(text.includes('```'))throw new Error('The plain-text prompt must not contain Markdown code fences');
const markdown=`# Copy/paste build prompt\n\nGive your coding agent the starter ZIP or checkout, then copy the complete block\nbelow. [GUIDE.md](GUIDE.md) explains the stages for the homeowner;\n[README.md](../README.md) explains how to preview the prebuilt demo.\n\nThe canonical copy is [BUILD_PROMPT.txt](../BUILD_PROMPT.txt). After editing that\nfile, run \`npm run docs:sync\` from the starter root to update this Markdown view.\n\n\`\`\`text\n${text}\n\`\`\`\n`;
await mkdir(path.join(root,'docs'),{recursive:true});
await writeFile(path.join(root,'docs','BUILD_PROMPT.md'),markdown);
console.log(`Synchronized BUILD_PROMPT.txt and docs/BUILD_PROMPT.md for version ${packageInfo.version}`);
