#!/usr/bin/env python3
"""Verify prebuilt runtime hashes, source freshness, and deployment downloads."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import posixpath
import re

ROOT = Path(__file__).resolve().parent.parent
MANIFEST_PATH = 'runtime/build-manifest.json'
HTML_ASSETS = (
    ('index.html', 'runtime/styles.css', 'runtime/app.bundle.js'),
    ('runtime/products.html', 'runtime/products.css', 'runtime/products.bundle.js'),
)


def verify(root, *, deployed=False):
    root = Path(root).resolve()
    manifest_path = root / MANIFEST_PATH
    if not manifest_path.is_file():
        raise ValueError('Missing runtime/build-manifest.json; run npm run build first')
    manifest = json.loads(manifest_path.read_text())
    if manifest.get('schemaVersion') != 1 or not isinstance(manifest.get('files'), dict) or not manifest['files']:
        raise ValueError('Invalid build manifest')

    def check_entries(entries):
        if not isinstance(entries, dict):
            raise ValueError('Invalid manifest file inventory')
        for relative, expected in entries.items():
            if not isinstance(relative, str) or not relative or '\\' in relative or ':' in relative:
                raise ValueError(f'Invalid relative path: {relative}')
            candidate = PurePosixPath(relative)
            if candidate.is_absolute() or '..' in candidate.parts:
                raise ValueError(f'Invalid relative path: {relative}')
            target = root / relative
            if target.is_symlink() or root not in target.resolve().parents:
                raise ValueError(f'Linked or external manifest file: {relative}')
            if not target.is_file():
                raise ValueError(f'Missing file: {relative}')
            data = target.read_bytes()
            if not isinstance(expected, dict) or len(data) != expected.get('bytes') or hashlib.sha256(data).hexdigest() != expected.get('sha256'):
                raise ValueError(f'Stale or changed file: {relative}; rebuild the application')

    check_entries(manifest['files'])
    if not deployed:
        check_entries(manifest.get('inputs', {}))
    for html, css, bundle in HTML_ASSETS:
        if any(asset not in manifest['files'] for asset in (html, css, bundle)):
            raise ValueError(f'Missing required runtime file inventory for {html}')
        text = (root / html).read_text()
        references = re.findall(r'(?:src|href)\s*=\s*["\']([^"\']+)["\']', text)
        for asset in (css, bundle):
            fingerprint = manifest['files'][asset]['sha256'][:16]
            relative = posixpath.relpath(asset, PurePosixPath(html).parent.as_posix())
            allowed = {f'{relative}?v=sha256-{fingerprint}', f'./{relative}?v=sha256-{fingerprint}'}
            if not any(reference in allowed for reference in references):
                raise ValueError(f'Unstamped or stale asset link: {html}: {asset}')
        if re.search(r'(?:src|href)=[\"\'](?:https?:)?//', text):
            raise ValueError(f'Unexpected remote runtime dependency in {html}')
    if deployed:
        expected = set(manifest['files']) | {MANIFEST_PATH}
        download_manifest = root / 'downloads-manifest.json'
        if download_manifest.is_file():
            downloads = json.loads(download_manifest.read_text())
            version = downloads.get('starterVersion')
            if downloads.get('schemaVersion') != 1 or not isinstance(version, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*', version):
                raise ValueError('Invalid starter downloads manifest/version')
            if downloads.get('buildManifestSha256') != hashlib.sha256(manifest_path.read_bytes()).hexdigest():
                raise ValueError('Starter downloads are bound to a different application build')
            allowed_downloads = {f'downloads/house-app-starter-{version}.zip', 'downloads/BUILD_PROMPT.txt'}
            if set(downloads.get('files', {})) != allowed_downloads:
                raise ValueError('Starter download inventory must contain exactly the ZIP and prompt')
            check_entries(downloads['files'])
            expected |= allowed_downloads | {'downloads-manifest.json'}
        actual = {file.relative_to(root).as_posix() for file in root.rglob('*') if file.is_file()}
        if actual != expected:
            raise ValueError(f'Deployment file inventory differs: {sorted(actual ^ expected)}')
    return len(manifest['files'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--dist', action='store_true')
    args = parser.parse_args()
    try:
        count = verify(args.root, deployed=args.dist)
    except (ValueError, OSError, KeyError, TypeError) as error:
        raise SystemExit(str(error))
    print(f'Verified {count} runtime files' + (' in deployment' if args.dist else ' and source freshness'))
