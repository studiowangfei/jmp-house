import {chromium,webkit} from 'playwright';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';

const PROFILES=[
  {name:'desktop',viewport:{width:1440,height:900},isMobile:false,hasTouch:false},
  {name:'phone-portrait',viewport:{width:390,height:844},isMobile:true,hasTouch:true},
  {name:'phone-landscape',viewport:{width:844,height:390},isMobile:true,hasTouch:true},
];
const STATES=['day-axon','plan','night','material','product','gallery','information','arrange','snapshot'];
const HELP=`Usage: npm run visual:smoke -- [options]
  --current-url URL   App under test (default http://127.0.0.1:4175/)
  --output DIR        Evidence folder (default artifacts/visual-smoke)
  --browser NAME      chromium or webkit (default chromium)
  --cdp-url URL       Attach to an explicitly provided Chromium endpoint
  --record            Record the automated sequence as well as screenshots
  --motion            Use normal motion (no-preference); default is reduced motion
                      Use --record --motion for normal-motion sequence recordings
  --list              Print profiles/states without launching a browser
  --help              Show these options
`;
function argumentsFor(argv){
  const result={url:'http://127.0.0.1:4175/',output:'artifacts/visual-smoke',browser:'chromium',cdp:process.env.HOUSE_STARTER_CDP_URL||'',record:false,motion:false,list:false,help:false};
  for(let i=0;i<argv.length;i++){
    const flag=argv[i];
    if(flag==='--help'){result.help=true;continue;}
    if(flag==='--list'){result.list=true;continue;}
    if(flag==='--record'){result.record=true;continue;}
    if(flag==='--motion'){result.motion=true;continue;}
    const key={'--current-url':'url','--output':'output','--browser':'browser','--cdp-url':'cdp'}[flag];
    if(!key||!argv[i+1])throw new Error(`Unknown option or missing value: ${flag}`);
    result[key]=argv[++i];
  }
  if(!['chromium','webkit'].includes(result.browser))throw new Error('Browser must be chromium or webkit');
  if(result.help){console.log(HELP);process.exit(0);}
  if(result.list){console.log(JSON.stringify({profiles:PROFILES,states:STATES,record:result.record,reducedMotion:result.motion?'no-preference':'reduce'},null,2));process.exit(0);}
  return result;
}
const options=argumentsFor(process.argv.slice(2)),output=path.resolve(options.output);
const reducedMotion=options.motion?'no-preference':'reduce',settleMs=options.motion?750:120,focusSettleMs=options.motion?4500:1600;
await mkdir(output,{recursive:true});
const manifest={schemaVersion:1,browser:options.cdp?'chromium-cdp':options.browser,record:options.record,motion:options.motion,reducedMotion,settleMs,focusSettleMs,profiles:[],errors:[],status:'running'};
const saveManifest=()=>writeFile(path.join(output,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
const assert=(condition,message)=>{if(!condition)throw new Error(message);};
const paint=page=>page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
async function settle(page){await page.waitForTimeout(settleMs);await paint(page);}
async function canonical(page){
  await page.keyboard.press('Escape');await page.evaluate(()=>window.houseStarter.reset());await settle(page);
}
async function freezeTv(page){
  await page.evaluate(async()=>{
    const video=document.querySelector('video');if(!video)return;
    video.pause();
    if(video.readyState<2)await Promise.race([new Promise(resolve=>video.addEventListener('loadeddata',resolve,{once:true})),new Promise(resolve=>setTimeout(resolve,3000))]);
    const frame=Math.min(1,Math.max(0,(video.duration||2)-.1));
    if(Math.abs(video.currentTime-frame)>.01){const sought=new Promise(resolve=>video.addEventListener('seeked',resolve,{once:true}));video.currentTime=frame;await Promise.race([sought,new Promise(resolve=>setTimeout(resolve,2000))]);}
    video.pause();window.houseStarter.requestRender();
  });await paint(page);
}
async function screenshot(page,profile,state,evidence){
  await freezeTv(page);await settle(page);
  const filename=`${profile.name}/${state}.png`,destination=path.join(output,filename);
  await page.screenshot({path:destination});
  const bytes=await readFile(destination);
  evidence.push({state,file:filename,sha256:createHash('sha256').update(bytes).digest('hex')});
}
let browser;
try{
  browser=options.cdp?await chromium.connectOverCDP(options.cdp):await ({chromium,webkit}[options.browser]).launch({headless:true});
  for(const profile of PROFILES){
    await mkdir(path.join(output,profile.name),{recursive:true});
    const context=await browser.newContext({viewport:profile.viewport,isMobile:profile.isMobile,hasTouch:profile.hasTouch,deviceScaleFactor:1,reducedMotion,locale:'en-US',timezoneId:'America/Los_Angeles',acceptDownloads:true,...(options.record?{recordVideo:{dir:path.join(output,profile.name),size:profile.viewport}}:{})});
    const page=await context.newPage(),errors=[],evidence=[];
    page.on('pageerror',error=>errors.push(`Page: ${error.message}`));
    page.on('console',message=>{if(message.type()==='error')errors.push(`Console: ${message.text()}`);});
    page.on('requestfailed',request=>{if(request.failure()?.errorText!=='net::ERR_ABORTED')errors.push(`Request: ${request.url()} ${request.failure()?.errorText}`);});
    page.on('response',response=>{if(response.status()>=400)errors.push(`HTTP ${response.status()}: ${response.url()}`);});
    const record={name:profile.name,viewport:profile.viewport,evidence,errors};manifest.profiles.push(record);
    try{
      const url=new URL(options.url);url.searchParams.set('intro','off');url.searchParams.set('inspect','1');
      await page.goto(url.href,{waitUntil:'domcontentloaded'});
      await page.waitForFunction(()=>document.documentElement.classList.contains('app-ready')&&window.houseStarter,undefined,{timeout:30000});
      await page.waitForFunction(()=>[...document.querySelectorAll('.product-item img,.material-item img')].every(image=>image.complete&&image.naturalWidth>0),undefined,{timeout:15000});
      record.loaded=await page.evaluate(()=>({title:document.title,progress:document.querySelector('#app-loader-meter').getAttribute('aria-valuenow'),products:document.querySelectorAll('.product-item').length,materials:document.querySelectorAll('.material-item').length,fallback:!document.querySelector('#app-loader-message').hidden}));
      assert(record.loaded.progress==='100'&&!record.loaded.fallback,'App loader did not complete cleanly');
      await canonical(page);await screenshot(page,profile,'day-axon',evidence);
      await page.locator('#view-mode-toggle').click();await settle(page);
      assert(await page.locator('#view-mode-toggle').getAttribute('data-current-view')==='plan','Plan control did not change the view');
      await screenshot(page,profile,'plan',evidence);
      await canonical(page);await page.locator('#day-night-toggle').click();await settle(page);
      assert(await page.evaluate(()=>houseStarter.nightView.isNight),'Night control did not enable Night');
      record.night=await page.evaluate(()=>({fixtures:houseStarter.nightView.fixtureCount,shelves:houseStarter.nightView.shelfLightCount,frames:houseStarter.nightView.frameLightCount}));
      await screenshot(page,profile,'night',evidence);
      await canonical(page);await page.locator('.material-item').first().click();await page.waitForTimeout(focusSettleMs);
      assert(await page.locator('.material-item.is-expanded').count()===1,'Material card failed to expand');
      await screenshot(page,profile,'material',evidence);
      await page.mouse.move(16,16);await canonical(page);await page.locator('.product-item').first().click();await page.waitForTimeout(focusSettleMs);
      assert(await page.locator('.product-item.is-expanded').count()===1,'Product card failed to expand');
      assert(await page.locator('.product-thumbnail canvas').count()===1,'Live product model preview is missing');
      await screenshot(page,profile,'product',evidence);
      await page.mouse.move(16,16);await canonical(page);await page.locator('#gallery-toggle').click();await settle(page);
      assert(await page.locator('#gallery-overlay').getAttribute('aria-hidden')==='false','Gallery failed to open');
      await page.keyboard.press('ArrowRight');await settle(page);await screenshot(page,profile,'gallery',evidence);
      await page.keyboard.press('Escape');await settle(page);
      await page.locator('#description-toggle').click();await settle(page);await screenshot(page,profile,'information',evidence);
      await page.keyboard.press('Escape');await canonical(page);
      const itemId=await page.evaluate(()=>houseStarter.project.house.placements.find(item=>item.constraint==='floor')?.id);
      assert(itemId,'Demo has no floor item to exercise Rearrange');
      await page.evaluate(id=>houseStarter.selectItem(id),itemId);await settle(page);
      const before=await page.evaluate(()=>houseStarter.arrangement.length);
      await page.locator('#arrange-rotate-right').click();await page.locator('#arrange-duplicate').click();await settle(page);
      assert(await page.evaluate(()=>houseStarter.arrangement.length)===before+1,'Duplicate failed');
      await page.locator('#arrange-undo').click();await settle(page);
      assert(await page.evaluate(()=>houseStarter.arrangement.filter(item=>item.present&&!item.deleted).length)===before,'Undo failed to remove duplicate');
      await page.locator('#arrange-redo').click();await settle(page);await screenshot(page,profile,'arrange',evidence);
      await page.locator('#arrange-snapshot').click();await page.locator('#snapshot-image').waitFor({state:'visible'});await page.waitForFunction(()=>document.querySelector('#snapshot-image').naturalWidth>0);
      record.snapshot=await page.locator('#snapshot-image').evaluate(image=>({width:image.naturalWidth,height:image.naturalHeight}));
      const expectedAspect=profile.hasTouch?3/4:4/3;
      assert(Math.abs(record.snapshot.width/record.snapshot.height-expectedAspect)<.001,'Snapshot orientation is incorrect');
      await screenshot(page,profile,'snapshot',evidence);
      const downloadPromise=page.waitForEvent('download');await page.locator('#snapshot-save').click();const download=await downloadPromise;await download.saveAs(path.join(output,profile.name,'saved-arrangement.png'));
      await canonical(page);
      assert(!await page.locator('#snapshot-dialog').isVisible(),'Snapshot dialog remained open after save');
      if(errors.length)throw new Error(errors.join('\n'));
      record.status='passed';console.log(`${profile.name}: ${evidence.length} states and arrangement/snapshot checks passed`);
    }catch(error){
      record.status='failed';record.failure=error.message;manifest.errors.push(`${profile.name}: ${error.message}`);
      await page.screenshot({path:path.join(output,profile.name,'failure.png')}).catch(()=>{});
    }finally{await context.close();await saveManifest();}
  }
  manifest.status=manifest.errors.length?'failed':'passed';await saveManifest();
  if(manifest.errors.length)throw new Error(manifest.errors.join('\n'));
  console.log(`Browser evidence: ${output}`);
}catch(error){
  manifest.status=browser?'failed':'blocked';manifest.failure=error.message;await saveManifest();
  console.error(`${manifest.status==='blocked'?'Browser launch unavailable':'Browser verification failed'}: ${error.message}`);
  process.exitCode=1;
}finally{if(browser)await browser.close();}
