#!/usr/bin/env python3
"""Small local static server with caching, compression, and byte ranges."""

from email.utils import parsedate_to_datetime
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO
from urllib.parse import parse_qs, urlsplit
import argparse
import gzip
import os
import re
import socket
import threading

try:
    import brotli
except ImportError:  # gzip remains available with the Python standard library.
    brotli = None


class RangeRequestHandler(SimpleHTTPRequestHandler):
    _byte_range = None
    _compressed_cache = {}
    _compressed_cache_lock = threading.Lock()
    _fingerprint = re.compile(r"(?:^|[-_.])[0-9a-fA-F]{8,}(?=[-_.]|$)")
    _compressible_types = {
        "application/javascript",
        "application/json",
        "application/manifest+json",
        "application/wasm",
        "application/xml",
        "image/svg+xml",
        "text/javascript",
    }

    def log_message(self, _format, *_args):
        # This server commonly runs unattended during phone testing. Avoid
        # filling its terminal buffer with range-request logs and stalling new
        # connections after several hours.
        return

    def _cache_control(self):
        request = urlsplit(self.path)
        relative_path = request.path.lstrip("/")
        filename = os.path.basename(relative_path)
        versioned = "v" in parse_qs(request.query)
        fingerprinted = bool(self._fingerprint.search(filename))
        if versioned or fingerprinted:
            return "public, max-age=31536000, immutable"
        if relative_path.startswith("assets/"):
            return "public, max-age=86400"
        return "no-cache"

    @staticmethod
    def _etag(stat, encoding="identity"):
        return f'W/"{stat.st_mtime_ns:x}-{stat.st_size:x}-{encoding}"'

    def _not_modified(self, stat, etag):
        if_none_match = self.headers.get("If-None-Match")
        if if_none_match is not None:
            candidates = {value.strip() for value in if_none_match.split(",")}
            return "*" in candidates or etag in candidates

        if_modified_since = self.headers.get("If-Modified-Since")
        if if_modified_since:
            try:
                requested = parsedate_to_datetime(if_modified_since)
                if requested.tzinfo is None:
                    return False
                return int(stat.st_mtime) <= int(requested.timestamp())
            except (TypeError, ValueError, OverflowError):
                pass
        return False

    def _encoding_quality(self, name):
        accepted = {}
        for item in self.headers.get("Accept-Encoding", "").split(","):
            parts = [part.strip() for part in item.split(";")]
            if not parts[0]:
                continue
            quality = 1.0
            for parameter in parts[1:]:
                if parameter.startswith("q="):
                    try:
                        quality = float(parameter[2:])
                    except ValueError:
                        quality = 0.0
            accepted[parts[0].lower()] = quality
        return accepted.get(name, accepted.get("*", 0.0))

    def _is_compressible(self, content_type, size):
        if size < 1024:
            return False
        mime = content_type.split(";", 1)[0].lower()
        return mime.startswith("text/") or mime in self._compressible_types

    def _content_encoding(self, content_type, size, has_range):
        if has_range or not self._is_compressible(content_type, size):
            return None
        brotli_quality = self._encoding_quality("br") if brotli is not None else 0
        gzip_quality = self._encoding_quality("gzip")
        if brotli_quality > 0 and brotli_quality >= gzip_quality:
            return "br"
        if gzip_quality > 0:
            return "gzip"
        if brotli_quality > 0:
            return "br"
        return None

    @classmethod
    def _compress(cls, path, stat, encoding, source):
        key = (path, stat.st_mtime_ns, stat.st_size, encoding)
        with cls._compressed_cache_lock:
            cached = cls._compressed_cache.get(key)
        if cached is not None:
            return cached

        source.seek(0)
        raw = source.read()
        if encoding == "br":
            encoded = brotli.compress(raw, quality=6)
        else:
            encoded = gzip.compress(raw, compresslevel=9, mtime=0)

        with cls._compressed_cache_lock:
            stale = [
                cached_key
                for cached_key in cls._compressed_cache
                if cached_key[0] == path and cached_key[1:3] != key[1:3]
            ]
            for cached_key in stale:
                del cls._compressed_cache[cached_key]
            cls._compressed_cache[key] = encoded
        return encoded

    def _send_common_headers(self, stat, etag, *, vary=False):
        self.send_header("ETag", etag)
        self.send_header("Cache-Control", self._cache_control())
        self.send_header("Last-Modified", self.date_time_string(stat.st_mtime))
        self.send_header("Accept-Ranges", "bytes")
        if vary:
            self.send_header("Vary", "Accept-Encoding")

    def send_head(self):
        self._byte_range = None
        path = self.translate_path(self.path)
        if os.path.isdir(path):
            if not urlsplit(self.path).path.endswith("/"):
                return super().send_head()
            for index in ("index.html", "index.htm"):
                candidate = os.path.join(path, index)
                if os.path.isfile(candidate):
                    path = candidate
                    break
            else:
                return super().send_head()

        try:
            source = open(path, "rb")
        except OSError:
            self.send_error(404, "File not found")
            return None

        stat = os.fstat(source.fileno())
        size = stat.st_size
        content_type = self.guess_type(path)
        range_header = self.headers.get("Range")
        encoding = self._content_encoding(content_type, size, bool(range_header))
        etag = self._etag(stat, encoding or "identity")
        compressible = self._is_compressible(content_type, size)

        if self._not_modified(stat, etag):
            source.close()
            self.send_response(304)
            self._send_common_headers(stat, etag, vary=compressible)
            self.end_headers()
            return None

        start, end = 0, size - 1
        status = 200
        if range_header:
            match = re.fullmatch(r"bytes=(\d*)-(\d*)", range_header.strip())
            if not match or size == 0:
                source.close()
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{size}")
                self._send_common_headers(stat, etag)
                self.end_headers()
                return None
            first, last = match.groups()
            if first:
                start = int(first)
                end = min(int(last), end) if last else end
            elif last:
                suffix = min(int(last), size)
                start = size - suffix
            else:
                start = size
            if start >= size or end < start:
                source.close()
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{size}")
                self._send_common_headers(stat, etag)
                self.end_headers()
                return None
            status = 206

        body = source
        content_length = end - start + 1 if status == 206 else size
        if encoding:
            encoded = self._compress(path, stat, encoding, source)
            source.close()
            body = BytesIO(encoded)
            content_length = len(encoded)

        self._byte_range = (start, end) if status == 206 else None
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(content_length))
        if encoding:
            self.send_header("Content-Encoding", encoding)
        self._send_common_headers(stat, etag, vary=compressible)
        if status == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        if status == 206:
            body.seek(start)
        return body

    def copyfile(self, source, outputfile):
        if self._byte_range is None:
            try:
                return super().copyfile(source, outputfile)
            except (BrokenPipeError, ConnectionResetError):
                return
        start, end = self._byte_range
        remaining = end - start + 1
        while remaining:
            chunk = source.read(min(64 * 1024, remaining))
            if not chunk:
                break
            try:
                outputfile.write(chunk)
            except (BrokenPipeError, ConnectionResetError):
                break
            remaining -= len(chunk)


class DualStackThreadingHTTPServer(ThreadingHTTPServer):
    """Accept both IPv6 and IPv4 clients on the same local-test port."""

    address_family = socket.AF_INET6

    def server_bind(self):
        self.socket.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
        super().server_bind()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=4175)
    parser.add_argument("--host", default="::")
    args = parser.parse_args()
    server = DualStackThreadingHTTPServer((args.host, args.port), RangeRequestHandler)
    print(f"House app: http://127.0.0.1:{args.port}/", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
