---
name: house-app-builder
description: Adapt House App Starter from a user's house plans, measurements, furniture names and material selections; research, author, preview, integrate and verify the visualization.
---

# House App Builder

Use this workflow when the user asks to adapt the House App Starter to a house
project. The skill is a workflow wrapper; the starter application must be available
in the working project or as an attached archive.

Locate the starter's README.md, GUIDE.md, BUILD_PROMPT.txt, APP_SPEC.md, INPUTS.md,
WORKFLOW.md, VALIDATION.md and SCENE_CONTRACT.md. In the bundled checkout these
are two directories above this file. If installed separately, read the copies
in the supplied starter workspace. Ask for the starter only if it is unavailable.

Follow BUILD_PROMPT.txt and WORKFLOW.md, preserving APP_SPEC.md's viewer behavior.
Inspect available inputs before asking for missing critical facts in small groups.
Maintain structured inputs, source evidence, corrections and estimates in project
files so work can continue without private chat context.

For furniture/lighting, a name is sufficient to start web research. Identify the
exact variant, find specifications and useful reference images, author dimensioned
procedural geometry, inspect several views, refine it, generate a matching thumbnail
and integrate placements. User-provided 3D assets are optional.

Use SCENE_CONTRACT.md's meter coordinates, product ownership, body/suspension
separation, movement bounds, material targeting and explicit media/lighting bindings.
Adapt camera framing and project identity to the new house.

Complete VALIDATION.md, repair concrete failures, and deliver runnable source,
deployment output, source records, visual evidence and concise run/update instructions.
State exact limitations or verification still needed. User instructions take
precedence over this skill's workflow.

Use project/input.json, project/sources.json, project/decisions.json and
project/progress.json as persistent records. Present shell, product/material and
furnished-house review outputs. Continue independent work while questions are
pending; unanswered critical facts stay unresolved. Record browser checks and
geometry renders as different evidence methods.
