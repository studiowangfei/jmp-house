---
name: house-app-builder
description: Adapt House App Starter from a user's house plans, measurements, furniture names and material selections; research, author, preview, integrate and verify the visualization.
---

# House App Builder

Use this workflow when the user asks to adapt the House App Starter to a house
project. The skill is a workflow wrapper; the starter application must be available
in the working project or as an attached archive.

Locate the starter's [README.md](../../README.md) and canonical
[BUILD_PROMPT.txt](../../BUILD_PROMPT.txt) at the checkout root, two directories
above this bundled skill. Guides are under that root's `docs/`: read
[GUIDE.md](../../docs/GUIDE.md), [WORKFLOW.md](../../docs/WORKFLOW.md),
[INPUTS.md](../../docs/INPUTS.md), [APP_SPEC.md](../../docs/APP_SPEC.md),
[SCENE_CONTRACT.md](../../docs/SCENE_CONTRACT.md) and
[VALIDATION.md](../../docs/VALIDATION.md). If installed separately, locate those
same paths in the supplied starter workspace. Ask for the starter only if it is
unavailable.

Preview the prebuilt app with `python3 scripts/serve.py` from the starter root.
The main URL is `http://127.0.0.1:4175/`; product previews use
`http://127.0.0.1:4175/runtime/products.html`. Edit sources under `src/`, geometry
helpers under `src/scene/` and data under `project/`; browser outputs and their
build manifest are generated in `runtime/`. Node/npm is for source builds and
automated verification.

Follow `BUILD_PROMPT.txt` and `docs/WORKFLOW.md`, preserving `docs/APP_SPEC.md`'s viewer behavior.
Inspect available inputs before asking for missing critical facts in small groups.
Maintain structured inputs, source evidence, corrections and estimates in project
files so work can continue without private chat context.

For furniture/lighting, a name is sufficient to start web research. Identify the
exact variant, find specifications and useful reference images, author dimensioned
procedural geometry, inspect several views, refine it, generate a matching thumbnail
and integrate placements. User-provided 3D assets are optional.

Use `docs/SCENE_CONTRACT.md`'s meter coordinates, product ownership, body/suspension
separation, movement bounds, material targeting and explicit media/lighting bindings.
Adapt camera framing and project identity to the new house.

Complete `docs/VALIDATION.md`, repair concrete failures, and deliver runnable source,
deployment output, source records, visual evidence and concise run/update instructions.
State exact limitations or verification still needed. User instructions take
precedence over this skill's workflow.

Use project/input.json, project/sources.json, project/decisions.json and
project/progress.json as persistent records. Present shell, product/material and
furnished-house review outputs. Continue independent work while questions are
pending; unanswered critical facts stay unresolved. Record browser checks and
geometry renders as different evidence methods.
