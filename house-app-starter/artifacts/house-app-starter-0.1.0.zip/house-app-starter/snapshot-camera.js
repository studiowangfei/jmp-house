export function createCenteredSnapshotCamera(camera){
  if(!camera?.isOrthographicCamera)throw new Error('Snapshot centering requires an orthographic camera');
  const snapshotCamera=camera.clone(),halfHeight=(camera.top-camera.bottom)/2;
  snapshotCamera.top=halfHeight;snapshotCamera.bottom=-halfHeight;
  snapshotCamera.userData={...snapshotCamera.userData,viewportShift:{...(snapshotCamera.userData.viewportShift||{}),topFraction:0}};
  snapshotCamera.updateProjectionMatrix();snapshotCamera.updateMatrixWorld(true);return snapshotCamera;
}
