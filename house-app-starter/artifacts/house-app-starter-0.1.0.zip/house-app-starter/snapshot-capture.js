export function centeredAspectCrop(width,height,aspectWidth=4,aspectHeight=3){
  if(!Number.isFinite(width)||!Number.isFinite(height)||width<1||height<1||!Number.isInteger(aspectWidth)||!Number.isInteger(aspectHeight)||aspectWidth<1||aspectHeight<1)throw new Error('Snapshot crop dimensions and aspect must be positive');
  const scale=Math.floor(Math.min(width/aspectWidth,height/aspectHeight));if(scale<1)throw new Error('Snapshot canvas is too small for the requested aspect');
  const cropWidth=scale*aspectWidth,cropHeight=scale*aspectHeight;
  return{x:Math.floor((width-cropWidth)/2),y:Math.floor((height-cropHeight)/2),width:cropWidth,height:cropHeight,aspectWidth,aspectHeight};
}

export function captureCanvasAtAspect(source,{aspectWidth=4,aspectHeight=3,createCanvas=()=>document.createElement('canvas')}={}){
  const crop=centeredAspectCrop(source.width,source.height,aspectWidth,aspectHeight),output=createCanvas();output.width=crop.width;output.height=crop.height;
  const context=output.getContext('2d',{alpha:false});if(!context)throw new Error('Snapshot capture needs a 2D canvas context');
  context.drawImage(source,crop.x,crop.y,crop.width,crop.height,0,0,crop.width,crop.height);
  return new Promise(resolve=>output.toBlob(resolve,'image/png'));
}
