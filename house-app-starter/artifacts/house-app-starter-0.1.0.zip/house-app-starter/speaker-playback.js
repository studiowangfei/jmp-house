const cachedParts=new WeakMap();

function playbackParts(root){
  if(!root)return[];
  if(cachedParts.has(root))return cachedParts.get(root);
  const parts=[];
  root.traverse(part=>{
    const config=part.userData.audioReactive;
    if(!config||typeof config!=='object')return;
    const material=Array.isArray(part.material)?part.material[0]:part.material;
    if(config.kind==='indicator'&&material){
      config.offColor??=material.color.getHex();config.offEmissive??=material.emissive?.getHex()||0;config.offIntensity??=material.emissiveIntensity||0;
    }
    config.restZ??=part.position.z;config.restRotationY??=part.rotation.y;config.restScale??=part.scale.toArray();
    parts.push({part,config,material});
  });
  cachedParts.set(root,parts);return parts;
}

export function updateSpeakerPlaybackVisual(root,{playing=false,currentTime=0,reducedMotion=false}={}){
  const parts=playbackParts(root);if(!parts.length)return false;
  const time=Number.isFinite(currentTime)?Math.max(0,currentTime):0;
  for(const {part,config,material} of parts){
    if(config.kind==='indicator'){
      material.color.set(playing?(config.onColor??'#83b88c'):config.offColor);
      material.emissive?.set(playing?(config.onColor??'#83b88c'):config.offEmissive);
      material.emissiveIntensity=playing?(config.onIntensity??.65):config.offIntensity;
    }else if(config.kind==='dial'){
      part.rotation.y=config.restRotationY-(reducedMotion?0:time*(config.speed??.8));
    }else if(config.kind==='driver'){
      const motion=playing&&!reducedMotion?Math.sin(time*(config.frequency??9)+(config.phase??0)):0;
      part.position.z=config.restZ+motion*(config.travel??.00025);
      const factor=1+motion*(config.radialScale??.002),scale=config.restScale;
      part.scale.set(scale[0]*factor,scale[1]*factor,scale[2]);
    }
  }
  root.userData.audioPlaybackVisualActive=Boolean(playing);return true;
}
