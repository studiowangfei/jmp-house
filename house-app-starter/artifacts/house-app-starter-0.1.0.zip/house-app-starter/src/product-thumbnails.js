import table from '../assets/product-thumbnails/demo-table.png';
import chair from '../assets/product-thumbnails/demo-chair.png';
import sofa from '../assets/product-thumbnails/demo-sofa.png';
import pendant from '../assets/product-thumbnails/demo-pendant.png';
import lamp from '../assets/product-thumbnails/demo-floor-lamp.png';
import mirror from '../assets/product-thumbnails/demo-mirror.png';
import speaker from '../assets/product-thumbnails/demo-speaker.png';
import plant from '../assets/product-thumbnails/demo-plant.png';

export const productThumbnailSources=Object.freeze({
  'demo-table':table,'demo-chair':chair,'demo-sofa':sofa,'demo-pendant':pendant,
  'demo-floor-lamp':lamp,'demo-mirror':mirror,'demo-speaker':speaker,'demo-plant':plant,
});
