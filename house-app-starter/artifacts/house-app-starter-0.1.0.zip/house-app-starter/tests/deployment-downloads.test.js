import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdtemp,mkdir,writeFile,readFile,readdir,rm} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const verifier=fileURLToPath(new URL('../scripts/verify-deployment.py',import.meta.url));
const checksum=data=>createHash('sha256').update(data).digest('hex');
const fingerprint=data=>({bytes:data.length,sha256:checksum(data)});
const starterPath='downloads/house-app-starter-0.1.0.zip';
const promptPath='downloads/BUILD_PROMPT.txt';
const manifestPath='downloads-manifest.json';
const buildManifestPath='runtime/build-manifest.json';
const prompt=Buffer.from('Use the neutral starter folder to build your own house app.\n');

async function put(directory,relative,data){
  const target=path.join(directory,relative);await mkdir(path.dirname(target),{recursive:true});await writeFile(target,data);
}

async function fixture(t,{downloads=true}={}){
  const directory=await mkdtemp(path.join(tmpdir(),'house-deployment-test-'));t.after(()=>rm(directory,{recursive:true,force:true}));
  const runtime={
    'runtime/app.bundle.js':Buffer.from('console.log("house fixture");\n'),
    'runtime/products.bundle.js':Buffer.from('console.log("products fixture");\n'),
    'runtime/styles.css':Buffer.from('body{margin:0}\n'),
    'runtime/products.css':Buffer.from('body{background:white}\n'),
  };
  for(const [html,css,bundle] of [['index.html','runtime/styles.css','runtime/app.bundle.js'],['runtime/products.html','runtime/products.css','runtime/products.bundle.js']]){
    const cssUrl=path.posix.relative(path.posix.dirname(html),css),bundleUrl=path.posix.relative(path.posix.dirname(html),bundle);
    runtime[html]=Buffer.from(`<html><head><link href="./${cssUrl}?v=sha256-${checksum(runtime[css]).slice(0,16)}" rel="stylesheet"></head><body><script src="./${bundleUrl}?v=sha256-${checksum(runtime[bundle]).slice(0,16)}"></script></body></html>\n`);
  }
  for(const [relative,data] of Object.entries(runtime))await put(directory,relative,data);
  const buildManifest={schemaVersion:1,version:'0.1.0',projectId:'synthetic-test-home',inputs:{},files:Object.fromEntries(Object.entries(runtime).map(([relative,data])=>[relative,fingerprint(data)]))};
  const buildBytes=Buffer.from(JSON.stringify(buildManifest,null,2)+'\n');await put(directory,buildManifestPath,buildBytes);
  let downloadsManifest=null;
  if(downloads){
    await put(directory,promptPath,prompt);
    const makeZip=spawnSync('python3',['-c',`import hashlib,json,sys,zipfile
payload=b'Use the neutral starter folder to build your own house app.\\n'
record={'schemaVersion':1,'name':'house-app-starter','version':'0.1.0','files':{'BUILD_PROMPT.txt':{'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}}}
with zipfile.ZipFile(sys.argv[1],'w',compression=zipfile.ZIP_DEFLATED) as archive:
    archive.writestr('house-app-starter/BUILD_PROMPT.txt',payload)
    archive.writestr('house-app-starter/starter-manifest.json',json.dumps(record,sort_keys=True)+'\\n')`,path.join(directory,starterPath)],{encoding:'utf8'});
    assert.equal(makeZip.status,0,makeZip.stderr);
    downloadsManifest={schemaVersion:1,buildManifestSha256:checksum(buildBytes),starterVersion:'0.1.0',files:{[starterPath]:fingerprint(await readFile(path.join(directory,starterPath))),[promptPath]:fingerprint(prompt)}};
    await put(directory,manifestPath,JSON.stringify(downloadsManifest,null,2)+'\n');
  }
  return {directory,buildManifest,downloadsManifest};
}

function verify(directory){
  const result=spawnSync('python3',[verifier,'--root',directory,'--dist'],{encoding:'utf8'});
  assert.equal(result.error,undefined,'The Python verifier must launch successfully');return result;
}
function accepted(directory){const result=verify(directory);assert.equal(result.status,0,result.stderr||result.stdout);}
function rejected(directory){const result=verify(directory);assert.notEqual(result.status,0,'A changed or undeclared deployment artifact must be rejected');assert.match(result.stderr,/download|manifest|inventory|file|version|path/i);}

async function deploymentTools(directory){
  for(const filename of ['build-deployment.py','verify-deployment.py','verify_deployment_support.py','package-starter.py'])await put(directory,'scripts/'+filename,await readFile(new URL(`../scripts/${filename}`,import.meta.url)));
}
async function filesUnder(directory,prefix=''){
  const files=[];for(const entry of await readdir(directory,{withFileTypes:true})){
    const relative=prefix?prefix+'/'+entry.name:entry.name;
    if(entry.isDirectory())files.push(...await filesUnder(path.join(directory,entry.name),relative));else if(entry.isFile())files.push(relative);
  }return files.sort();
}
function writeFrozenArchive(archivePath,{legacy=false,markdownPrompt=false}={}){
  const prompt='Use this frozen starter, independent of the current house source.\n';
  const payloads=markdownPrompt?{'BUILD_PROMPT.md':'# Copy/paste prompt\n\n```text\n'+prompt+'```\n'}:{'BUILD_PROMPT.txt':prompt};
  if(legacy){payloads['app.js']='console.log("legacy starter");\n';payloads['build-manifest.json']='{"schemaVersion":1,"files":{}}\n';}
  else{payloads['src/app.js']='console.log("organized starter");\n';payloads['runtime/build-manifest.json']='{"schemaVersion":1,"files":{}}\n';}
  const made=spawnSync('python3',['-c',`import hashlib,json,sys,zipfile
payloads={name:text.encode('utf-8') for name,text in json.loads(sys.argv[2]).items()}
record={'schemaVersion':1,'name':'house-app-starter','version':'0.1.0','files':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in payloads.items()}}
with zipfile.ZipFile(sys.argv[1],'w',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,data in payloads.items(): archive.writestr('house-app-starter/'+name,data)
    archive.writestr('house-app-starter/starter-manifest.json',json.dumps(record,sort_keys=True)+'\\n')`,archivePath,JSON.stringify(payloads)],{encoding:'utf8'});
  assert.equal(made.status,0,made.stderr);return{payloads,prompt};
}

test('ordinary deployment remains runtime-only without requiring a starter download manifest',async t=>{
  const {directory}=await fixture(t,{downloads:false});accepted(directory);
});

test('the default deployment builder excludes source downloads even when they exist in its checkout',async t=>{
  const {directory,buildManifest}=await fixture(t);
  await deploymentTools(directory);
  const output=path.join(directory,'runtime-release'),built=spawnSync('python3',[path.join(directory,'scripts/build-deployment.py'),'--output',output],{encoding:'utf8'});assert.equal(built.status,0,built.stderr||built.stdout);
  assert.deepEqual(await filesUnder(output),[...Object.keys(buildManifest.files),buildManifestPath].sort());accepted(output);
});

test('demo deployment accepts two declared downloads bound to its exact runtime manifest',async t=>{
  const {directory,buildManifest,downloadsManifest}=await fixture(t);assert.equal(Object.keys(buildManifest.files).length,6);assert.deepEqual(Object.keys(downloadsManifest.files).sort(),[promptPath,starterPath].sort());accepted(directory);
});

test('organized and legacy frozen starters retain their own archive and prompt during deployment',async t=>{
  for(const options of [{legacy:false},{legacy:true},{legacy:true,markdownPrompt:true}])await t.test(options.markdownPrompt?'early legacy Markdown prompt':options.legacy?'legacy flat starter':'organized starter',async child=>{
    const {directory}=await fixture(child,{downloads:false});await deploymentTools(directory);
    await put(directory,'BUILD_PROMPT.txt','A different prompt from the customized checkout\n');
    const archive=path.join(directory,'frozen.zip'),frozen=writeFrozenArchive(archive,options),output=path.join(directory,'frozen-release');
    const built=spawnSync('python3',[path.join(directory,'scripts/build-deployment.py'),'--output',output,'--starter-pack',archive],{encoding:'utf8'});assert.equal(built.status,0,built.stderr||built.stdout);
    assert.deepEqual(await readFile(path.join(output,starterPath)),await readFile(archive));assert.equal(await readFile(path.join(output,promptPath),'utf8'),frozen.prompt);accepted(output);
  });
});

test('changed starter ZIP or copy/paste prompt fails download integrity verification',async t=>{
  for(const relative of [starterPath,promptPath])await t.test(relative,async child=>{
    const {directory}=await fixture(child);const data=await readFile(path.join(directory,relative));data[0]^=1;await put(directory,relative,data);rejected(directory);
  });
});

test('declared downloads cannot be missing',async t=>{
  for(const relative of [starterPath,promptPath])await t.test(relative,async child=>{
    const {directory}=await fixture(child);await rm(path.join(directory,relative));rejected(directory);
  });
});

test('downloads from an older runtime manifest are rejected even when their files remain unchanged',async t=>{
  const {directory,buildManifest}=await fixture(t);buildManifest.projectId='different-synthetic-home';await put(directory,buildManifestPath,JSON.stringify(buildManifest,null,2)+'\n');rejected(directory);
});

test('extra source files or undeclared downloads cannot enter a deployed demo',async t=>{
  for(const relative of ['app.js','downloads/private-notes.md'])await t.test(relative,async child=>{
    const {directory}=await fixture(child);await put(directory,relative,'Unrequested source fixture\n');rejected(directory);
  });
});

test('a downloads manifest cannot legitimize an additional source document',async t=>{
  const {directory,downloadsManifest}=await fixture(t),relative='downloads/private-notes.md',data=Buffer.from('Unrequested document fixture\n');await put(directory,relative,data);downloadsManifest.files[relative]=fingerprint(data);await put(directory,manifestPath,JSON.stringify(downloadsManifest,null,2)+'\n');rejected(directory);
});

test('download files require their optional manifest rather than bypassing the runtime inventory',async t=>{
  const {directory}=await fixture(t);await rm(path.join(directory,manifestPath));rejected(directory);
});

test('download manifest paths cannot escape the downloads directory',async t=>{
  const {directory,downloadsManifest}=await fixture(t),data=Buffer.from('Source fixture\n');await put(directory,'source.txt',data);downloadsManifest.files['downloads/../source.txt']=fingerprint(data);await put(directory,manifestPath,JSON.stringify(downloadsManifest,null,2)+'\n');rejected(directory);
});

test('the declared starter version must agree with the downloadable archive filename',async t=>{
  const {directory,downloadsManifest}=await fixture(t);downloadsManifest.starterVersion='0.2.0';await put(directory,manifestPath,JSON.stringify(downloadsManifest,null,2)+'\n');rejected(directory);
});

test('an empty downloads manifest cannot silently remove the promised starter and prompt',async t=>{
  const {directory,downloadsManifest}=await fixture(t);downloadsManifest.files={};await put(directory,manifestPath,JSON.stringify(downloadsManifest,null,2)+'\n');rejected(directory);
});
