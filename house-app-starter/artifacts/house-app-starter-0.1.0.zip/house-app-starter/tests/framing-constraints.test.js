import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {createHomeView,createDaylightFrame} from '../default-view.js';
import {constrainWallPosition} from '../arrangement-constraints.js';

const close=(actual,expected)=>assert.ok(Math.abs(actual-expected)<1e-7,`${actual} differs from ${expected}`);

test('a large translated home remains centered and fully inside its orthographic home framing',()=>{
  const bounds=new THREE.Box3(new THREE.Vector3(950,-.2,-710),new THREE.Vector3(1018,8,-688)),view=createHomeView(THREE,bounds);
  assert.deepEqual(view.target,[984,3.9,-699]);
  const camera=new THREE.OrthographicCamera(-view.halfWidth,view.halfWidth,view.halfHeight,-view.halfHeight,.1,1000);
  camera.position.fromArray(view.target).add(new THREE.Vector3().fromArray(view.offset));camera.lookAt(new THREE.Vector3().fromArray(view.target));camera.zoom=view.zoom;camera.updateProjectionMatrix();camera.updateMatrixWorld(true);
  for(const x of [950,1018])for(const y of [-.2,8])for(const z of [-710,-688]){
    const projected=new THREE.Vector3(x,y,z).project(camera);assert.ok(Math.abs(projected.x)<1&&Math.abs(projected.y)<1&&Math.abs(projected.z)<1,'Every foundation/ceiling corner must fit inside the viewing volume');
  }
  const originView=createHomeView(THREE,bounds.clone().translate(new THREE.Vector3(-950,0,710)));
  close(view.halfWidth,originView.halfWidth);close(view.halfHeight,originView.halfHeight);view.offset.forEach((value,index)=>close(value,originView.offset[index]));
});

test('framing follows an authored focal target while still containing the full house',()=>{
  const bounds=new THREE.Box3(new THREE.Vector3(-8,0,-3),new THREE.Vector3(4,3,11)),target=[-4,1.5,1],view=createHomeView(THREE,bounds,{target,margin:1.45});
  assert.deepEqual(view.target,target);
  const camera=new THREE.OrthographicCamera(-view.halfWidth,view.halfWidth,view.halfHeight,-view.halfHeight,.1,500);
  camera.position.fromArray(target).add(new THREE.Vector3().fromArray(view.offset));camera.lookAt(new THREE.Vector3().fromArray(target));camera.updateProjectionMatrix();camera.updateMatrixWorld(true);
  for(const corner of [bounds.min,bounds.max,new THREE.Vector3(bounds.min.x,bounds.max.y,bounds.max.z),new THREE.Vector3(bounds.max.x,bounds.min.y,bounds.min.z)]){
    const projected=corner.clone().project(camera);assert.ok(Math.abs(projected.x)<1&&Math.abs(projected.y)<1,'An off-center focal target must not crop the house');
  }
});

test('Daylight aims at a translated large home and keeps every house corner in its shadow volume',()=>{
  const bounds=new THREE.Box3(new THREE.Vector3(950,-.2,-710),new THREE.Vector3(1018,8,-688)),light=createDaylightFrame(THREE,bounds);
  assert.deepEqual(light.target.toArray(),[984,3.9,-699]);
  const shadow=new THREE.OrthographicCamera(-light.span,light.span,light.span,-light.span,light.near,light.far);shadow.position.copy(light.position);shadow.lookAt(light.target);shadow.updateProjectionMatrix();shadow.updateMatrixWorld(true);
  for(const x of [950,1018])for(const y of [-.2,8])for(const z of [-710,-688]){
    const point=new THREE.Vector3(x,y,z).project(shadow);assert.ok(Math.abs(point.x)<1&&Math.abs(point.y)<1&&Math.abs(point.z)<1,'A translated footprint must receive shadows across its complete extent');
  }
  const centered=createDaylightFrame(THREE,bounds.clone().translate(new THREE.Vector3(-984,-3.9,699)));close(light.span,centered.span);
  light.position.clone().sub(light.target).toArray().forEach((value,index)=>close(value,centered.position.getComponent(index)));
});

test('wall-mounted items stay on either wall plane and clamp their complete rendered extent',()=>{
  const xWall={axis:'x',planeX:6,minZ:-2,maxZ:3,minY:.1,maxY:2.7},xStart={x:6.03,y:1.2,z:0},offsets={minX:-.03,maxX:.03,minY:-.4,maxY:.4,minZ:-.6,maxZ:.6};
  const onX=constrainWallPosition({x:-100,y:10,z:100},xStart,xWall,offsets);
  close(onX.x,6.03);close(onX.z+offsets.maxZ,3);close(onX.y+offsets.maxY,2.7);assert.ok(onX.z+offsets.minZ>=xWall.minZ);
  const zWall={axis:'z',planeZ:-4,minX:10,maxX:16,minY:.1,maxY:2.7},zStart={x:12,y:1.2,z:-3.97},zOffsets={minX:-.6,maxX:.6,minY:-.4,maxY:.4,minZ:-.03,maxZ:.03};
  const onZ=constrainWallPosition({x:-100,y:-10,z:100},zStart,zWall,zOffsets);
  close(onZ.z,-3.97);close(onZ.x+zOffsets.minX,10);close(onZ.y+zOffsets.minY,.1);assert.ok(onZ.x+zOffsets.maxX<=zWall.maxX);
});

test('Plan dragging preserves wall-mount height and valid interior movements remain unclamped',()=>{
  const wall={axis:'z',planeZ:8,minX:-5,maxX:5,minY:0,maxY:3},start={x:0,y:1.3,z:8.02},offsets={minX:-.2,maxX:.2,minY:-.25,maxY:.25,minZ:0,maxZ:.04};
  const planar=constrainWallPosition({x:2,y:99,z:-99},start,wall,offsets,{allowHeight:false});
  assert.deepEqual(planar,{x:2,y:1.3,z:8.02});
  const free=constrainWallPosition({x:-2,y:1.8,z:-99},start,wall,offsets);assert.deepEqual(free,{x:-2,y:1.8,z:8.02});
});

test('a product larger than the wall is retained at its starting position instead of moved to invalid bounds',()=>{
  const start={x:0,y:1,z:2},wall={axis:'z',planeZ:2,minX:-.3,maxX:.3,minY:0,maxY:2},offsets={minX:-.5,maxX:.5,minY:-.2,maxY:.2,minZ:0,maxZ:.04};
  const result=constrainWallPosition({x:100,y:1,z:100},start,wall,offsets);assert.deepEqual(result,start);
});
