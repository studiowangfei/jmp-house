import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from 'three';
import {buildHouse} from '../model.js';
import {projectConfig} from '../project-config.js';
import demoBrief from '../project/demo-brief.json' with {type:'json'};

const near=(actual,expected,message,tolerance=1e-5)=>assert.ok(Math.abs(actual-expected)<=tolerance,`${message}: ${actual} vs ${expected}`);
const cloneProject=()=>structuredClone(projectConfig);
const descendants=(root,predicate)=>{const objects=[];root.traverse(object=>{if(predicate(object))objects.push(object);});return objects;};
function contains(x,z,polygon){
  let inside=false;
  for(let a=polygon.length-1,b=0;b<polygon.length;a=b++){
    if((polygon[a][1]>z)!==(polygon[b][1]>z)&&x<(polygon[b][0]-polygon[a][0])*(z-polygon[a][1])/(polygon[b][1]-polygon[a][1])+polygon[a][0])inside=!inside;
  }
  return inside;
}
function disposeHouse(house){
  const geometries=new Set(),materials=new Set(),textures=new Set();
  for(const layer of Object.values(house.layers))layer.traverse(object=>{
    if(object.geometry)geometries.add(object.geometry);
    for(const material of Array.isArray(object.material)?object.material:object.material?[object.material]:[]){
      materials.add(material);for(const value of Object.values(material))if(value?.isTexture)textures.add(value);
    }
  });
  for(const {mirror} of house.reflectors)mirror.dispose();
  for(const geometry of geometries)geometry.dispose();for(const texture of textures)texture.dispose();for(const material of materials)material.dispose();
}

test('the neutral house has finite geometry, its supplied six-corner footprint and the confirmed height',()=>{
  const result=buildHouse(T,{project:projectConfig});
  try{
    assert.deepEqual(result.movementBoundary,demoBrief.house.footprint.map(([x,z])=>({x,z})));
    assert.equal(result.exterior.length,6);assert.equal(result.wallSchedule.length,9);
    const foundation=result.layers.architecture.getObjectByName('Foundation'),bounds=new T.Box3().setFromObject(foundation);
    near(bounds.min.x,-5.09,'Foundation west face');near(bounds.max.x,5.09,'Foundation east face');
    near(bounds.min.z,-4.09,'Foundation rear face');near(bounds.max.z,4.09,'Foundation front face');
    near(bounds.max.y,projectConfig.house.floorLevel-.003,'Foundation stays below the finished-floor datum');
    let meshCount=0;
    for(const layer of Object.values(result.layers))layer.traverse(object=>{
      if(!object.isMesh)return;meshCount++;
      for(const [name,attribute] of Object.entries(object.geometry.attributes)){
        for(const value of attribute.array)assert.ok(Number.isFinite(value),`${object.name}: ${name} contains a nonfinite value`);
      }
      object.geometry.computeBoundingBox();const size=object.geometry.boundingBox.getSize(new T.Vector3());
      assert.ok([size.x,size.y,size.z].filter(value=>value>1e-7).length>=2,`${object.name} has a collapsed envelope`);
    });
    assert.ok(meshCount>70,'The demo must include architecture and feature geometry');
    for(const wall of result.wallSchedule){
      const wallBounds=new T.Box3().setFromObject(wall.group);
      near(wallBounds.min.y,0,`${wall.id} starts at the floor`);near(wallBounds.max.y,2.7,`${wall.id} reaches the ceiling`);
    }
  }finally{disposeHouse(result);}
});

test('rendered floor regions cover the house once and leave the entry notch empty',()=>{
  const result=buildHouse(T,{project:projectConfig});
  try{
    const floors=result.layers.architecture.children.filter(object=>object.userData.floorRegion),ray=new T.Raycaster();let covered=0,outside=0;
    assert.equal(floors.length,4);
    for(let x=-4.913;x<4.99;x+=.373)for(let z=-3.927;z<3.99;z+=.367){
      ray.set(new T.Vector3(x,1,z),new T.Vector3(0,-1,0));
      const floorHits=new Set(ray.intersectObjects(floors,false).map(hit=>hit.object));
      if(contains(x,z,projectConfig.house.footprint)){assert.equal(floorHits.size,1,`Floor coverage at ${x},${z}`);covered++;}
      else{assert.equal(floorHits.size,0,`No floor outside the footprint at ${x},${z}`);outside++;}
    }
    assert.ok(covered>400&&outside>20,'Coverage checks must sample both the house and notch');
    for(const floor of floors){
      near(new T.Box3().setFromObject(floor).min.y,0,`${floor.name} shares the finished floor`);
      assert.equal(floor.userData.materialCatalogKey,projectConfig.house.rooms.find(room=>room.id===floor.userData.floorRegion.id).material);
    }
  }finally{disposeHouse(result);}
});

test('room finishes have no competing upward foundation surfaces underneath them',()=>{
  const result=buildHouse(T,{project:projectConfig});
  try{
    const foundation=result.layers.architecture.getObjectByName('Foundation'),floors=result.layers.architecture.children.filter(object=>object.userData.floorRegion),ray=new T.Raycaster();
    assert.equal(foundation.userData.interiorCapRemoved,true);
    let checked=0;
    for(let x=-4.913;x<4.99;x+=.373)for(let z=-3.927;z<3.99;z+=.367){
      if(!contains(x,z,projectConfig.house.footprint))continue;
      ray.set(new T.Vector3(x,5,z),new T.Vector3(0,-1,0));
      const finishHits=new Set(ray.intersectObjects(floors,false).map(hit=>hit.object));
      assert.equal(finishHits.size,1,`One visible finish at ${x},${z}`);
      const competingHits=ray.intersectObject(foundation,true).filter(hit=>hit.face.normal.y>.9);
      assert.equal(competingHits.length,0,`No foundation cap behind the finish at ${x},${z}`);checked++;
    }
    assert(checked>400,'Verify floor ownership throughout every room');
    const ledge=foundation.getObjectByName('Foundation outside ledge');assert(ledge);
    ray.set(new T.Vector3(-5.045,5,-2),new T.Vector3(0,-1,0));
    assert(ray.intersectObject(ledge,false).length>0,'The outer slab ledge remains visible');
  }finally{disposeHouse(result);}
});

test('every scheduled opening is a real wall void and exterior normals face away from the house',()=>{
  const result=buildHouse(T,{project:projectConfig});
  try{
    const ray=new T.Raycaster();let openingCount=0;
    for(const wall of result.wallSchedule){
      const surfaces=wall.group.children.filter(object=>object.name==='wall surface');
      for(const opening of wall.openings){
        const local=new T.Vector3((opening.from+opening.to)/2,opening.sill+opening.height/2,wall.thickness+.25);
        ray.set(wall.group.localToWorld(local),new T.Vector3(0,0,-1).transformDirection(wall.group.matrixWorld));
        ray.far=1;
        assert.equal(ray.intersectObjects(surfaces,false).length,0,`${wall.id} must leave its ${opening.type} opening empty`);openingCount++;
      }
      ray.set(wall.group.localToWorld(new T.Vector3(.12,1.3,wall.thickness+.25)),new T.Vector3(0,0,-1).transformDirection(wall.group.matrixWorld));ray.far=1;
      assert.ok(ray.intersectObjects(surfaces,false).length>0,`${wall.id} must retain a solid wall segment`);
    }
    assert.equal(openingCount,9);
    for(const {group,normal} of result.exterior){
      near(normal.length(),1,'Exterior normal has unit length');
      const wall=result.wallSchedule.find(record=>record.group===group),x=(wall.a[0]+wall.b[0])/2,z=(wall.a[1]+wall.b[1])/2;
      assert.equal(contains(x-normal.x*.02,z-normal.z*.02,projectConfig.house.footprint),true,'Normal points away from the interior');
      assert.equal(contains(x+normal.x*.02,z+normal.z*.02,projectConfig.house.footprint),false,'Normal points outside the footprint');
    }
    for(const glazing of result.glazingGroups){
      assert.equal(glazing.parent.name,glazing.userData.hostWall,'Cutaway must hide a glazing assembly with its host wall');
      assert.ok(descendants(glazing,object=>object.userData.glazing).length>0);
    }
  }finally{disposeHouse(result);}
});

test('all eight demo products are placed with unique movement identities and correct floor or surface datums',()=>{
  const result=buildHouse(T,{project:projectConfig});
  try{
    const items=Object.values(result.layers).flatMap(layer=>descendants(layer,object=>object.userData.movableItem));
    assert.equal(new Set(items.map(root=>root.userData.movableItem.id)).size,items.length,'Arrange identities must remain unique');
    const productRoots=items.filter(root=>root.userData.productId);
    assert.deepEqual(new Set(productRoots.map(root=>root.userData.productId)),new Set(projectConfig.products.map(product=>product.id)));
    for(const root of productRoots){
      const bounds=new T.Box3().setFromObject(root.getObjectByName('product body')),movement=root.userData.movableItem;
      if(movement.constraint==='floor')near(bounds.min.y,0,`${root.name} rests on the finished floor`);
      if(movement.constraint==='surface')near(bounds.min.y,movement.surfaceBounds.planeY,`${root.name} retains its supported body datum`);
      if(movement.constraint==='wall')assert.ok(result.wallSchedule.some(wall=>wall.id===movement.hostWall));
    }
    const gallery=result.bindings.gallery.root,mirror=result.reflectors[0].group;
    assert.equal(gallery.userData.movableItem.wallBounds.axis,'z','Rear gallery wall has a fixed Z normal');
    assert.equal(mirror.userData.movableItem.wallBounds.axis,'x','Entry mirror wall has a fixed X normal');
    assert.equal(mirror.userData.movableItem.duplicateMode,'static-mirror');
  }finally{disposeHouse(result);}
});

test('gallery, live mirror, audio, TV, fireplace, shelves and landscape expose functional scene targets',()=>{
  const videoTexture=new T.Texture(),fireTexture=new T.Texture(),result=buildHouse(T,{project:projectConfig,tvVideoTexture:videoTexture,fireplaceFireTexture:fireTexture});
  try{
    const {gallery,audio,tv,fireplace,landscape}=result.bindings;
    assert.equal(gallery.frames.length,6);assert.deepEqual(gallery.frames.map(frame=>frame.userData.galleryFrame.index),[0,1,2,3,4,5]);
    assert.ok(gallery.frames.every(frame=>frame.parent===gallery.root&&frame.rotation.y===0),'Photo frames use local XY with +Z fronts');
    assert.ok(audio.root);assert.ok(descendants(audio.root,object=>object.userData.audioReactive).length>=3);
    assert.equal(tv.display.material.map,videoTexture);assert.equal(fireplace.flames.material.map,fireTexture);
    assert.ok(fireplace.root.getObjectByName('illustrated fireplace fire'));
    const animator=result.animators.find(record=>record.name==='illustrated fireplace fire');assert.equal(animator.isActive(),true);animator.update(.4);assert.ok(Number.isFinite(fireplace.flames.scale.y));
    fireplace.root.getObjectByName('illustrated fireplace fire').visible=false;assert.equal(animator.isActive(),false);
    assert.equal(result.reflectors.length,1);assert.equal(result.reflectors[0].mirror.isReflector,true);
    assert.equal(result.reflectors[0].mirror.parent,result.reflectors[0].group,'Live mirror remains directly replaceable for static duplicates');
    const shelf=result.layers.cabinetry.getObjectByName('open-shelf');assert.equal(shelf.userData.shelfLighting.cells.length,8);
    for(const cell of shelf.userData.shelfLighting.cells){assert.ok(cell.min.every((value,index)=>value<cell.max[index]));assert.equal(cell.front,'+Z');}
    assert.equal(landscape.billboards.length,1);assert.equal(landscape.bases.length,1);
    landscape.updateView('plan');assert.equal(landscape.billboards[0].getObjectByName('Tree canopy Plan').visible,true);assert.equal(landscape.billboards[0].getObjectByName('Tree canopy Axon').visible,false);
    landscape.updateView('axon');assert.equal(landscape.billboards[0].getObjectByName('Tree canopy Axon').visible,true);
  }finally{disposeHouse(result);}
});

test('the TV mount touches its real host wall and stays attached when the cabinet moves',()=>{
  for(const movedCabinet of [false,true]){
    const project=cloneProject();
    if(movedCabinet){
      project.house.floorLevel=.12;project.house.ceilingHeight=3.05;
      const cabinet=project.house.builtIns.find(record=>record.type==='media');cabinet.position[2]=.9;cabinet.size[1]=.65;delete cabinet.hostWall;
    }
    const result=buildHouse(T,{project});
    try{
      const {mount,hostWall,screen,display}=result.bindings.tv,plate=mount.getObjectByName('TV wall mounting plate');
      assert.equal(hostWall.name,'wall:terrace');assert.equal(mount.parent.userData.builtInType,'media');
      const front=new T.Vector3(0,0,1).transformDirection(plate.matrixWorld),ray=new T.Raycaster(plate.getWorldPosition(new T.Vector3()),front.clone().negate(),0,.1);
      const hit=ray.intersectObjects(hostWall.children.filter(object=>object.name==='wall surface'),false)[0];assert(hit);
      near(hit.distance,plate.geometry.parameters.depth/2,'Mounting plate rear face touches the wall');
      const plateFront=plate.localToWorld(new T.Vector3(0,0,plate.geometry.parameters.depth/2)),screenBack=screen.localToWorld(new T.Vector3(0,0,-screen.geometry.parameters.depth/2));
      near(plateFront.distanceTo(screenBack),0,'TV back touches the mounting plate');
      near(screen.getWorldPosition(new T.Vector3()).y,project.house.floorLevel+1.51,'TV installation height');
      assert(new T.Vector3(0,0,1).transformDirection(display.matrixWorld).dot(front)>.999,'Video faces into the room');
    }finally{disposeHouse(result);}
  }
});

test('fixture light anchors follow normalized emitter geometry and pendant canopies meet the ceiling',()=>{
  const result=buildHouse(T,{project:projectConfig});
  try{
    const fixtures=result.layers.lighting.children.filter(root=>root.userData.fixtureLight);assert.equal(fixtures.length,2);
    for(const fixture of fixtures){
      const emitter=descendants(fixture,object=>object.userData.lightEmitter)[0],actual=emitter.getWorldPosition(new T.Vector3()),anchor=fixture.localToWorld(new T.Vector3().fromArray(fixture.userData.fixtureLight.anchor));
      near(actual.distanceTo(anchor),0,`${fixture.name} glow attaches to its actual emitter`);
      const bodyBounds=new T.Box3().setFromObject(fixture.getObjectByName('product body'));
      if(fixture.userData.productId==='demo-pendant'){near(new T.Box3().setFromObject(fixture).max.y,2.7,'Ceiling canopy upper face');near(bodyBounds.min.y,1.62,'Independent fixture-body installation height');}
    }
  }finally{disposeHouse(result);}
});

test('a second input changes the measured house width, floor datum and ceiling without warping product envelopes',()=>{
  const project=cloneProject();project.house.ceilingHeight=3.05;project.house.floorLevel=.12;
  const expandRight=point=>[point[0]===5?6:point[0],point[1]];
  project.house.footprint=project.house.footprint.map(expandRight);
  for(const room of project.house.rooms)room.polygon=room.polygon.map(expandRight);
  for(const wall of project.house.partitions){wall.a=expandRight(wall.a);wall.b=expandRight(wall.b);}
  project.house.dimensions.width=11;
  const result=buildHouse(T,{project});
  try{
    const foundation=new T.Box3().setFromObject(result.layers.architecture.getObjectByName('Foundation'));
    near(foundation.max.x,6.09,'New right exterior face');near(foundation.max.y,.117,'Foundation below the new finished-floor datum');
    for(const wall of result.wallSchedule){near(wall.height,3.05,'New wall height');near(new T.Box3().setFromObject(wall.group).max.y,3.17,'New ceiling level');}
    const table=result.layers.furniture.children.find(root=>root.userData.productId==='demo-table'),size=new T.Box3().setFromObject(table.getObjectByName('product body')).getSize(new T.Vector3());
    near(size.x,1.6,'Table physical width');near(size.z,.85,'Table physical depth');near(size.y,.74,'Table physical height');
    const pendant=result.layers.lighting.children.find(root=>root.userData.productId==='demo-pendant');
    near(new T.Box3().setFromObject(pendant).max.y,3.17,'Pendant ceiling attachment follows the new ceiling');
    near(new T.Box3().setFromObject(pendant.getObjectByName('product body')).min.y,1.74,'Fixture body retains its requested height above the new floor');
  }finally{disposeHouse(result);}
});

test('contradictory dimensions and floor regions fail before model construction',()=>{
  const invalidHeight=cloneProject();invalidHeight.house.ceilingHeight=0;
  assert.throws(()=>buildHouse(T,{project:invalidHeight}),/ceilingHeight must be positive/);
  const invalidOpening=cloneProject();invalidOpening.house.exteriorWalls[0].openings[0].to=25;
  assert.throws(()=>buildHouse(T,{project:invalidOpening}),/invalid or overlapping opening/);
  const inconsistentWidth=cloneProject();inconsistentWidth.house.dimensions.width=14;
  assert.throws(()=>buildHouse(T,{project:inconsistentWidth}),/width conflicts with the footprint/);
  const overlappingFloors=cloneProject();overlappingFloors.house.rooms[1].polygon=structuredClone(overlappingFloors.house.rooms[0].polygon);
  assert.throws(()=>buildHouse(T,{project:overlappingFloors}),/floor regions overlap/);
  const missingFloor=cloneProject();missingFloor.house.rooms.splice(2,1);
  assert.throws(()=>buildHouse(T,{project:missingFloor}),/floor regions leave a gap/);
  const skewedPlan=cloneProject();skewedPlan.house.footprint[1][1]=-.1;
  assert.throws(()=>buildHouse(T,{project:skewedPlan}),/orthogonal edges/);
});

test('wall mount axes, mounting planes and bounds must match their actual host walls',()=>{
  const wrongGalleryAxis=cloneProject();wrongGalleryAxis.house.gallery.wallBounds.axis='x';
  assert.throws(()=>buildHouse(T,{project:wrongGalleryAxis}),/gallery wallBounds.axis must match.*normal axis z/);
  const wrongMirrorAxis=cloneProject();wrongMirrorAxis.house.placements.find(item=>item.role==='mirror').wallBounds.axis='z';
  assert.throws(()=>buildHouse(T,{project:wrongMirrorAxis}),/demo-mirror-1 wallBounds.axis must match.*normal axis x/);
  const wrongPlane=cloneProject();wrongPlane.house.gallery.wallBounds.planeZ=-1;
  assert.throws(()=>buildHouse(T,{project:wrongPlane}),/mounting plane is not near its host wall/);
  const wrongTangent=cloneProject();wrongTangent.house.placements.find(item=>item.role==='mirror').wallBounds.minZ=0;
  assert.throws(()=>buildHouse(T,{project:wrongTangent}),/tangent bounds lie outside its host wall/);
  const wrongHeight=cloneProject();wrongHeight.house.gallery.wallBounds.maxY=4;
  assert.throws(()=>buildHouse(T,{project:wrongHeight}),/vertical bounds lie outside its host wall/);
});

test('foundation top stays below floor finishes while retaining thickness and the measured footprint',()=>{
  const result=buildHouse(T,{project:projectConfig});
  try{
    const foundation=new T.Box3().setFromObject(result.layers.architecture.getObjectByName('Foundation'));
    near(foundation.max.y-foundation.min.y,.2,'Structural foundation thickness');
    near(foundation.max.x-foundation.min.x,houseWidth(projectConfig.house)+projectConfig.house.wallThickness,'Foundation outer width');
    near(foundation.max.z-foundation.min.z,8+projectConfig.house.wallThickness,'Foundation outer depth');
    for(const floor of result.layers.architecture.children.filter(object=>object.userData.floorRegion)){
      const bounds=new T.Box3().setFromObject(floor);near(bounds.min.y,projectConfig.house.floorLevel,`${floor.name} retains its datum`);
      assert.ok(bounds.min.y-foundation.max.y>.0029,`${floor.name} must not be coplanar with the foundation cap`);
    }
  }finally{disposeHouse(result);}
});

function houseWidth(house){return Math.max(...house.footprint.map(point=>point[0]))-Math.min(...house.footprint.map(point=>point[0]));}
