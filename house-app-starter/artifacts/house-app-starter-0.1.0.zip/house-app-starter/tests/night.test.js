import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {addNightLightsToFixtures,createNightShelfLighting,createNightViewController} from '../src/night-view.js';
import {createNightWallFrameLighting} from '../src/night-wall-frame-lighting.js';

const close=(actual,expected,tolerance=1e-6)=>assert.ok(Math.abs(actual-expected)<tolerance,`${actual} differs from ${expected}`);
const vectorClose=(actual,expected)=>actual.toArray().forEach((value,index)=>close(value,expected.getComponent(index)));
function fixture(id='custom-pendant',zone='living'){
  const root=new THREE.Group();root.name=id;root.userData={productId:id,movableItem:{id},fixtureLight:{anchor:[.12,.08,.04],power:12,distance:2.4,color:'#ffe0b0',glowSize:.06,zone}};
  const body=new THREE.Group();body.name='product body';root.add(body);
  const emitter=new THREE.Mesh(new THREE.SphereGeometry(.03),new THREE.MeshStandardMaterial({color:'#fff6e5',emissive:'#271c0f',emissiveIntensity:.15}));
  emitter.userData.lightEmitter=true;body.add(emitter);return root;
}
function setup(){
  const scene=new THREE.Scene();scene.background=new THREE.Color('#faf8f4');
  const fixtures=new THREE.Group();scene.add(fixtures);
  const hemisphere=new THREE.HemisphereLight('#fafafa','#9f9e99',2.1),sun=new THREE.DirectionalLight('#fff3e2',1.8),ambient=new THREE.AmbientLight('#ffffff',.4);sun.castShadow=true;scene.add(hemisphere,sun,ambient);
  const renderer={toneMappingExposure:1.05,shadowMap:{enabled:true,needsUpdate:false}};
  return {scene,fixtures,hemisphere,sun,ambient,renderer,options:{scene,renderer,fixtureLayer:fixtures,hemisphere,sun,ambient}};
}

test('metadata fixtures retain local anchors through movement, rotation, duplication, and deletion with a fixed light budget',()=>{
  const layer=new THREE.Group();layer.position.set(2,0,-1);layer.rotation.y=.3;
  const pendant=fixture();pendant.position.set(1,2,3);pendant.rotation.y=Math.PI/2;layer.add(pendant);
  const resources=addNightLightsToFixtures(THREE,layer);resources.syncPositions(true);
  assert.equal(resources.lightCount,4);assert.equal(resources.count,1);
  const glow=pendant.getObjectByName('Night fixture glow');vectorClose(glow.position,new THREE.Vector3(.12,.08,.04));
  let light=resources.zoneLights.find(item=>item.userData.fixtureCount===1);vectorClose(light.getWorldPosition(new THREE.Vector3()),pendant.localToWorld(new THREE.Vector3(.12,.08,.04)));close(light.power,12);
  const duplicate=pendant.clone(true);duplicate.userData.movableItem.id='custom-pendant-copy';duplicate.position.set(4,2,2);duplicate.rotation.y=-Math.PI/3;layer.add(duplicate);
  resources.syncPositions(true);assert.equal(resources.count,2);assert.equal(resources.zoneLights.length,4);
  const expected=pendant.localToWorld(new THREE.Vector3(.12,.08,.04)).add(duplicate.localToWorld(new THREE.Vector3(.12,.08,.04))).multiplyScalar(.5);
  light=resources.zoneLights.find(item=>item.userData.fixtureCount===2);vectorClose(light.getWorldPosition(new THREE.Vector3()),expected);close(light.power,24);
  pendant.userData.arrangeDeleted=true;pendant.visible=false;resources.syncPositions(true);
  assert.equal(resources.count,1);assert.equal(glow.visible,false);light=resources.zoneLights.find(item=>item.userData.fixtureCount===1);
  vectorClose(light.getWorldPosition(new THREE.Vector3()),duplicate.localToWorld(new THREE.Vector3(.12,.08,.04)));
  duplicate.position.x+=1;resources.syncPositions(true);vectorClose(light.getWorldPosition(new THREE.Vector3()),duplicate.localToWorld(new THREE.Vector3(.12,.08,.04)));
  resources.syncPositions(false);assert.ok(resources.zoneLights.every(item=>!item.visible));assert.equal(duplicate.getObjectByName('Night fixture glow').visible,false);resources.dispose();
});

test('many future fixture zones cannot exceed the fixed point-light shader budget',()=>{
  const layer=new THREE.Group();for(let index=0;index<12;index++){const root=fixture(`fixture-${index}`,`room-${index}`);root.position.x=index;layer.add(root);}
  const resources=addNightLightsToFixtures(THREE,layer);resources.syncPositions(true);
  assert.equal(resources.count,12);assert.equal(resources.lightCount,4);assert.equal(resources.zoneLights.reduce((sum,light)=>sum+light.userData.fixtureCount,0),12);
  close(resources.zoneLights.reduce((sum,light)=>sum+light.power,0),144);assert.equal(layer.children.filter(item=>item.isPointLight).length,4);resources.dispose();
});

test('Day restoration preserves authored finishes, emissive emitters, media brightness, tree bases, and controls',()=>{
  const state=setup(),pendant=fixture();state.fixtures.add(pendant);
  const emitter=pendant.getObjectByProperty('isMesh',true),emissive=emitter.material.emissive.clone(),emissiveIntensity=emitter.material.emissiveIntensity;
  const unlitMaterial=new THREE.MeshBasicMaterial({color:'#c4baa4'}),videoMaterial=new THREE.MeshBasicMaterial({color:'#d5e5f2'}),houseMaterial=new THREE.MeshStandardMaterial({color:'#775b42',roughness:.63});
  state.scene.add(new THREE.Mesh(new THREE.PlaneGeometry(1,1),unlitMaterial));
  const video=new THREE.Mesh(new THREE.PlaneGeometry(1,1),videoMaterial);video.userData.nightVideo=true;state.scene.add(video);
  state.scene.add(new THREE.Mesh(new THREE.BoxGeometry(1,1,1),houseMaterial));
  const base=new THREE.Mesh(new THREE.CircleGeometry(.5),new THREE.MeshStandardMaterial({color:'#bcbab2'}));state.scene.add(base);const baseMaterial=base.material;
  const dayBackground=state.scene.background.clone(),unlitColor=unlitMaterial.color.clone(),videoColor=videoMaterial.color.clone(),houseColor=houseMaterial.color.clone(),houseVersion=houseMaterial.version;
  const classes=new Set(),attributes=new Map(),button={dataset:{},setAttribute:(key,value)=>attributes.set(key,value)};
  let theme='#fefefe',invalidations=0;const meta={getAttribute:()=>theme,setAttribute:(_key,value)=>{theme=value;}};
  const controller=createNightViewController(THREE,{...state.options,materials:{wood:houseMaterial},treeBases:[base],toggle:button,rootElement:{classList:{toggle:(name,enabled)=>enabled?classes.add(name):classes.delete(name)}},themeColorMeta:meta,invalidateReflections:()=>invalidations++});
  controller.setNightView(true);assert.equal(controller.isNight,true);assert.equal(state.scene.background.getHexString(),'242526');assert.equal(state.renderer.shadowMap.enabled,false);assert.equal(state.sun.intensity,0);
  assert.ok(unlitMaterial.color.equals(unlitColor.clone().multiplyScalar(.22)));assert.ok(videoMaterial.color.equals(videoColor.clone().multiplyScalar(2)));assert.ok(houseMaterial.color.equals(houseColor));assert.equal(houseMaterial.roughness,.63);assert.equal(houseMaterial.version,houseVersion);
  assert.equal(emitter.material.emissive.getHexString(),'ffe0b0');assert.equal(emitter.material.emissiveIntensity,.9);assert.notEqual(base.material,baseMaterial);assert.equal(button.dataset.lightingMode,'night');assert.equal(attributes.get('aria-pressed'),'true');assert.equal(theme,'#242526');assert.ok(classes.has('night-view'));
  const duplicate=pendant.clone(true);const duplicateEmitter=duplicate.getObjectByProperty('isMesh',true);duplicateEmitter.material=duplicateEmitter.material.clone();duplicate.userData.movableItem.id='new-copy';state.fixtures.add(duplicate);controller.syncFixturePositions();assert.equal(controller.fixtureCount,2);
  controller.setNightView(false);assert.ok(state.scene.background.equals(dayBackground));assert.ok(unlitMaterial.color.equals(unlitColor));assert.ok(videoMaterial.color.equals(videoColor));assert.ok(houseMaterial.color.equals(houseColor));assert.ok(emitter.material.emissive.equals(emissive));assert.ok(duplicateEmitter.material.emissive.equals(emissive));assert.equal(duplicateEmitter.material.emissiveIntensity,emissiveIntensity);
  assert.equal(base.material,baseMaterial);assert.equal(state.renderer.toneMappingExposure,1.05);assert.equal(state.renderer.shadowMap.enabled,true);assert.equal(state.renderer.shadowMap.needsUpdate,false);assert.equal(state.sun.castShadow,true);assert.equal(theme,'#fefefe');assert.ok(invalidations>=3);controller.dispose();
});

test('shelf illumination remains inside rotated local cells and updates for duplicate/deleted cabinetry',()=>{
  const layer=new THREE.Group();layer.position.set(-2,0,.5);layer.rotation.y=.2;
  const cabinet=new THREE.Group();cabinet.position.set(1,.1,2);cabinet.rotation.y=Math.PI/4;
  cabinet.userData.shelfLighting={front:'+Z',cells:[{min:[-.45,.2,-.18],max:[.45,.7,.25]},{min:[-.45,.75,-.18],max:[.45,1.2,.25]}]};layer.add(cabinet);
  const effect=createNightShelfLighting(THREE,layer);assert.equal(effect.count,2);assert.equal(effect.geometry.attributes.position.count,24);assert.equal(effect.geometry.index.count/3,12);
  layer.updateMatrixWorld(true);const inverse=cabinet.matrixWorld.clone().invert();
  for(let index=0;index<effect.geometry.attributes.position.count;index++){
    const point=new THREE.Vector3().fromBufferAttribute(effect.geometry.attributes.position,index).applyMatrix4(layer.matrixWorld).applyMatrix4(inverse),cell=cabinet.userData.shelfLighting.cells[Math.floor(index/12)];
    point.toArray().forEach((value,axis)=>assert.ok(value>=cell.min[axis]-1e-6&&value<=cell.max[axis]+1e-6,'Every receiver must remain inside its authored cell'));
  }
  assert.equal(layer.children.some(child=>child.isLight),false);assert.equal(effect.material.depthWrite,false);const first=effect.geometry.attributes.position.getX(0);
  cabinet.position.x+=.7;assert.equal(effect.syncPositions(),true);assert.notEqual(effect.geometry.attributes.position.getX(0),first);
  const duplicate=cabinet.clone(true);duplicate.position.x+=2;layer.add(duplicate);effect.syncPositions();assert.equal(effect.count,4);
  cabinet.userData.arrangeDeleted=true;cabinet.visible=false;effect.syncPositions();assert.equal(effect.count,2);effect.dispose();assert.equal(effect.mesh.parent,null);
});

test('arbitrarily named media meshes use explicit TV/keep-bright metadata and restore their Day material state',()=>{
  const state=setup(),tvMaterial=new THREE.MeshStandardMaterial({color:'#aacde2',emissive:'#ffeedd',emissiveIntensity:.7}),flameMaterial=new THREE.MeshBasicMaterial({color:'#d88632'}),ordinaryMaterial=new THREE.MeshBasicMaterial({color:'#d88632'});
  const tv=new THREE.Mesh(new THREE.PlaneGeometry(1,1),tvMaterial);tv.name='Owner selected screen';tv.userData={tvDisplay:true,keepBrightAtNight:true};
  const flame=new THREE.Mesh(new THREE.ConeGeometry(.1,.3),flameMaterial);flame.name='Generated warmth';flame.userData.keepBrightAtNight=true;
  state.scene.add(tv,flame,new THREE.Mesh(new THREE.BoxGeometry(1,1,1),ordinaryMaterial));
  const tvColor=tvMaterial.color.clone(),tvEmissive=tvMaterial.emissive.clone(),flameColor=flameMaterial.color.clone(),ordinaryColor=ordinaryMaterial.color.clone(),controller=createNightViewController(THREE,state.options);
  controller.setNightView(true);assert.ok(tvMaterial.color.equals(tvColor.clone().multiplyScalar(2)));close(tvMaterial.emissiveIntensity,1.4);assert.ok(tvMaterial.emissive.equals(tvEmissive));assert.ok(flameMaterial.color.equals(flameColor));assert.ok(ordinaryMaterial.color.equals(ordinaryColor.clone().multiplyScalar(.22)));
  controller.setNightView(false);assert.ok(tvMaterial.color.equals(tvColor));close(tvMaterial.emissiveIntensity,.7);assert.ok(flameMaterial.color.equals(flameColor));assert.ok(ordinaryMaterial.color.equals(ordinaryColor));controller.dispose();
});

function frameScene(rotation=0){
  const furniture=new THREE.Group(),architecture=new THREE.Group(),wall=new THREE.Group();wall.name='wall:host';wall.rotation.y=rotation;architecture.add(wall);
  for(const x of [-1.1,1.1]){const surface=new THREE.Mesh(new THREE.BoxGeometry(1.8,2.7,.18),new THREE.MeshStandardMaterial());surface.name='wall surface';surface.position.set(x,1.35,-.09);wall.add(surface);}
  const gallery=new THREE.Group();gallery.position.set(0,1.45,.025);gallery.rotation.y=rotation;
  gallery.userData={frameGrid:{rows:2,columns:3},movableItem:{id:'gallery',hostWall:'wall:host'}};
  gallery.add(new THREE.Mesh(new THREE.BoxGeometry(1.8,1,.035),new THREE.MeshStandardMaterial()));furniture.add(gallery);
  return {furniture,architecture,wall,gallery};
}

test('frame wash follows local XY/+Z galleries, batches sources, and clips to host wall openings',()=>{
  for(const rotation of [0,Math.PI/2]){
    const {furniture,architecture,wall,gallery}=frameScene(rotation),effect=createNightWallFrameLighting(THREE,furniture,architecture);
    assert.equal(effect.count,1);assert.equal(effect.mesh.userData.frameCount,6);assert.equal(effect.sourceMaterial.visible,false);
    const source=effect.sources[0],delta=new THREE.Vector3().fromArray(source.position).sub(new THREE.Vector3().fromArray(source.target)),front=new THREE.Vector3(0,0,1).applyAxisAngle(new THREE.Vector3(0,1,0),rotation);
    assert.ok(delta.dot(front)>0);close(Math.atan2(delta.y,Math.hypot(delta.x,delta.z))*180/Math.PI,60);vectorClose(new THREE.Vector3().fromArray(source.front),front);
    const geometry=effect.geometry,indices=geometry.index,kind=geometry.attributes.exhibitionSurfaceKind,wallInverse=wall.matrixWorld.clone().invert();let wallTriangles=0;
    for(let index=0;index<indices.count;index+=3){const ids=[0,1,2].map(offset=>indices.getX(index+offset));if(kind.getX(ids[0])!==0)continue;wallTriangles++;
      const centroid=ids.reduce((sum,id)=>sum.add(new THREE.Vector3().fromBufferAttribute(geometry.attributes.position,id)),new THREE.Vector3()).multiplyScalar(1/3).applyMatrix4(wallInverse);
      assert.ok(Math.abs(centroid.x)>=.2-1e-6,'Wall wash must not bridge the gap between host wall panels');close(centroid.z,.0004);
    }
    assert.ok(wallTriangles>0);const before=effect.sources[0].target;gallery.position.x+=.4;effect.syncPositions();assert.notDeepEqual(effect.sources[0].target,before);
    const duplicate=gallery.clone(true);duplicate.userData.movableItem.id='gallery-copy';duplicate.position.x+=2;furniture.add(duplicate);effect.syncPositions();assert.equal(effect.count,2);assert.equal(effect.mesh.userData.frameCount,12);
    gallery.visible=false;gallery.userData.arrangeDeleted=true;effect.syncPositions();assert.equal(effect.count,1);effect.dispose();
  }
});

test('shader warm-up uses a separate Night scene and keeps one cache signature after duplication',async()=>{
  const state=setup(),pendant=fixture();state.fixtures.add(pendant);let compiles=0,finishCompile;
  state.renderer.compile=(source,_camera,target)=>{compiles++;assert.notEqual(source,state.scene);assert.equal(source.children.filter(object=>object.isLight&&object.visible).length,0);assert.equal(target.children.filter(object=>object.isPointLight).length,4);assert.equal(state.renderer.shadowMap.enabled,false);};
  const controller=createNightViewController(THREE,state.options);assert.equal(controller.preparePrograms(new THREE.PerspectiveCamera()),true);assert.equal(state.renderer.shadowMap.enabled,true);assert.equal(state.sun.visible,true);
  const copy=pendant.clone(true);copy.position.x=2;state.fixtures.add(copy);controller.syncFixturePositions();assert.equal(controller.preparePrograms(new THREE.PerspectiveCamera()),false);assert.equal(compiles,1);
  state.renderer.compileAsync=(source,_camera,target)=>{assert.notEqual(source,state.scene);assert.equal(target.children.filter(object=>object.isPointLight).length,4);return new Promise(resolve=>{finishCompile=resolve;});};
  const pending=controller.prepareProgramsAsync(new THREE.OrthographicCamera());assert.equal(state.renderer.shadowMap.enabled,true);assert.equal(state.sun.visible,true);
  controller.setNightView(true);finishCompile();assert.equal(await pending,true);assert.equal(controller.isNight,true);assert.equal(state.scene.background.getHexString(),'242526');assert.equal(state.renderer.shadowMap.enabled,false);controller.dispose();
});
