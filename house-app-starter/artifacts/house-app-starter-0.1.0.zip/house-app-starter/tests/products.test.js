import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {productCatalog,createProduct,disposeProduct} from '../product-library.js';

for(const spec of productCatalog)test(`${spec.id}: dimensioned, finite, independent product`,()=>{
  const product=createProduct(spec.id),body=product.getObjectByName('product body');
  assert.ok(body);assert.equal(product.userData.productId,spec.id);
  const bounds=new THREE.Box3().setFromObject(body),size=bounds.getSize(new THREE.Vector3());
  for(const [actual,expected] of [[size.x,spec.size[0]],[size.z,spec.size[1]],[size.y,spec.size[2]]])assert.ok(Math.abs(actual-expected)<1e-6,`${actual} != ${expected}`);
  assert.ok(Math.abs(bounds.min.y)<1e-6);assert.ok(Math.abs(bounds.min.x+bounds.max.x)<1e-6);assert.ok(Math.abs(bounds.min.z+bounds.max.z)<1e-6);
  let meshes=0;
  body.traverse(object=>{
    if(!object.isMesh)return;meshes++;
    const position=object.geometry.attributes.position;assert.ok(position?.count>0);
    for(const value of position.array)assert.ok(Number.isFinite(value));
  });
  assert.ok(meshes>=3,'Products must contain independently authored parts');
  const fresh=createProduct(spec.id);let firstMaterial,secondMaterial;
  body.traverse(object=>{if(!firstMaterial&&object.isMesh)firstMaterial=object.material;});
  fresh.getObjectByName('product body').traverse(object=>{if(!secondMaterial&&object.isMesh)secondMaterial=object.material;});
  assert.notEqual(firstMaterial,secondMaterial);disposeProduct(product);disposeProduct(fresh);
});

test('Pendant body dimensions do not change with adjustable suspension',()=>{
  const short=createProduct('demo-pendant',{suspension:.2}),long=createProduct('demo-pendant',{suspension:1.2});
  const shortBody=new THREE.Box3().setFromObject(short.getObjectByName('product body')),longBody=new THREE.Box3().setFromObject(long.getObjectByName('product body'));
  assert.ok(shortBody.min.distanceTo(longBody.min)<1e-6);assert.ok(shortBody.max.distanceTo(longBody.max)<1e-6);
  const shortAll=new THREE.Box3().setFromObject(short),longAll=new THREE.Box3().setFromObject(long);
  assert.ok(Math.abs(longAll.max.y-shortAll.max.y-1)<1e-6);
  const hidden=createProduct('demo-pendant',{showSuspension:false});assert.equal(hidden.getObjectByName('adjustable suspension').visible,false);
  disposeProduct(short);disposeProduct(long);disposeProduct(hidden);
});

test('Product emitters and mirror surface are explicitly tagged',()=>{
  for(const id of ['demo-pendant','demo-floor-lamp']){
    const product=createProduct(id);let emitters=0;product.traverse(object=>{if(object.userData.lightEmitter)emitters++;});assert.equal(emitters,1);disposeProduct(product);
  }
  const mirror=createProduct('demo-mirror');assert.equal(mirror.getObjectByName('mirror face').userData.mirrorSurface,true);disposeProduct(mirror);
});

test('Unknown products and invalid creation options are rejected',()=>{
  assert.throws(()=>createProduct('missing'),/Unknown product/);
  for(const suspension of [-1,Infinity,NaN])assert.throws(()=>createProduct('demo-pendant',{suspension}),/Suspension/);
  assert.throws(()=>createProduct('demo-chair',{variant:-1}),/Variant/);
});
