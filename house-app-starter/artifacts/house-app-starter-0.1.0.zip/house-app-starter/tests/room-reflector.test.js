import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {buildHouse} from '../src/model.js';
import {projectConfig} from '../src/project-config.js';
import {createRoomReflector,clipReflectionCamera} from '../src/scene/room-reflector.js';

const near=(actual,expected,tolerance=1e-7)=>assert(Math.abs(actual-expected)<tolerance,`${actual} vs ${expected}`);
const nearScore=(camera,point)=>{
  const clip=new THREE.Vector4(point.x,point.y,point.z,1).applyMatrix4(camera.matrixWorldInverse).applyMatrix4(camera.projectionMatrix);return clip.z+clip.w;
};
function rendererFor(draw){
  let target={name:'primary target'};
  return{xr:{enabled:true},shadowMap:{autoUpdate:true,needsUpdate:true},autoClear:true,
    state:{buffers:{depth:{setMask(){}}},viewport(){}},getRenderTarget:()=>target,setRenderTarget:value=>{target=value;},render:draw};
}

test('the actual mirror clips every exterior tree corner and retains the room side at shifted zoom levels',()=>{
  const house=buildHouse(THREE,{project:projectConfig}),{mirror}=house.reflectors[0],scene=new THREE.Scene();
  Object.values(house.layers).forEach(layer=>scene.add(layer));scene.updateMatrixWorld(true);
  const bounds=new THREE.Box3().setFromObject(house.bindings.landscape.billboards[0]),mirrorPoint=mirror.getWorldPosition(new THREE.Vector3()),front=new THREE.Vector3(0,0,1).transformDirection(mirror.matrixWorld);
  let passes=0;
  const renderer=rendererFor((_,reflection)=>{
    for(const x of [bounds.min.x,bounds.max.x])for(const y of [bounds.min.y,bounds.max.y])for(const z of [bounds.min.z,bounds.max.z])assert(nearScore(reflection,new THREE.Vector3(x,y,z))<0,'Exterior tree geometry behind the mirror must be clipped');
    assert(nearScore(reflection,mirrorPoint.clone().addScaledVector(front,.5))>0,'Room geometry in front must remain');
    const identity=reflection.projectionMatrix.clone().multiply(reflection.projectionMatrixInverse);
    identity.elements.forEach((value,index)=>near(value,index%5===0?1:0));passes++;
  });
  for(const zoom of [1,4.5])for(const far of [30,500,5000]){
    const camera=new THREE.OrthographicCamera(-3,4,3,-2,.1,far);camera.zoom=zoom;camera.position.copy(mirrorPoint).add(new THREE.Vector3(5,4,3));camera.lookAt(mirrorPoint);camera.updateProjectionMatrix();camera.updateMatrixWorld(true);
    mirror.onBeforeRender(renderer,scene,camera);
  }
  assert.equal(passes,6);mirror.dispose();
});

test('physical clip tolerance is independent of camera projection and far distance',()=>{
  const normal=new THREE.Vector3(1,0,1).normalize(),point=new THREE.Vector3(2,1,-3),plane=new THREE.Plane().setFromNormalAndCoplanarPoint(normal,point);
  for(const type of ['orthographic','perspective'])for(const far of [30,500,5000]){
    const camera=type==='orthographic'?new THREE.OrthographicCamera(-4,5,3,-2,.1,far):new THREE.PerspectiveCamera(50,1.4,.1,far);
    camera.position.copy(point).addScaledVector(normal,-8).add(new THREE.Vector3(0,3,0));camera.lookAt(point.clone().addScaledVector(normal,2));camera.updateMatrixWorld(true);
    const original=camera.projectionMatrix.clone();assert(clipReflectionCamera(camera,original,plane,.003));
    assert(nearScore(camera,point.clone().addScaledVector(normal,-.002))>0,'Two millimeters behind is within the requested tolerance');
    assert(nearScore(camera,point.clone().addScaledVector(normal,-.004))<0,'Four millimeters behind must be clipped');
    assert(nearScore(camera,point.clone().addScaledVector(normal,.2))>0,'Front-side objects remain visible');
  }
});

test('asymmetric orthographic clipping preserves the selected far corner',()=>{
  const camera=new THREE.OrthographicCamera(-18,22,10,-14,.1,500);camera.position.set(-8,4,2);camera.lookAt(2,1,0);camera.updateMatrixWorld(true);
  const plane=new THREE.Plane().setFromNormalAndCoplanarPoint(new THREE.Vector3(1,0,0),new THREE.Vector3(0,0,0)),original=camera.projectionMatrix.clone(),viewPlane=plane.clone().applyMatrix4(camera.matrixWorldInverse);
  const corner=new THREE.Vector4(Math.sign(viewPlane.normal.x),Math.sign(viewPlane.normal.y),1,1).applyMatrix4(original.clone().invert());
  assert(clipReflectionCamera(camera,original,plane,0));corner.applyMatrix4(camera.projectionMatrix);near(corner.z,corner.w);
});

test('reflection restores physical cutaway walls and all primary render state, including after errors',()=>{
  const wall=new THREE.Group();wall.visible=false;
  const mirror=createRoomReflector(new THREE.CircleGeometry(.4,32),{wallGroups:[wall]});mirror.position.set(0,1,0);mirror.rotation.y=Math.PI/2;mirror.updateMatrixWorld(true);
  const camera=new THREE.OrthographicCamera(-3,3,3,-3,.1,100);camera.position.set(5,4,3);camera.lookAt(mirror.position);camera.updateMatrixWorld(true);
  for(const fail of [false,true]){
    const renderer=rendererFor(()=>{assert.equal(wall.visible,true);assert.equal(renderer.shadowMap.needsUpdate,false);if(fail)throw new Error('reflection failure');}),originalTarget=renderer.getRenderTarget();
    if(fail)assert.throws(()=>mirror.onBeforeRender(renderer,new THREE.Scene(),camera),/reflection failure/);
    else mirror.onBeforeRender(renderer,new THREE.Scene(),camera);
    assert.equal(wall.visible,false);assert.equal(mirror.visible,true);assert.equal(renderer.getRenderTarget(),originalTarget);assert.equal(renderer.xr.enabled,true);assert.equal(renderer.shadowMap.autoUpdate,true);assert.equal(renderer.shadowMap.needsUpdate,true);
  }
  mirror.dispose();
});
