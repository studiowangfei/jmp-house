import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {createCenteredSnapshotCamera} from '../src/snapshot-camera.js';

test('Snapshot camera centers vertically without mutating the live view',()=>{
  const live=new THREE.OrthographicCamera(-7,9,8,-12,.1,100),target=new THREE.Vector3(1,2,3);live.position.set(5,6,7);live.zoom=2;live.layers.set(3);live.userData={viewportShift:{leftFraction:.08,topFraction:.06},marker:'live'};live.lookAt(target);live.updateProjectionMatrix();live.updateMatrixWorld(true);
  const sourceProjection=live.projectionMatrix.toArray(),sourcePosition=live.position.clone(),sourceQuaternion=live.quaternion.clone(),snapshot=createCenteredSnapshotCamera(live),projectedTarget=target.clone().project(snapshot);
  assert.notEqual(snapshot,live);assert.equal(snapshot.top,10);assert.equal(snapshot.bottom,-10);assert.equal(snapshot.left,live.left);assert.equal(snapshot.right,live.right);assert.equal(snapshot.zoom,live.zoom);assert.equal(snapshot.layers.mask,live.layers.mask);assert(snapshot.position.equals(sourcePosition));assert(snapshot.quaternion.equals(sourceQuaternion));assert(Math.abs(projectedTarget.y)<1e-12,'Camera target must land at the vertical center of the PNG');assert.deepEqual(snapshot.userData.viewportShift,{leftFraction:.08,topFraction:0});
  assert.equal(live.top,8);assert.equal(live.bottom,-12);assert(live.position.equals(sourcePosition));assert(live.quaternion.equals(sourceQuaternion));assert.deepEqual(live.projectionMatrix.toArray(),sourceProjection);assert.deepEqual(live.userData,{viewportShift:{leftFraction:.08,topFraction:.06},marker:'live'});
});

test('Snapshot centering rejects non-orthographic cameras',()=>{
  assert.throws(()=>createCenteredSnapshotCamera(new THREE.PerspectiveCamera()),/orthographic camera/);
});
