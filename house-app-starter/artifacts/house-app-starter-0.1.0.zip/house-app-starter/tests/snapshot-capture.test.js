import test from 'node:test';
import assert from 'node:assert/strict';
import {captureCanvasAtAspect,centeredAspectCrop} from '../snapshot-capture.js';

test('Snapshot crop is the largest centered exact 4:3 rectangle',()=>{
  assert.deepEqual(centeredAspectCrop(1600,1100),{x:68,y:1,width:1464,height:1098,aspectWidth:4,aspectHeight:3});
  assert.deepEqual(centeredAspectCrop(780,1688),{x:0,y:551,width:780,height:585,aspectWidth:4,aspectHeight:3});
  for(const [width,height] of [[1464,1098],[780,585]])assert.equal(width/height,4/3);
});

test('Mobile Snapshot crop is centered portrait 3:4',()=>{
  assert.deepEqual(centeredAspectCrop(780,1688,3,4),{x:0,y:324,width:780,height:1040,aspectWidth:3,aspectHeight:4});assert.equal(780/1040,3/4);
});

test('Snapshot aspect capture crops without resizing or mutating the source canvas',async()=>{
  const source={width:780,height:1688},draws=[],blob={type:'image/png'},output={width:0,height:0,getContext:()=>({drawImage:(...args)=>draws.push(args)}),toBlob:callback=>callback(blob)};
  assert.equal(await captureCanvasAtAspect(source,{createCanvas:()=>output}),blob);assert.equal(output.width,780);assert.equal(output.height,585);assert.deepEqual(draws,[[source,0,551,780,585,0,0,780,585]]);assert.deepEqual(source,{width:780,height:1688});
});

test('Snapshot crop rejects invalid sizes',()=>{
  assert.throws(()=>centeredAspectCrop(2,2),/too small/);assert.throws(()=>centeredAspectCrop(0,100),/positive/);
});
