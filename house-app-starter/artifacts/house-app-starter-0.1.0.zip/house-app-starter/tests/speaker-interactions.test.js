import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {createProduct,disposeProduct} from '../product-library.js';
import {updateSpeakerPlaybackVisual} from '../speaker-playback.js';
import {collectInteractionTargets,galleryPhotoForHit} from '../scene-interactions.js';

test('the actual speaker animates its indicator/dial/drivers and restores pause/reduced-motion state',()=>{
  const root=createProduct('demo-speaker'),indicator=root.getObjectByName('Playback indicator'),dial=root.getObjectByName('Top volume dial'),driver=root.getObjectByName('Speaker driver grille');
  const color=indicator.material.color.getHex(),emissive=indicator.material.emissiveIntensity,rest=driver.position.z;
  assert(updateSpeakerPlaybackVisual(root,{playing:true,currentTime:.35}));
  assert.notEqual(indicator.material.color.getHex(),color);assert.notEqual(dial.rotation.y,0);assert.notEqual(driver.position.z,rest);assert(Math.abs(driver.position.z-rest)<=.00025);
  const duplicate=root.clone(true);updateSpeakerPlaybackVisual(duplicate,{playing:true,currentTime:.4});
  updateSpeakerPlaybackVisual(root,{playing:false,currentTime:.4});updateSpeakerPlaybackVisual(duplicate,{playing:false,currentTime:.4});
  assert.equal(indicator.material.color.getHex(),color);assert.equal(indicator.material.emissiveIntensity,emissive);assert.equal(driver.position.z,rest);
  updateSpeakerPlaybackVisual(root,{playing:true,currentTime:10,reducedMotion:true});assert.equal(driver.position.z,rest);assert.equal(dial.rotation.y,0);
  disposeProduct(root);
});

test('gallery duplicates retain their own photo and clickable target rather than the original frame',()=>{
  const frame=new THREE.Group(),photo=new THREE.Mesh(new THREE.PlaneGeometry(.3,.3),new THREE.MeshBasicMaterial()),hit=new THREE.Mesh(new THREE.PlaneGeometry(.4,.4),new THREE.MeshBasicMaterial({visible:false}));
  photo.userData={galleryPhoto:true,galleryIndex:2};hit.userData={interaction:'gallery',galleryIndex:2};frame.add(photo,hit);
  const copy=frame.clone(true),targets=collectInteractionTargets(copy);
  assert.equal(targets.meshes.length,1);assert.equal(targets.photos.length,1);assert.equal(galleryPhotoForHit(targets.meshes[0]),targets.photos[0]);assert.notEqual(targets.photos[0],photo);assert.equal(targets.photos[0].userData.galleryIndex,2);
});

test('wall-mounted product metadata makes its mirror available to generic frame illumination',()=>{
  const root=createProduct('demo-mirror');assert(root.userData.wallFrame);assert.equal(root.userData.wallFrame.width,.75);assert.equal(root.userData.wallFrame.height,.75);disposeProduct(root);
});
