import test from 'node:test';
import assert from 'node:assert/strict';
import {createRetroStaticPixels,createTvVideoTransitionController} from '../src/tv-video-transition.js';

class FakeVideo{
  constructor(){this.listeners=new Map();this.readyState=0;this.src='';this.currentSrc='';}
  addEventListener(type,listener){if(!this.listeners.has(type))this.listeners.set(type,new Set());this.listeners.get(type).add(listener);}
  removeEventListener(type,listener){this.listeners.get(type)?.delete(listener);}
  dispatch(type){for(const listener of this.listeners.get(type)||[])listener({type,target:this});}
}
function fixture({deferPresentation=false,animatedStatic=false,reduced=false}={}){
  const video=new FakeVideo(),videoTexture={name:'video',needsUpdate:false},staticTexture={name:'static',needsUpdate:false,disposed:false,dispose(){this.disposed=true;}},videoMaterial={name:'video material',map:videoTexture,color:{value:2}},staticMaterial={name:'static material',map:staticTexture,disposed:false,color:{copy(source){this.value=source.value;return this;},multiplyScalar(scale){this.value*=scale;return this;}},dispose(){this.disposed=true;}},display={material:videoMaterial};let time=0,renders=0,nextTimer=1;
  const timers=new Map(),presentations=new Map(),frameChanges=[],present=callback=>{const id=nextTimer++;if(deferPresentation)presentations.set(id,callback);else callback();return id;},controller=createTvVideoTransitionController({video,display,videoMaterial,staticMaterial,videoTexture,staticTexture,requestRender:()=>renders++,paintStaticFrame:index=>{frameChanges.push(index);staticTexture.needsUpdate=true;},staticFrameCount:animatedStatic?4:1,staticFrameIntervalMs:100,staticAnimationDurationMs:300,staticBrightness:.8,reducedMotion:()=>reduced,minimumVisibleMs:300,now:()=>time,schedule:(callback,delay)=>{const id=nextTimer++;timers.set(id,{callback,at:time+delay});return id;},cancel:id=>timers.delete(id),present,cancelPresent:id=>presentations.delete(id),resolveSource:source=>`resolved:${source}`});
  const advance=ms=>{time+=ms;for(const [id,timer] of [...timers])if(timer.at<=time){timers.delete(id);timer.callback();}};
  const paint=()=>{for(const [id,callback] of [...presentations]){presentations.delete(id);callback();}};
  return{video,videoTexture,staticTexture,videoMaterial,staticMaterial,display,controller,advance,paint,frameChanges,get renders(){return renders;},get timers(){return timers;},get presentations(){return presentations;}};
}

test('retro static pixels are deterministic, opaque and lightweight',()=>{
  const a=createRetroStaticPixels(),b=createRetroStaticPixels(),alternate=createRetroStaticPixels(256,144,0x43525430);assert.equal(a.length,256*144*4);assert.deepEqual(a,b);assert.notDeepEqual(a,alternate,'animation frames need distinct deterministic noise');
  let darkest=255,brightest=0;for(let index=0;index<a.length;index+=4){darkest=Math.min(darkest,a[index]);brightest=Math.max(brightest,a[index]);assert.equal(a[index+3],255);}
  assert(darkest<8&&brightest>200,'CRT static needs a full monochrome noise range');
});

test('TV transition shows one shared placeholder until the decoded frame and minimum interval are ready',()=>{
  const f=fixture();assert.equal(f.controller.begin('night','night.mp4'),1);assert.equal(f.display.material,f.staticMaterial);assert.equal(f.staticMaterial.color.value,f.videoMaterial.color.value*.8);assert.equal(f.videoMaterial.color.value,2,'dimming the transition must not alter video brightness');assert.equal(f.staticTexture.needsUpdate,true);assert.equal(f.renders,1);
  f.video.src='night.mp4';f.video.currentSrc='night.mp4';f.video.readyState=2;f.video.dispatch('loadeddata');assert.equal(f.display.material,f.staticMaterial);assert.equal(f.timers.size,1);
  f.advance(299);assert.equal(f.display.material,f.staticMaterial);f.advance(1);assert.equal(f.display.material,f.videoMaterial);assert.equal(f.videoTexture.needsUpdate,true);assert.equal(f.controller.active,false);assert.equal(f.renders,2);
});

test('rapid mode switches invalidate stale reveal callbacks',()=>{
  const f=fixture();f.controller.begin('night','night.mp4');f.video.src='night.mp4';f.video.currentSrc='night.mp4';f.video.readyState=2;f.video.dispatch('loadeddata');assert.equal(f.timers.size,1);
  f.advance(100);f.controller.begin('day','day.mp4');assert.equal(f.staticMaterial.color.value,f.videoMaterial.color.value*.8,'brightness reduction must be copied from the video finish instead of compounding');assert.equal(f.timers.size,0);f.advance(300);assert.equal(f.display.material,f.staticMaterial);
  f.video.src='day.mp4';f.video.currentSrc='day.mp4';f.video.readyState=2;f.video.dispatch('loadeddata');assert.equal(f.display.material,f.videoMaterial);assert.equal(f.controller.generation,2);
});

test('minimum visibility starts only after the placeholder reaches a presentation frame',()=>{
  const f=fixture({deferPresentation:true});f.controller.begin('night','night.mp4');f.video.src='night.mp4';f.video.currentSrc='night.mp4';f.video.readyState=2;f.video.dispatch('loadeddata');f.advance(1000);assert.equal(f.display.material,f.staticMaterial);assert.equal(f.timers.size,0);
  f.paint();f.advance(299);assert.equal(f.display.material,f.staticMaterial);f.advance(1);assert.equal(f.display.material,f.videoMaterial);
});

test('animated CRT static cycles four frames at 10 fps only after its first painted frame',()=>{
  const f=fixture({deferPresentation:true,animatedStatic:true});f.controller.begin('night','night.mp4');f.video.src='night.mp4';f.video.currentSrc='night.mp4';f.video.readyState=2;f.video.dispatch('loadeddata');assert.deepEqual(f.frameChanges,[0]);f.advance(500);assert.deepEqual(f.frameChanges,[0]);
  f.paint();f.advance(99);assert.deepEqual(f.frameChanges,[0]);f.advance(1);assert.deepEqual(f.frameChanges,[0,1]);assert.equal(f.display.material,f.staticMaterial);f.advance(100);f.advance(100);assert.deepEqual(f.frameChanges,[0,1,2,3]);assert.equal(f.display.material,f.videoMaterial,'decoded video may appear only after the required painted noise advances');f.advance(500);assert.deepEqual(f.frameChanges,[0,1,2,3],'animation must stop after the bounded transition interval');
});

test('reduced motion keeps the CRT transition on its first frame',()=>{
  const f=fixture({animatedStatic:true,reduced:true});f.controller.begin('night','night.mp4');f.advance(1000);assert.deepEqual(f.frameChanges,[0]);assert.equal(f.display.material,f.staticMaterial);
});

test('wrong-source events and errors cannot reveal a stale video frame',()=>{
  const f=fixture();f.controller.begin('night','night.mp4');f.advance(400);f.video.src='day.mp4';f.video.currentSrc='day.mp4';f.video.readyState=2;f.video.dispatch('loadeddata');assert.equal(f.display.material,f.staticMaterial);
  f.video.dispatch('error');assert.equal(f.controller.active,false);assert.equal(f.display.material,f.staticMaterial);f.controller.dispose();assert.equal(f.display.material,f.videoMaterial);assert.equal(f.staticMaterial.disposed,true);assert.equal(f.staticTexture.disposed,true);assert.equal(f.video.listeners.get('loadeddata').size,0);
});
