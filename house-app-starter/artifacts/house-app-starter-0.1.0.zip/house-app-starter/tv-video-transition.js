const DEFAULT_WIDTH=256,DEFAULT_HEIGHT=144,DEFAULT_SEED=0x43525431,HAVE_CURRENT_DATA=2,retroStaticTextures=new WeakMap();

export function createRetroStaticPixels(width=DEFAULT_WIDTH,height=DEFAULT_HEIGHT,seed=DEFAULT_SEED){
  if(!Number.isInteger(width)||width<1||!Number.isInteger(height)||height<1)throw new Error('Retro TV texture dimensions must be positive integers');
  const pixels=new Uint8ClampedArray(width*height*4);let state=seed>>>0||DEFAULT_SEED,offset=0;
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    state^=state<<13;state^=state>>>17;state^=state<<5;state>>>=0;
    const nx=(x+.5)/width*2-1,ny=(y+.5)/height*2-1,radius=Math.hypot(nx,ny),vignette=1-Math.min(.58,Math.max(0,(radius-.42)/.72)*.58),scanline=y%2?.84:1,edge=Math.min(x,y,width-1-x,height-1-y),edgeShade=edge<3?.46+edge*.18:1;
    let value=12+(state>>>24)*.86;if((state&63)===0)value=state&64?246:4;
    const luminance=Math.max(0,Math.min(255,Math.round(value*vignette*scanline*edgeShade)));
    pixels[offset++]=Math.round(luminance*.96);pixels[offset++]=Math.round(luminance*.99);pixels[offset++]=Math.min(255,Math.round(luminance*1.03));pixels[offset++]=255;
  }
  return pixels;
}

export function createRetroTvStaticTexture(THREE,{width=DEFAULT_WIDTH,height=DEFAULT_HEIGHT,seed=DEFAULT_SEED,frameCount=4,createCanvas=()=>document.createElement('canvas')}={}){
  const canvas=createCanvas();canvas.width=width;canvas.height=height;
  const context=canvas.getContext('2d',{alpha:false});if(!context)throw new Error('Retro TV texture needs a 2D canvas context');
  const count=Math.max(1,Math.floor(frameCount)),frames=Array.from({length:count},(_,index)=>createRetroStaticPixels(width,height,(seed^Math.imul(index,0x9e3779b9))>>>0)),image=context.createImageData(width,height);image.data.set(frames[0]);context.putImageData(image,0,0);
  const texture=new THREE.CanvasTexture(canvas);texture.name='Retro TV transition static';texture.colorSpace=THREE.SRGBColorSpace;texture.wrapS=THREE.ClampToEdgeWrapping;texture.wrapT=THREE.ClampToEdgeWrapping;texture.minFilter=THREE.LinearFilter;texture.magFilter=THREE.LinearFilter;texture.generateMipmaps=false;
  texture.userData={effect:'temporary animated retro CRT static',width,height,seed,animated:count>1,frameCount:count,fps:10,shared:true,currentFrame:0};retroStaticTextures.set(texture,{context,image,frames,currentFrame:0});return texture;
}

export function setRetroTvStaticFrame(texture,index=0){
  const state=retroStaticTextures.get(texture);if(!state)return false;
  const frame=((Math.floor(index)%state.frames.length)+state.frames.length)%state.frames.length;if(frame===state.currentFrame&&texture.needsUpdate)return frame;
  state.image.data.set(state.frames[frame]);state.context.putImageData(state.image,0,0);state.currentFrame=frame;texture.userData.currentFrame=frame;texture.needsUpdate=true;return frame;
}

export function createTvVideoTransitionController({video,display,videoMaterial=display?.material,staticMaterial,videoTexture,staticTexture=staticMaterial?.map,requestRender=()=>{},paintStaticFrame=()=>false,staticFrameCount=1,staticFrameIntervalMs=100,staticAnimationDurationMs=650,staticBrightness=1,reducedMotion=()=>false,onStateChange=()=>{},minimumVisibleMs=300,now=()=>performance.now(),schedule=(callback,delay)=>setTimeout(callback,delay),cancel=handle=>clearTimeout(handle),present=callback=>globalThis.requestAnimationFrame?requestAnimationFrame(callback):schedule(callback,0),cancelPresent=handle=>globalThis.cancelAnimationFrame?cancelAnimationFrame(handle):cancel(handle),resolveSource=source=>new URL(source,document.baseURI).href}={}){
  if(!video||!display||!videoMaterial||!staticMaterial||!videoTexture||!staticTexture)throw new Error('TV transition controller requires video, display and both materials and textures');
  let generation=0,pending=null,revealTimer=0,staticFrameTimer=0,presentationFrame=0,staticFrame=0,disposed=false;
  const clearRevealTimer=()=>{if(revealTimer){cancel(revealTimer);revealTimer=0;}};
  const clearStaticFrameTimer=()=>{if(staticFrameTimer){cancel(staticFrameTimer);staticFrameTimer=0;}};
  const clearPresentationFrame=()=>{if(presentationFrame){cancelPresent(presentationFrame);presentationFrame=0;}};
  const sourceMatches=()=>{
    if(!pending)return false;
    const current=video.currentSrc||video.src;if(!current)return false;
    try{return resolveSource(current)===pending.source;}catch{return current===pending.source;}
  };
  const reveal=(token=generation)=>{
    if(disposed||!pending||pending.generation!==token||video.readyState<HAVE_CURRENT_DATA||!sourceMatches())return false;
    if(!Number.isFinite(pending.notBefore)||!pending.animationDone)return false;
    const remaining=pending.notBefore-now();
    if(remaining>0){clearRevealTimer();revealTimer=schedule(()=>{revealTimer=0;reveal(token);},remaining);return false;}
    clearRevealTimer();clearStaticFrameTimer();videoTexture.needsUpdate=true;display.material=videoMaterial;pending=null;onStateChange('video');requestRender();return true;
  };
  const scheduleStaticFrame=(token=generation)=>{
    if(disposed||!pending||pending.generation!==token||pending.animationDone)return;
    if(reducedMotion()){pending.animationFramesRemaining=0;pending.animationDone=true;reveal(token);return;}
    staticFrameTimer=schedule(()=>{staticFrameTimer=0;if(disposed||!pending||pending.generation!==token)return;if(reducedMotion()){pending.animationFramesRemaining=0;pending.animationDone=true;reveal(token);return;}staticFrame=(staticFrame+1)%staticFrameCount;paintStaticFrame(staticFrame);requestRender();pending.animationFramesRemaining--;if(pending.animationFramesRemaining>0)scheduleStaticFrame(token);else{pending.animationDone=true;reveal(token);}},staticFrameIntervalMs);
  };
  const onLoadedData=()=>reveal();
  const onError=()=>{if(!pending)return;clearRevealTimer();clearStaticFrameTimer();clearPresentationFrame();pending=null;onStateChange('error');requestRender();};
  video.addEventListener('loadeddata',onLoadedData);video.addEventListener('error',onError);
  const begin=(mode,source)=>{
    if(disposed)return false;
    clearRevealTimer();clearStaticFrameTimer();clearPresentationFrame();const token=++generation;
    pending={generation:token,mode,source:resolveSource(source),notBefore:Infinity,animationDone:false,animationFramesRemaining:0};staticFrame=0;paintStaticFrame(0);
    staticTexture.needsUpdate=true;if(staticMaterial.color?.copy&&videoMaterial.color){staticMaterial.color.copy(videoMaterial.color);staticMaterial.color.multiplyScalar?.(staticBrightness);}display.material=staticMaterial;onStateChange('static');requestRender();
    let presented=false;const handle=present(()=>{presented=true;presentationFrame=0;if(disposed||!pending||pending.generation!==token)return;pending.notBefore=now()+Math.max(0,minimumVisibleMs);pending.animationFramesRemaining=staticFrameCount>1&&!reducedMotion()?Math.max(1,Math.floor(staticAnimationDurationMs/staticFrameIntervalMs)):0;pending.animationDone=pending.animationFramesRemaining===0;onStateChange('static-presented');scheduleStaticFrame(token);reveal(token);});if(!presented)presentationFrame=handle||0;return token;
  };
  const dispose=()=>{if(disposed)return;disposed=true;generation++;pending=null;clearRevealTimer();clearStaticFrameTimer();clearPresentationFrame();video.removeEventListener('loadeddata',onLoadedData);video.removeEventListener('error',onError);if(display.material===staticMaterial)display.material=videoMaterial;onStateChange('disposed');staticMaterial.dispose?.();staticTexture.dispose?.();};
  return{begin,reveal,dispose,get active(){return Boolean(pending);},get generation(){return generation;},get mode(){return pending?.mode||null;}};
}
