#!/usr/bin/env python3
"""Verify built runtime hashes and source freshness with no third-party packages."""
import argparse
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent

def verify(root, *, deployed=False):
    manifest_path = root / 'build-manifest.json'
    if not manifest_path.is_file():
        raise ValueError('Missing build-manifest.json; run npm run build first')
    manifest = json.loads(manifest_path.read_text())
    if manifest.get('schemaVersion') != 1 or not manifest.get('files'):
        raise ValueError('Invalid build manifest')
    def check_entries(entries):
        for relative, expected in entries.items():
            candidate = Path(relative)
            if candidate.is_absolute() or '..' in candidate.parts:
                raise ValueError(f'Invalid relative path: {relative}')
            target = root / candidate
            if not target.is_file():
                raise ValueError(f'Missing file: {relative}')
            data = target.read_bytes()
            if len(data) != expected['bytes'] or hashlib.sha256(data).hexdigest() != expected['sha256']:
                raise ValueError(f'Stale or changed file: {relative}; rebuild the application')
    check_entries(manifest['files'])
    if not deployed:
        check_entries(manifest.get('inputs', {}))
    for html, css, bundle in [('index.html', 'styles.css', 'app.bundle.js'), ('products.html', 'products.css', 'products.bundle.js')]:
        text = (root / html).read_text()
        for asset in (css, bundle):
            fingerprint = manifest['files'][asset]['sha256'][:16]
            if f'{asset}?v=sha256-{fingerprint}' not in text:
                raise ValueError(f'Unstamped or stale asset link: {html}: {asset}')
        if re.search(r'(?:src|href)=[\"\'](?:https?:)?//', text):
            raise ValueError(f'Unexpected remote runtime dependency in {html}')
    if deployed:
        expected = set(manifest['files']) | {'build-manifest.json'}
        actual = {file.relative_to(root).as_posix() for file in root.rglob('*') if file.is_file()}
        if actual != expected:
            raise ValueError(f'Deployment file inventory differs: {sorted(actual ^ expected)}')
    return len(manifest['files'])

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--dist', action='store_true')
    args = parser.parse_args()
    try:
        count = verify(args.root.resolve(), deployed=args.dist)
    except (ValueError, OSError, KeyError) as error:
        raise SystemExit(str(error))
    print(f'Verified {count} runtime files' + (' in deployment' if args.dist else ' and source freshness'))
