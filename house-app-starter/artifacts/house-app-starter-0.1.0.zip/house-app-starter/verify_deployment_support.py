"""Import the CLI verifier without running its main function."""
import importlib.util
from pathlib import Path

spec = importlib.util.spec_from_file_location('house_verifier', Path(__file__).with_name('verify-deployment.py'))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
verify = module.verify
